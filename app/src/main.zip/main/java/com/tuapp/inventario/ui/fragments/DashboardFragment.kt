﻿package com.tuapp.inventario.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.tuapp.inventario.R

class DashboardFragment : Fragment() {
    
    private lateinit var btnIngreso: Button
    private lateinit var btnStock: Button
    private lateinit var btnVencimientos: Button
    private lateinit var btnVentaVolumen: Button
    
    private var listener: DashboardListener? = null
    
    interface DashboardListener {
        fun onIngresoMercaderia()
        fun onStockFinal()
        fun onVencimientos()
        fun onVentaVolumen()
    }
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        inicializarVistas(view)
        configurarListeners()
    }
    
    fun setListener(listener: DashboardListener) {
        this.listener = listener
    }
    
    private fun inicializarVistas(view: View) {
        btnIngreso = view.findViewById(R.id.btnIngreso)
        btnStock = view.findViewById(R.id.btnStock)
        btnVencimientos = view.findViewById(R.id.btnVencimientos)
        btnVentaVolumen = view.findViewById(R.id.btnVentaVolumen)
    }
    
    private fun configurarListeners() {
        btnIngreso.setOnClickListener {
            listener?.onIngresoMercaderia()
        }
        
        btnStock.setOnClickListener {
            listener?.onStockFinal()
        }
        
        btnVencimientos.setOnClickListener {
            listener?.onVencimientos()
        }
        
        btnVentaVolumen.setOnClickListener {
            listener?.onVentaVolumen()
        }
    }
    
    fun actualizarEstadoBotones(
        ingresoCompleto: Boolean,
        stockCompleto: Boolean,
        vencimientosCompleto: Boolean
    ) {
        // Actualizar apariencia de botones segun estado
        actualizarBoton(btnIngreso, ingresoCompleto)
        actualizarBoton(btnStock, stockCompleto)
        actualizarBoton(btnVencimientos, vencimientosCompleto)
    }
    
    private fun actualizarBoton(boton: Button, completado: Boolean) {
        if (completado) {
            boton.setBackgroundColor(resources.getColor(android.R.color.holo_green_dark, null))
        } else {
            boton.setBackgroundColor(resources.getColor(R.color.brand_gold, null))
        }
    }
}
