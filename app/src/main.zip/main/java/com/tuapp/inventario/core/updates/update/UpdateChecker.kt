﻿package com.tuapp.inventario.update

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

data class UpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val downloadUrl: String,
    val fileName: String,
    val description: String,
    val forceUpdate: Boolean = false
)

class UpdateChecker(private val context: Context) {
    
    private val firestore = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()
    
    companion object {
        private const val TAG = "UpdateChecker"
        private const val COLLECTION_UPDATE = "app_updates"
        private const val DOCUMENT_LATEST = "latest"
    }
    
    /**
     * Verifica si hay una actualizacion disponible
     */
    suspend fun checkForUpdate(): UpdateInfo? {
        return try {
            Log.d(TAG, " Verificando actualizaciones...")
            
            val currentVersionCode = getCurrentVersionCode()
            Log.d(TAG, " Version actual: $currentVersionCode")
            
            val updateInfo = getLatestUpdateInfo()
            
            if (updateInfo != null && updateInfo.versionCode > currentVersionCode) {
                Log.d(TAG, " Actualizacion disponible: ${updateInfo.versionName} (${updateInfo.versionCode})")
                updateInfo
            } else {
                Log.d(TAG, " Aplicacion actualizada")
                null
            }
            
        } catch (e: Exception) {
            Log.e(TAG, " Error verificando actualizaciones", e)
            null
        }
    }
    
    /**
     * Obtiene la informacion de la ultima actualizacion desde Firestore
     */
    private suspend fun getLatestUpdateInfo(): UpdateInfo? {
        return try {
            val document = firestore.collection(COLLECTION_UPDATE)
                .document(DOCUMENT_LATEST)
                .get()
                .await()
            
            if (document.exists()) {
                val data = document.data
                UpdateInfo(
                    versionCode = (data?.get("versionCode") as? Long ?: 0).toInt(),
                    versionName = data?.get("versionName") as? String ?: "",
                    downloadUrl = data?.get("downloadUrl") as? String ?: "",
                    fileName = data?.get("fileName") as? String ?: "",
                    description = data?.get("description") as? String ?: "",
                    forceUpdate = data?.get("forceUpdate") as? Boolean ?: false
                )
            } else {
                Log.w(TAG, " No se encontro informacion de actualizacion en Firestore")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, " Error obteniendo informacion de actualizacion", e)
            null
        }
    }
    
    /**
     * Obtiene el codigo de version actual de la aplicacion
     */
    private fun getCurrentVersionCode(): Int {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.longVersionCode.toInt()
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, " Error obteniendo version actual", e)
            0
        }
    }
    
    /**
     * Descarga la nueva APK desde Firebase Storage
     */
    suspend fun downloadUpdate(updateInfo: UpdateInfo, onProgress: (Int) -> Unit = {}): File? {
        return try {
            Log.d(TAG, " Iniciando descarga de actualizacion...")
            
            val storageRef = storage.reference.child("apks/${updateInfo.fileName}")
            val localFile = File(context.getExternalFilesDir(null), updateInfo.fileName)
            
            // Crear directorio si no existe
            localFile.parentFile?.mkdirs()
            
            // Descargar archivo
            storageRef.getFile(localFile).addOnProgressListener { taskSnapshot ->
                val progress = (100 * taskSnapshot.bytesTransferred / taskSnapshot.totalByteCount).toInt()
                onProgress(progress)
                Log.d(TAG, " Progreso descarga: $progress%")
            }.await()
            
            Log.d(TAG, " Descarga completada: ${localFile.absolutePath}")
            localFile
            
        } catch (e: Exception) {
            Log.e(TAG, " Error descargando actualizacion", e)
            null
        }
    }
    
    /**
     * Verifica si el archivo APK es valido
     */
    fun validateApk(file: File): Boolean {
        return try {
            file.exists() && file.length() > 0 && file.extension == "apk"
        } catch (e: Exception) {
            Log.e(TAG, " Error validando APK", e)
            false
        }
    }
    
    /**
     * Obtiene el tamano del archivo de actualizacion
     */
    suspend fun getUpdateSize(updateInfo: UpdateInfo): Long {
        return try {
            val storageRef = storage.reference.child("apks/${updateInfo.fileName}")
            val metadata = storageRef.metadata.await()
            metadata.sizeBytes
        } catch (e: Exception) {
            Log.e(TAG, " Error obteniendo tamano de actualizacion", e)
            0L
        }
    }
}
