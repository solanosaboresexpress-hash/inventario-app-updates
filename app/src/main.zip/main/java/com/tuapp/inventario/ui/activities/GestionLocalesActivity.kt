﻿package com.tuapp.inventario

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.ktx.functions
import com.google.firebase.ktx.Firebase
import com.tuapp.inventario.model.Local
import com.tuapp.inventario.model.UsuarioLocal
import com.tuapp.inventario.model.Supervisor
import com.tuapp.inventario.model.UsuarioActual
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.tasks.await
import com.tuapp.inventario.utils.DateHelper
import com.tuapp.inventario.utils.FirebaseRegionManager
import java.util.*

class GestionLocalesActivity : AppCompatActivity() {

    // Views principales
    private lateinit var btnTabLocales: Button
    private lateinit var btnTabSupervisores: Button
    private lateinit var layoutContenidoLocales: LinearLayout
    private lateinit var layoutContenidoSupervisores: LinearLayout
    
    // Views de Locales
    private lateinit var btnAgregarLocal: Button
    private lateinit var layoutLocales: LinearLayout
    private lateinit var editTextBuscar: EditText
    
    // Views de Supervisores
    private lateinit var btnAgregarSupervisor: Button
    private lateinit var layoutSupervisores: LinearLayout
    private lateinit var editTextBuscarSupervisores: EditText
    
    // Estado
    private lateinit var txtEstado: TextView
    
    // Firebase (usar FirebaseRegionManager para obtener el Firestore de la región actual)
    private val firestore: FirebaseFirestore
        get() = com.tuapp.inventario.utils.FirebaseRegionManager.getFirestore()
    
    // Datos
    private val locales = mutableListOf<Local>()
    private val localesFiltrados = mutableListOf<Local>()
    private val supervisores = mutableListOf<Supervisor>()
    private val supervisoresFiltrados = mutableListOf<Supervisor>()
    
    // Estado de la aplicación
    private var usuarioActual: UsuarioActual? = null
    private var esUsuarioMaestro = false
    private var esUsuarioAsistente = false // Indica si el usuario actual es asistente (no maestro real)
    private var uidUsuarioActual: String? = null // UID de Firebase Auth del usuario actual
    
    // TextWatchers para poder removerlos en onDestroy
    private var textWatcherLocales: TextWatcher? = null
    private var textWatcherSupervisores: TextWatcher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gestion_locales)

        // Cargar usuario actual y determinar tipo
        cargarUsuarioActual()
        
        initViews()
        setupListeners()
        
        // Configurar marca de agua según modo oscuro
        configurarMarcaDeAgua()
        
        // Cargar datos según el tipo de usuario
        lifecycleScope.launch {
            // Si es supervisor, verificar si es asistente antes de cargar datos
            if (!esUsuarioMaestro && usuarioActual?.rol == "supervisor") {
                val esAsistente = verificarSiEsAsistente()
                if (esAsistente) {
                    // Si es asistente, actualizar la interfaz para mostrar opciones de maestro
                    // Ejecutar en el hilo principal para actualizar la UI
                    runOnUiThread {
                        configurarInterfazSegunUsuario()
                    }
                    // Cargar todos los datos como maestro
                    cargarLocalesSuspend()
                    cargarSupervisoresSuspend()
                } else {
                    // Supervisor normal - solo cargar sus locales asignados
                    cargarLocalesAsignados()
                }
            } else if (esUsuarioMaestro) {
                // Usuario maestro - cargar todos los datos
                cargarLocalesSuspend()
                cargarSupervisoresSuspend()
            } else {
                // Usuario supervisor - solo cargar sus locales asignados
                cargarLocalesAsignados()
            }
        }
    }

    private fun initViews() {
        // Views principales
        btnTabLocales = findViewById(R.id.btnTabLocales)
        btnTabSupervisores = findViewById(R.id.btnTabSupervisores)
        layoutContenidoLocales = findViewById(R.id.layoutContenidoLocales)
        layoutContenidoSupervisores = findViewById(R.id.layoutContenidoSupervisores)
        
        // Views de Locales
        btnAgregarLocal = findViewById(R.id.btnAgregarLocal)
        layoutLocales = findViewById(R.id.layoutLocales)
        editTextBuscar = findViewById(R.id.editTextBuscar)
        
        // Views de Supervisores
        btnAgregarSupervisor = findViewById(R.id.btnAgregarSupervisor)
        layoutSupervisores = findViewById(R.id.layoutSupervisores)
        editTextBuscarSupervisores = findViewById(R.id.editTextBuscarSupervisores)
        
        // Estado
        txtEstado = findViewById(R.id.txtEstado)
        
        // Configurar interfaz según el tipo de usuario
        configurarInterfazSegunUsuario()
    }

    private fun setupListeners() {
        // Listeners de pestañas
        btnTabLocales.setOnClickListener {
            mostrarPestanaLocales()
        }
        
        btnTabSupervisores.setOnClickListener {
            mostrarPestanaSupervisores()
        }
        
        // Listeners de Locales
        btnAgregarLocal.setOnClickListener {
            mostrarDialogoAgregarLocal()
        }
        
        textWatcherLocales = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!isFinishing && !isDestroyed) {
                    filtrarLocales(s.toString())
                }
            }
        }
        editTextBuscar.addTextChangedListener(textWatcherLocales)
        
        // Listeners de Supervisores
        btnAgregarSupervisor.setOnClickListener {
            mostrarDialogoAgregarSupervisor()
        }
        
        textWatcherSupervisores = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!isFinishing && !isDestroyed) {
                    filtrarSupervisores(s.toString())
                }
            }
        }
        editTextBuscarSupervisores.addTextChangedListener(textWatcherSupervisores)
    }

    /**
     * Carga el usuario actual y determina si es maestro o supervisor
     */
    private fun cargarUsuarioActual() {
        val prefs = getSharedPreferences("usuario_actual", MODE_PRIVATE)
        val metodoLogin = prefs.getString("metodoLogin", "")
        
        // 🔧 Si viene desde admin_gestion (acceso desde gestión de locales), restaurar rol original
        if (metodoLogin == "admin_gestion") {
            val rolOriginal = prefs.getString("rolOriginal", "")
            val usuarioOriginal = prefs.getString("usuarioOriginal", "")
            
            Log.d("GestionLocalesActivity", "🔧 Usuario viene desde admin_gestion, restaurando rol original: $rolOriginal")
            
            if (!rolOriginal.isNullOrEmpty()) {
                // Restaurar el rol original
                val editor = prefs.edit()
                editor.putString("rol", rolOriginal)
                
                // Si hay usuario original, restaurarlo también
                if (!usuarioOriginal.isNullOrEmpty()) {
                    editor.putString("usuario", usuarioOriginal)
                }
                
                // Limpiar el flag de método de login para que no se restaure repetidamente
                editor.putString("metodoLogin", "")
                editor.remove("rolOriginal")
                editor.remove("usuarioOriginal")
                editor.apply()
                
                Log.d("GestionLocalesActivity", "✅ Rol restaurado: $rolOriginal")
            }
        }
        
        val rol = prefs.getString("rol", "")
        val localesAsignadosStr = prefs.getString("localesAsignados", "")
        
        val localesAsignados = if (localesAsignadosStr.isNullOrEmpty()) {
            emptyList()
        } else {
            localesAsignadosStr.split(",").filter { it.isNotEmpty() }
        }
        
        usuarioActual = UsuarioActual(
            localId = prefs.getString("localId", "") ?: "",
            localNombre = prefs.getString("localNombre", "") ?: "",
            usuarioId = prefs.getString("usuarioId", "") ?: "",
            usuario = prefs.getString("usuario", "") ?: "",
            rol = rol ?: "",
            localesAsignados = localesAsignados
        )
        
        esUsuarioMaestro = rol == "maestro"
        
        Log.d("GestionLocalesActivity", "Usuario cargado: ${usuarioActual?.usuario}, Rol: ${usuarioActual?.rol}, EsMaestro: $esUsuarioMaestro, LocalesAsignados: ${usuarioActual?.localesAsignados}")
    }
    
    /**
     * Verifica si el supervisor actual es asistente del maestro
     * Retorna true si es asistente, false en caso contrario
     */
    private suspend fun verificarSiEsAsistente(): Boolean {
        return try {
            val auth = FirebaseRegionManager.getFirebaseAuth()
            val currentUser = auth.currentUser
            
            if (currentUser == null) {
                Log.e("GestionLocalesActivity", "❌ No hay usuario autenticado en Firebase Auth")
                return false
            }
            
            val uid = currentUser.uid
            
            // Buscar el supervisor en Firebase usando el UID de Firebase Auth
            val supervisorSnapshot = firestore.collection("supervisores")
                .whereEqualTo("firebaseAuthUid", uid)
                .limit(1)
                .get()
                .await()
            
            if (!supervisorSnapshot.isEmpty) {
                val supervisor = supervisorSnapshot.documents[0].toObject(Supervisor::class.java)
                if (supervisor != null && supervisor.esAsistente) {
                    // Si es asistente, otorgar permisos de maestro
                    esUsuarioMaestro = true
                    esUsuarioAsistente = true
                    uidUsuarioActual = uid
                    Log.d("GestionLocalesActivity", "✅ Supervisor es asistente - otorgando permisos de maestro")
                    return true
                }
            }
            false
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "Error verificando si es asistente", e)
            false
        }
    }
    
    /**
     * Configura la interfaz según el tipo de usuario
     */
    private fun configurarInterfazSegunUsuario() {
        if (esUsuarioMaestro) {
            // Usuario maestro - mostrar ambas pestañas y botón agregar local
            btnTabSupervisores.visibility = android.view.View.VISIBLE
            btnAgregarSupervisor.visibility = android.view.View.VISIBLE
            btnAgregarLocal.visibility = android.view.View.VISIBLE
        } else {
            // Usuario supervisor - solo mostrar pestaña de locales, sin botón agregar local
            btnTabSupervisores.visibility = android.view.View.GONE
            btnAgregarSupervisor.visibility = android.view.View.GONE
            btnAgregarLocal.visibility = android.view.View.GONE
            layoutContenidoSupervisores.visibility = android.view.View.GONE
        }
    }
    
    /**
     * Muestra la pestaña de locales
     */
    private fun mostrarPestanaLocales() {
        layoutContenidoLocales.visibility = android.view.View.VISIBLE
        layoutContenidoSupervisores.visibility = android.view.View.GONE
        
        // Actualizar estilos de botones
        btnTabLocales.setBackgroundResource(R.drawable.tab_selected_background)
        btnTabLocales.setTextColor(resources.getColor(android.R.color.white, null))
        btnTabSupervisores.setBackgroundResource(R.drawable.tab_unselected_background)
        btnTabSupervisores.setTextColor(resources.getColor(R.color.brand_white, null))
    }
    
    /**
     * Muestra la pestaña de supervisores
     */
    private fun mostrarPestanaSupervisores() {
        layoutContenidoLocales.visibility = android.view.View.GONE
        layoutContenidoSupervisores.visibility = android.view.View.VISIBLE
        
        // Actualizar estilos de botones
        btnTabSupervisores.setBackgroundResource(R.drawable.tab_selected_background)
        btnTabSupervisores.setTextColor(resources.getColor(android.R.color.white, null))
        btnTabLocales.setBackgroundResource(R.drawable.tab_unselected_background)
        btnTabLocales.setTextColor(resources.getColor(R.color.brand_white, null))
    }
    
    /**
     * Función suspend para cargar locales de forma síncrona
     */
    private suspend fun cargarLocalesSuspend() {
        try {
            txtEstado.text = "Cargando información de locales..."
            
            // Solo cargar información básica de locales (sin datos de inventario)
            val snapshot = firestore.collection("locales")
                .whereEqualTo("activo", true)
                .get()
                .await()
            
            locales.clear()
            snapshot.documents.forEach { document ->
                val local = document.toObject(Local::class.java)?.copy(id = document.id)
                if (local != null) {
                    // Solo mantener información básica del local para gestión
                    val localBasico = local.copy(
                        usuarios = local.usuarios, // Mantener usuarios para gestión
                        // No cargar datos de inventario aquí
                    )
                    locales.add(localBasico)
                }
            }
            
            Log.d("GestionLocalesActivity", "Información básica de locales cargada: ${locales.size}")
            Log.d("GestionLocalesActivity", "Locales encontrados: ${locales.map { it.nombre }}")
            
            // Mostrar los locales en la interfaz
            mostrarLocales()
            
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "Error cargando locales", e)
            txtEstado.text = "Error cargando locales: ${e.message}"
        }
    }

    private fun cargarLocales() {
        lifecycleScope.launch {
            cargarLocalesSuspend()
            
            // Solo mostrar locales si estamos en la pestaña de locales
            if (layoutContenidoLocales.visibility == android.view.View.VISIBLE) {
                mostrarLocales()
            }
            txtEstado.text = ""
        }
    }
    
    /**
     * Carga todos los supervisores (solo para usuarios maestros)
     */
    private fun cargarSupervisores() {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Cargando supervisores..."
                
                val snapshot = firestore.collection("supervisores")
                    .whereEqualTo("activo", true)
                    .get()
                    .await()
                
                supervisores.clear()
                snapshot.documents.forEach { document ->
                    val supervisor = document.toObject(Supervisor::class.java)?.copy(id = document.id)
                    if (supervisor != null) {
                        supervisores.add(supervisor)
                    }
                }
                
                Log.d("GestionLocalesActivity", "Supervisores cargados: ${supervisores.size}")
                mostrarSupervisores()
                txtEstado.text = ""
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error cargando supervisores", e)
                txtEstado.text = "Error cargando supervisores: ${e.message}"
            }
        }
    }
    
    /**
     * Versión suspend de cargarSupervisores para uso en corrutinas
     */
    private suspend fun cargarSupervisoresSuspend() {
        try {
            txtEstado.text = "Cargando supervisores..."
            
            val snapshot = firestore.collection("supervisores")
                .whereEqualTo("activo", true)
                .get()
                .await()
            
            supervisores.clear()
            snapshot.documents.forEach { document ->
                val supervisor = document.toObject(Supervisor::class.java)?.copy(id = document.id)
                if (supervisor != null) {
                    supervisores.add(supervisor)
                }
            }
            
            Log.d("GestionLocalesActivity", "Supervisores cargados: ${supervisores.size}")
            mostrarSupervisores()
            txtEstado.text = ""
            
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "Error cargando supervisores", e)
            txtEstado.text = "Error cargando supervisores: ${e.message}"
        }
    }
    
    /**
     * Carga solo los locales asignados al supervisor actual
     */
    private fun cargarLocalesAsignados() {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Cargando locales asignados..."
                
                // 🔄 SIEMPRE consultar Firebase para obtener los locales asignados actualizados
                // El maestro puede cambiar los locales asignados en cualquier momento
                val auth = FirebaseRegionManager.getFirebaseAuth()
                val currentUser = auth.currentUser
                
                if (currentUser == null) {
                    Log.e("GestionLocalesActivity", "❌ No hay usuario autenticado en Firebase Auth")
                    txtEstado.text = "Error: No hay usuario autenticado"
                    mostrarLocales()
                    return@launch
                }
                
                val uid = currentUser.uid
                Log.d("GestionLocalesActivity", "🔍 Buscando supervisor con UID: $uid")
                
                // Buscar el supervisor en Firebase usando el UID de Firebase Auth
                val supervisorSnapshot = firestore.collection("supervisores")
                    .whereEqualTo("firebaseAuthUid", uid)
                    .limit(1)
                    .get()
                    .await()
                
                if (supervisorSnapshot.isEmpty) {
                    Log.w("GestionLocalesActivity", "⚠️ Supervisor no encontrado en Firebase con UID: $uid")
                    txtEstado.text = "Supervisor no encontrado"
                    mostrarLocales()
                    return@launch
                }
                
                val supervisor = supervisorSnapshot.documents[0].toObject(Supervisor::class.java)
                    ?.copy(id = supervisorSnapshot.documents[0].id)
                
                if (supervisor == null) {
                    Log.e("GestionLocalesActivity", "❌ Error parseando supervisor desde Firebase")
                    txtEstado.text = "Error cargando datos del supervisor"
                    mostrarLocales()
                    return@launch
                }
                
                val localesAsignados = supervisor.localesAsignados
                Log.d("GestionLocalesActivity", "✅ Supervisor encontrado: ${supervisor.usuario}")
                Log.d("GestionLocalesActivity", "📋 Locales asignados desde Firebase: $localesAsignados")
                
                // Actualizar usuarioActual con los datos actualizados de Firebase
                usuarioActual = usuarioActual?.copy(localesAsignados = localesAsignados)
                
                if (localesAsignados.isEmpty()) {
                    Log.w("GestionLocalesActivity", "⚠️ El supervisor no tiene locales asignados")
                    txtEstado.text = "No tienes locales asignados"
                    mostrarLocales()
                    return@launch
                }
                
                // Cargar solo los locales asignados desde Firebase
                val snapshot = firestore.collection("locales")
                    .whereEqualTo("activo", true)
                    .get()
                    .await()
                
                Log.d("GestionLocalesActivity", "📦 Total de locales activos en Firebase: ${snapshot.documents.size}")
                
                locales.clear()
                snapshot.documents.forEach { document ->
                    val local = document.toObject(Local::class.java)?.copy(id = document.id)
                    if (local != null) {
                        Log.d("GestionLocalesActivity", "🔍 Verificando local: ${local.id} (nombre: ${local.nombre})")
                        // Comparar tanto por ID como por nombre (por si acaso)
                        if (localesAsignados.contains(local.id) || localesAsignados.contains(local.nombre)) {
                            Log.d("GestionLocalesActivity", "✅ Local ${local.nombre} (${local.id}) agregado a la lista")
                            locales.add(local)
                        }
                    }
                }
                
                Log.d("GestionLocalesActivity", "✅ Locales asignados cargados: ${locales.size} de ${localesAsignados.size} esperados")
                mostrarLocales()
                txtEstado.text = if (locales.isEmpty()) {
                    "No se encontraron los locales asignados en Firebase"
                } else {
                    ""
                }
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error cargando locales asignados", e)
                txtEstado.text = "Error cargando locales asignados: ${e.message}"
            }
        }
    }

    private fun mostrarLocales() {
        layoutLocales.removeAllViews()
        
        // Usar la lista filtrada si hay filtro, sino usar la lista completa
        val listaAMostrar = if (localesFiltrados.isNotEmpty()) localesFiltrados else locales
        
        if (listaAMostrar.isEmpty()) {
            val mensajeVacio = TextView(this).apply {
                text = if (localesFiltrados.isNotEmpty()) "🔍 No se encontraron locales que coincidan con la búsqueda" else "📝 No hay locales registrados"
                textSize = 16f
                setTextColor(resources.getColor(android.R.color.darker_gray, null))
                gravity = android.view.Gravity.CENTER
                setPadding(32, 32, 32, 32)
            }
            layoutLocales.addView(mensajeVacio)
        } else {
            // Mapa para almacenar los badges por localId
            val badgesMap = mutableMapOf<String, TextView>()
            
            // Crear todos los layouts primero y guardar referencias a los badges
            listaAMostrar.forEach { local ->
                val (localLayout, badgeView) = crearLayoutLocalConBadge(local)
                layoutLocales.addView(localLayout)
                badgesMap[local.id] = badgeView
            }
            
            // Solo cargar badges de vencimientos si es maestro o supervisor
            // - Maestro: cargar badges de TODOS los locales mostrados
            // - Supervisor: cargar badges SOLO de los locales asignados que están en la lista
            if (badgesMap.isNotEmpty()) {
                val localesParaCargar = if (esUsuarioMaestro) {
                    // Maestro: cargar todos los locales mostrados
                    badgesMap
                } else {
                    // Supervisor: solo cargar badges de los locales asignados
                    val localesAsignados = usuarioActual?.localesAsignados ?: emptyList()
                    badgesMap.filterKeys { localId -> localId in localesAsignados }
                }
                
                if (localesParaCargar.isNotEmpty()) {
                    cargarBadgesVencimientosParalelo(localesParaCargar)
                }
            }
        }
    }
    
    /**
     * Muestra la lista de supervisores
     */
    private fun mostrarSupervisores() {
        layoutSupervisores.removeAllViews()
        
        // Usar la lista filtrada si hay filtro, sino usar la lista completa
        val listaBase = if (supervisoresFiltrados.isNotEmpty()) supervisoresFiltrados else supervisores
        
        // Si el usuario actual es asistente (no maestro real), filtrar su propia cuenta
        val listaAMostrar = if (esUsuarioAsistente && uidUsuarioActual != null) {
            listaBase.filter { supervisor ->
                supervisor.firebaseAuthUid != uidUsuarioActual
            }
        } else {
            listaBase
        }
        
        if (listaAMostrar.isEmpty()) {
            val mensajeVacio = TextView(this).apply {
                text = if (supervisoresFiltrados.isNotEmpty()) "🔍 No se encontraron supervisores que coincidan con la búsqueda" else "👥 No hay supervisores registrados"
                textSize = 16f
                setTextColor(resources.getColor(android.R.color.darker_gray, null))
                gravity = android.view.Gravity.CENTER
                setPadding(32, 32, 32, 32)
            }
            layoutSupervisores.addView(mensajeVacio)
        } else {
            listaAMostrar.forEach { supervisor ->
                val supervisorLayout = crearLayoutSupervisor(supervisor)
                layoutSupervisores.addView(supervisorLayout)
            }
        }
    }
    
    /**
     * Filtra supervisores por texto de búsqueda
     */
    private fun filtrarSupervisores(texto: String) {
        supervisoresFiltrados.clear()
        
        if (texto.isBlank()) {
            // Si no hay texto de búsqueda, mostrar todos los supervisores
            mostrarSupervisores()
            return
        }
        
        // Filtrar supervisores que contengan el texto de búsqueda
        supervisoresFiltrados.addAll(
            supervisores.filter { supervisor ->
                supervisor.usuario.contains(texto, ignoreCase = true) ||
                supervisor.fechaCreacion.contains(texto, ignoreCase = true) ||
                supervisor.localesAsignados.any { localId ->
                    locales.find { it.id == localId }?.nombre?.contains(texto, ignoreCase = true) == true
                }
            }
        )
        
        mostrarSupervisores()
    }

    /**
     * Crea el layout de un local y retorna también el badge de vencimientos
     */
    private fun crearLayoutLocalConBadge(local: Local): Pair<LinearLayout, TextView> {
        var badgeVencimientosRef: TextView? = null
        
        val layout = crearLayoutLocal(local) { badgeView ->
            badgeVencimientosRef = badgeView
        }
        
        return layout to (badgeVencimientosRef ?: TextView(this))
    }
    
    private fun crearLayoutLocal(local: Local, onBadgeCreated: ((TextView) -> Unit)? = null): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundResource(R.drawable.card_local_background)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 8, 16, 16)
            }
        }
        
        // Layout horizontal para nombre del local + badge de vencimientos
        val nombreLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 8)
        }
        
        // Nombre del local (con posible icono de advertencia)
        val nombreText = TextView(this).apply {
            text = "🏪 ${local.nombre}"
            textSize = 20f
            setTextColor(resources.getColor(android.R.color.black, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }
        nombreLayout.addView(nombreText)
        
        // Badge de vencimientos (se actualizará asíncronamente en paralelo)
        val badgeVencimientos = TextView(this).apply {
            text = ""
            textSize = 12f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(12, 4, 12, 4)
            visibility = View.GONE
            setBackgroundResource(R.drawable.button_gestion_danger)
            isClickable = true
            isFocusable = true
            tag = "badge_vencimientos" // Tag para identificarlo después
            setOnClickListener {
                mostrarPopupVencimientosHoy(local)
            }
        }
        nombreLayout.addView(badgeVencimientos)
        
        // Notificar que el badge fue creado
        onBadgeCreated?.invoke(badgeVencimientos)
        
        layout.addView(nombreLayout)
        
        // Verificar asíncronamente si el local tiene datos en 0 sin el flag
        verificarDatosEnCero(local.id, local.nombre, nombreText)
        
        // NO cargar badge aquí - se cargará en paralelo después de crear todos los layouts
        
        // Fecha de creación
        val fechaText = TextView(this).apply {
            text = "Creado: ${local.fechaCreacion}"
            textSize = 12f
            setTextColor(resources.getColor(android.R.color.black, null))
            setPadding(0, 4, 0, 4)
        }
        layout.addView(fechaText)
        
        // Usuarios
        val usuariosText = TextView(this).apply {
            text = "Usuarios: ${local.usuarios.size}"
            textSize = 12f
            setTextColor(resources.getColor(android.R.color.black, null))
            setPadding(0, 4, 0, 8)
        }
        layout.addView(usuariosText)
        
        // Botón de acceso directo (primera fila)
        val btnAccesoDirecto = Button(this).apply {
            text = "🚀 Ingresar al Local"
            textSize = 14f
            setBackgroundColor(resources.getColor(android.R.color.holo_purple, null))
            setTextColor(resources.getColor(android.R.color.white, null))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 8, 0, 8)
            }
            setOnClickListener {
                ingresarAlLocal(local)
            }
        }
        layout.addView(btnAccesoDirecto)
        
        // Botón Ver Stock y Vencimientos (primera fila)
        val btnVerStock = Button(this).apply {
            text = "📦 Ver Stock y Vencimientos"
            textSize = 14f
            setBackgroundColor(resources.getColor(android.R.color.holo_blue_dark, null))
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 8, 0, 8)
            }
            setOnClickListener {
                abrirStockVencimientos(local)
            }
        }
        layout.addView(btnVerStock)
        
        // Layout para botones de administración
        val botonesLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        // Botón ver credenciales y usuarios (unificado)
        val btnVerCredenciales = Button(this).apply {
            text = "👥 USUARIOS Y CREDENCIALES"
            textSize = 10f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.button_gestion_info)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(0, 0, 4, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                mostrarUsuariosYCredenciales(local)
            }
        }

        // Botón cambiar contraseña
        val btnCambiarcontraseña = Button(this).apply {
            text = "🔑 contraseña"
            textSize = 11f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.button_gestion_success)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(4, 0, 4, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                mostrarDialogoCambiarcontraseña(local)
            }
        }
        
        // Botón eliminar local (solo para usuarios maestros)
        val btnEliminarLocal = Button(this).apply {
            text = "🗑️ ELIMINAR"
            textSize = 11f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.button_gestion_danger)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(4, 0, 0, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                mostrarDialogoEliminarLocal(local)
            }
        }
        
        botonesLayout.addView(btnVerCredenciales)
        botonesLayout.addView(btnCambiarcontraseña)
        
        // Solo mostrar botón eliminar para usuarios maestros
        if (esUsuarioMaestro) {
            botonesLayout.addView(btnEliminarLocal)
        }
        layout.addView(botonesLayout)
        
        return layout
    }
    
    /**
     * Crea el layout para mostrar un supervisor
     */
    private fun crearLayoutSupervisor(supervisor: Supervisor): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundResource(R.drawable.card_local_background)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 8, 16, 16)
            }
        }
        
        // Nombre del supervisor (con indicador de asistente si aplica)
        val nombreText = TextView(this).apply {
            val textoNombre = if (supervisor.esAsistente) {
                "👨‍💼 ${supervisor.usuario} ⭐ ASISTENTE"
            } else {
                "👨‍💼 ${supervisor.usuario}"
            }
            text = textoNombre
            textSize = 20f
            setTextColor(resources.getColor(android.R.color.black, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 8)
        }
        layout.addView(nombreText)
        
        // Fecha de creación
        val fechaText = TextView(this).apply {
            text = "Creado: ${supervisor.fechaCreacion}"
            textSize = 12f
            setTextColor(resources.getColor(android.R.color.black, null))
            setPadding(0, 4, 0, 4)
        }
        layout.addView(fechaText)
        
        // Locales asignados
        val localesAsignadosText = TextView(this).apply {
            val nombresLocales = supervisor.localesAsignados.mapNotNull { localId ->
                locales.find { it.id == localId }?.nombre
            }
            text = "Locales asignados: ${nombresLocales.size} (${nombresLocales.joinToString(", ")})"
            textSize = 12f
            setTextColor(resources.getColor(android.R.color.black, null))
            setPadding(0, 4, 0, 8)
        }
        layout.addView(localesAsignadosText)
        
        // Layout para botones de administración
        val botonesLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        // Botón ver locales asignados
        val btnVerLocales = Button(this).apply {
            text = "🏪 LOCALES"
            textSize = 11f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.button_gestion_info)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(0, 0, 4, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                mostrarLocalesAsignados(supervisor)
            }
        }
        
        // Botón asignar locales
        val btnAsignarLocales = Button(this).apply {
            text = "➕ ASIGNAR"
            textSize = 11f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.button_gestion_success)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(4, 0, 4, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                mostrarDialogoAsignarLocales(supervisor)
            }
        }
        
        // Botón ver contraseña
        val btnVercontraseña = Button(this).apply {
            text = "🔑 contraseña"
            textSize = 11f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.button_gestion_info)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(4, 0, 4, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                mostrarcontraseñaSupervisor(supervisor)
            }
        }
        
        // Botón designar/remover como asistente (solo visible para maestros reales, no asistentes)
        val btnAsistente = Button(this).apply {
            text = if (supervisor.esAsistente) "⭐ QUITAR ASISTENTE" else "⭐ ASISTENTE"
            textSize = 10f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(if (supervisor.esAsistente) R.drawable.button_gestion_warning else R.drawable.button_gestion_success)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(4, 0, 4, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                toggleAsistenteSupervisor(supervisor)
            }
        }
        
        // Botón eliminar supervisor
        val btnEliminarSupervisor = Button(this).apply {
            text = "🗑️ ELIMINAR"
            textSize = 11f
            setTextColor(resources.getColor(android.R.color.white, null))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundResource(R.drawable.button_gestion_danger)
            layoutParams = LinearLayout.LayoutParams(0, 160, 1f).apply {
                setMargins(4, 0, 0, 0)
            }
            setPadding(8, 8, 8, 8)
            setOnClickListener {
                mostrarDialogoEliminarSupervisor(supervisor)
            }
        }
        
        botonesLayout.addView(btnVerLocales)
        botonesLayout.addView(btnAsignarLocales)
        botonesLayout.addView(btnVercontraseña)
        
        // Solo mostrar botón de asistente si es maestro real (no asistente)
        if (!esUsuarioAsistente) {
            botonesLayout.addView(btnAsistente)
        }
        
        botonesLayout.addView(btnEliminarSupervisor)
        layout.addView(botonesLayout)
        
        return layout
    }
    
    /**
     * Muestra los locales asignados a un supervisor
     */
    private fun mostrarLocalesAsignados(supervisor: Supervisor) {
        val nombresLocales = supervisor.localesAsignados.mapNotNull { localId ->
            locales.find { it.id == localId }?.nombre
        }
        
        val mensaje = if (nombresLocales.isEmpty()) {
            "Este supervisor no tiene locales asignados"
        } else {
            "Locales asignados:\n\n" + nombresLocales.joinToString("\n") { "🏪 $it" }
        }
        
        mostrarDialogoPersonalizado(
            icono = "🏪",
            titulo = "Locales de ${supervisor.usuario}",
            contenido = mensaje,
            textoBotonConfirmar = "OK",
            soloConfirmar = true
        )
    }
    
    /**
     * Muestra y permite editar las credenciales del supervisor
     */
    private fun mostrarcontraseñaSupervisor(supervisor: Supervisor) {
        // Si el email tiene el dominio, mostrar solo la parte antes del "@"
        val emailSinDominio = if (supervisor.email.contains("@")) {
            supervisor.email.substringBefore("@")
        } else {
            supervisor.email
        }
        
        val contenido = "Ingresa el email y la nueva contraseña para el supervisor '${supervisor.usuario}'.\n\n⚠️ Si el usuario no existe en Firebase Auth, se creará automáticamente."
        
        val campos = listOf(
            CampoEntrada("email", "Email del supervisor", 
                android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, 
                emailSinDominio, esEmail = true),
            CampoEntrada("nueva", "Nueva contraseña", 
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD),
            CampoEntrada("confirmar", "Confirmar nueva contraseña", 
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
        )
        
        mostrarDialogoPersonalizado(
            icono = "🔑",
            titulo = "Cambiar Credenciales: ${supervisor.usuario}",
            contenido = contenido,
            textoBotonConfirmar = "CAMBIAR",
            soloConfirmar = false,
            camposEntrada = campos
        ) { valores ->
            val email = valores["email"]?.trim() ?: ""
            val contraseñaNueva = valores["nueva"]?.trim() ?: ""
            val confirmarcontraseña = valores["confirmar"]?.trim() ?: ""
            
            if (email.isNotEmpty() && contraseñaNueva.isNotEmpty() && confirmarcontraseña.isNotEmpty()) {
                if (contraseñaNueva == confirmarcontraseña) {
                    cambiarcontraseñaSupervisor(supervisor, email, "", contraseñaNueva)
                } else {
                    txtEstado.text = "Las contraseñas nuevas no coinciden"
                }
            } else {
                txtEstado.text = "Email y nueva contraseña son obligatorios"
            }
        }
    }
    
    /**
     * Muestra el diálogo para crear un nuevo supervisor
     */
    private fun mostrarDialogoAgregarSupervisor() {
        val contenido = "Ingresa los datos del nuevo supervisor:"
        
        val campos = listOf(
            CampoEntrada("usuario", "Nombre de usuario del supervisor"),
            CampoEntrada("email", "Email del supervisor (ej: supervisor)", 
                android.text.InputType.TYPE_CLASS_TEXT,
                esEmail = true),
            CampoEntrada("contraseña", "contraseña del supervisor", 
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
        )
        
        mostrarDialogoPersonalizado(
            icono = "➕",
            titulo = "Agregar Nuevo Supervisor",
            contenido = contenido,
            textoBotonConfirmar = "CREAR",
            soloConfirmar = false,
            camposEntrada = campos
        ) { valores ->
            val usuarioSupervisor = valores["usuario"]?.trim() ?: ""
            val emailUsuario = valores["email"]?.trim() ?: ""
            val contraseña = valores["contraseña"]?.trim() ?: ""
            
            if (usuarioSupervisor.isEmpty()) {
                txtEstado.text = "El nombre de usuario es obligatorio"
                return@mostrarDialogoPersonalizado
            }
            
            if (emailUsuario.isEmpty()) {
                txtEstado.text = "El email del supervisor es obligatorio"
                return@mostrarDialogoPersonalizado
            }
            
            if (contraseña.isEmpty()) {
                txtEstado.text = "La contraseña es obligatoria"
                return@mostrarDialogoPersonalizado
            }
            
            // Agregar el dominio automáticamente si no lo tiene
            val email = if (emailUsuario.contains("@")) {
                emailUsuario
            } else {
                "$emailUsuario@saboresexpress.com.ar"
            }
            
            if (!email.endsWith("@saboresexpress.com.ar")) {
                txtEstado.text = "El email debe terminar en @saboresexpress.com.ar"
                return@mostrarDialogoPersonalizado
            }
            
            crearNuevoSupervisor(usuarioSupervisor, email, contraseña)
        }
    }
    
    /**
     * Crea un nuevo supervisor
     */
    private fun crearNuevoSupervisor(usuarioSupervisor: String, email: String, contraseña: String) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Creando supervisor $usuarioSupervisor..."
                
                // Verificar si el supervisor ya existe
                val snapshot = firestore.collection("supervisores")
                    .whereEqualTo("usuario", usuarioSupervisor)
                    .get()
                    .await()
                
                if (!snapshot.isEmpty) {
                    txtEstado.text = "El supervisor $usuarioSupervisor ya existe"
                    return@launch
                }
                
                // Verificar si el email ya está en uso
                val snapshotEmail = firestore.collection("supervisores")
                    .whereEqualTo("email", email)
                    .get()
                    .await()
                
                if (!snapshotEmail.isEmpty) {
                    txtEstado.text = "El email $email ya está en uso por otro supervisor"
                    return@launch
                }
                
                // Crear usuario en Firebase Auth
                txtEstado.text = "Creando usuario en Firebase Auth..."
                val auth = FirebaseAuth.getInstance()
                val authResult = try {
                    auth.createUserWithEmailAndPassword(email, contraseña).await()
                } catch (e: FirebaseAuthUserCollisionException) {
                    txtEstado.text = "El email $email ya está registrado en Firebase Auth"
                    return@launch
                } catch (e: Exception) {
                    Log.e("GestionLocalesActivity", "Error creando usuario en Firebase Auth", e)
                    txtEstado.text = "Error creando usuario: ${e.message}"
                    return@launch
                }
                
                val uid = authResult.user?.uid ?: throw Exception("No se pudo obtener el UID del usuario")
                Log.d("GestionLocalesActivity", "✅ Usuario creado en Firebase Auth con UID: $uid")
                
                // Crear el supervisor
                val nuevoSupervisor = Supervisor(
                    usuario = usuarioSupervisor,
                    email = email,
                    contraseña = contraseña, // Se mantiene temporalmente para migración
                    localesAsignados = emptyList(),
                    creadoPor = usuarioActual?.usuarioId ?: "",
                    fechaCreacion = DateHelper.getDateFormat("yyyy-MM-dd").format(Date()),
                    firebaseAuthUid = uid // UID de Firebase Auth
                )
                
                // Guardar en Firebase
                val docRef = firestore.collection("supervisores").document()
                docRef.set(nuevoSupervisor.copy(id = docRef.id)).await()
                
                // Agregar a la lista local
                supervisores.add(nuevoSupervisor.copy(id = docRef.id))
                mostrarSupervisores()
                
                txtEstado.text = "Supervisor $usuarioSupervisor creado exitosamente"
                
                // Mostrar credenciales
                mostrarCredencialesSupervisor(usuarioSupervisor, email, contraseña)
                
                Log.d("GestionLocalesActivity", "Supervisor $usuarioSupervisor creado exitosamente con email: $email")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error creando supervisor", e)
                txtEstado.text = "Error creando supervisor: ${e.message}"
            }
        }
    }
    
    /**
     * Muestra las credenciales del supervisor creado
     */
    private fun mostrarCredencialesSupervisor(usuarioSupervisor: String, email: String, contraseña: String) {
        val mensaje = """
            🎉 Supervisor creado exitosamente!
            
            👤 Usuario: $usuarioSupervisor
            📧 Email: $email
            🔑 contraseña: $contraseña
            
            ⚠️ Guarda estas credenciales para que el supervisor pueda acceder
            Usa el email y contraseña para iniciar sesión
        """.trimIndent()
        
        AlertDialog.Builder(this)
            .setTitle("Supervisor Creado")
            .setMessage(mensaje)
            .setPositiveButton("OK") { _, _ ->
                // Recargar la lista de supervisores
                cargarSupervisores()
            }
            .setCancelable(false)
            .show()
    }
    
    /**
     * Cambia las credenciales del supervisor (email y contraseña) en Firestore y Firebase Auth
     */
    private fun cambiarcontraseñaSupervisor(supervisor: Supervisor, email: String, contraseñaActual: String, contraseñaNueva: String) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Verificando datos..."
                
                // Verificar contraseña actual solo si se proporcionó
                if (contraseñaActual.isNotEmpty() && supervisor.contraseña != contraseñaActual) {
                    txtEstado.text = "❌ contraseña actual incorrecta"
                    return@launch
                }
                
                // Validar nueva contraseña
                if (contraseñaNueva.length < 4) {
                    txtEstado.text = "La nueva contraseña debe tener al menos 4 caracteres"
                    return@launch
                }
                
                // Validar email
                if (email.isEmpty() || !email.contains("@")) {
                    txtEstado.text = "El email debe ser válido"
                    return@launch
                }
                
                val auth = FirebaseAuth.getInstance()
                var firebaseAuthUidActualizado = supervisor.firebaseAuthUid
                
                // Gestionar Firebase Auth
                txtEstado.text = "Gestionando usuario en Firebase Auth..."
                
                try {
                    // Si no tiene firebaseAuthUid o el usuario no existe, crear uno nuevo
                    if (supervisor.firebaseAuthUid.isNullOrEmpty()) {
                        Log.d("GestionLocalesActivity", "🔨 Creando nuevo usuario en Firebase Auth...")
                        try {
                            val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                            firebaseAuthUidActualizado = authResult.user?.uid
                            Log.d("GestionLocalesActivity", "✅ Usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                        } catch (e: FirebaseAuthWeakPasswordException) {
                            Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e)
                            txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                            return@launch
                        }
                    } else {
                        // Intentar actualizar usuario existente
                        try {
                            val user = auth.currentUser
                            
                            // Si el usuario actual no es el del supervisor, intentar autenticarnos como ese usuario
                            if (user?.uid != supervisor.firebaseAuthUid) {
                                val emailActual = supervisor.email
                                val contraseñaParaAuth = if (contraseñaActual.isNotEmpty()) {
                                    contraseñaActual
                                } else {
                                    // Si no se proporcionó contraseña actual, intentar con la que está en Firestore
                                    supervisor.contraseña
                                }
                                
                                if (emailActual.isNotEmpty() && contraseñaParaAuth.isNotEmpty()) {
                                    try {
                                        auth.signInWithEmailAndPassword(emailActual, contraseñaParaAuth).await()
                                    } catch (e: Exception) {
                                        Log.w("GestionLocalesActivity", "⚠️ No se pudo autenticar con contraseña actual, intentando crear nuevo usuario")
                                        // Si no se puede autenticar, crear un nuevo usuario
                                        try {
                                            val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                                            firebaseAuthUidActualizado = authResult.user?.uid
                                            Log.d("GestionLocalesActivity", "✅ Nuevo usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                                        } catch (e2: FirebaseAuthWeakPasswordException) {
                                            Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e2)
                                            txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                            return@launch
                                        }
                                    }
                                }
                            }
                            
                            val currentUser = auth.currentUser
                            if (currentUser != null && currentUser.uid == supervisor.firebaseAuthUid) {
                                // Actualizar email si cambió
                                if (email != supervisor.email) {
                                    try {
                                        currentUser.updateEmail(email).await()
                                        Log.d("GestionLocalesActivity", "✅ Email actualizado en Firebase Auth: $email")
                                    } catch (e: Exception) {
                                        Log.e("GestionLocalesActivity", "Error actualizando email", e)
                                        throw e
                                    }
                                }
                                
                                // Actualizar contraseña
                                try {
                                    currentUser.updatePassword(contraseñaNueva).await()
                                    Log.d("GestionLocalesActivity", "✅ contraseña actualizada en Firebase Auth")
                                } catch (e: FirebaseAuthWeakPasswordException) {
                                    Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e)
                                    txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                    return@launch
                                }
                            } else if (currentUser == null || currentUser.uid != supervisor.firebaseAuthUid) {
                                // Si no se pudo autenticar, crear nuevo usuario
                                Log.d("GestionLocalesActivity", "🔨 Creando nuevo usuario en Firebase Auth (no se pudo actualizar existente)...")
                                try {
                                    val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                                    firebaseAuthUidActualizado = authResult.user?.uid
                                    Log.d("GestionLocalesActivity", "✅ Nuevo usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                                } catch (e: FirebaseAuthWeakPasswordException) {
                                    Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e)
                                    txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                    return@launch
                                }
                            }
                        } catch (e: FirebaseAuthUserCollisionException) {
                            // El email ya está en uso, intentar autenticarnos con ese email
                            Log.w("GestionLocalesActivity", "⚠️ Email ya existe en Firebase Auth, intentando autenticar...")
                            try {
                                val contraseñaParaAuth = if (contraseñaActual.isNotEmpty()) {
                                    contraseñaActual
                                } else {
                                    supervisor.contraseña
                                }
                                if (contraseñaParaAuth.isNotEmpty()) {
                                    auth.signInWithEmailAndPassword(email, contraseñaParaAuth).await()
                                    val currentUser = auth.currentUser
                                    if (currentUser != null) {
                                        try {
                                            currentUser.updatePassword(contraseñaNueva).await()
                                            firebaseAuthUidActualizado = currentUser.uid
                                            Log.d("GestionLocalesActivity", "✅ contraseña actualizada en Firebase Auth")
                                        } catch (e2: FirebaseAuthWeakPasswordException) {
                                            Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e2)
                                            txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                            return@launch
                                        }
                                    }
                                }
                            } catch (e2: Exception) {
                                Log.e("GestionLocalesActivity", "Error autenticando con email existente", e2)
                                throw e // Re-lanzar el error original
                            }
                        } catch (e: Exception) {
                            Log.e("GestionLocalesActivity", "Error actualizando Firebase Auth, intentando crear nuevo usuario", e)
                            // Si falla la actualización, intentar crear nuevo usuario
                            try {
                                val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                                firebaseAuthUidActualizado = authResult.user?.uid
                                Log.d("GestionLocalesActivity", "✅ Nuevo usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                            } catch (e2: FirebaseAuthWeakPasswordException) {
                                Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e2)
                                txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                return@launch
                            } catch (e2: Exception) {
                                Log.e("GestionLocalesActivity", "Error creando nuevo usuario en Firebase Auth", e2)
                                throw e2
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("GestionLocalesActivity", "Error gestionando Firebase Auth", e)
                    txtEstado.text = "⚠️ Advertencia: Error gestionando Firebase Auth: ${e.message}. Se actualizará en Firestore."
                }
                
                txtEstado.text = "Actualizando credenciales en Firestore..."
                
                // Crear supervisor actualizado con nuevo email y contraseña
                val supervisorActualizado = supervisor.copy(
                    email = email,
                    contraseña = contraseñaNueva,
                    firebaseAuthUid = firebaseAuthUidActualizado
                )
                
                // Guardar en Firebase
                firestore.collection("supervisores").document(supervisor.id).set(supervisorActualizado).await()
                
                // Actualizar en la lista local
                val indice = supervisores.indexOfFirst { it.id == supervisor.id }
                if (indice != -1) {
                    supervisores[indice] = supervisorActualizado
                    mostrarSupervisores()
                }
                
                txtEstado.text = "✅ Credenciales actualizadas exitosamente"
                
                // Mostrar confirmación
                val mensajeConfirmacion = if (firebaseAuthUidActualizado != null) {
                    "Las credenciales del supervisor '${supervisor.usuario}' han sido actualizadas exitosamente.\n\nEmail: $email\n\n✅ Usuario sincronizado con Firebase Auth"
                } else {
                    "Las credenciales del supervisor '${supervisor.usuario}' han sido actualizadas exitosamente.\n\nEmail: $email\n\n⚠️ Usuario actualizado solo en Firestore"
                }
                
                AlertDialog.Builder(this@GestionLocalesActivity)
                    .setTitle("✅ Credenciales Actualizadas")
                    .setMessage(mensajeConfirmacion)
                    .setPositiveButton("OK", null)
                    .show()
                
                Log.d("GestionLocalesActivity", "Credenciales del supervisor ${supervisor.usuario} actualizadas exitosamente")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error cambiando credenciales del supervisor", e)
                txtEstado.text = "Error cambiando credenciales: ${e.message}"
            }
        }
    }
    
    /**
     * Muestra el diálogo para asignar locales a un supervisor
     */
    private fun mostrarDialogoAsignarLocales(supervisor: Supervisor) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Cargando locales disponibles..."
                
                // Siempre recargar locales para asegurar datos actualizados
                Log.d("GestionLocalesActivity", "Recargando locales para asignación...")
                cargarLocalesSuspend()
                
                Log.d("GestionLocalesActivity", "Locales disponibles para asignación: ${locales.size}")
                Log.d("GestionLocalesActivity", "Nombres de locales: ${locales.map { it.nombre }}")
                
                // Separar locales en asignados y no asignados
                val localesAsignados = locales.filter { supervisor.localesAsignados.contains(it.id) }
                val localesNoAsignados = locales.filter { !supervisor.localesAsignados.contains(it.id) }
                
                // Crear layout principal con ScrollView
                val layoutPrincipal = LinearLayout(this@GestionLocalesActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT
                    )
                    setPadding(16, 16, 16, 16)
                    setBackgroundColor(resources.getColor(R.color.background_color, null))
                }
                
                // Título
                val titulo = TextView(this@GestionLocalesActivity).apply {
                    text = "Asignar Locales a ${supervisor.usuario}"
                    textSize = 16f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(resources.getColor(android.R.color.black, null))
                    setPadding(0, 0, 0, 8)
                }
                layoutPrincipal.addView(titulo)
                
                // Mensaje informativo
                val mensajeInfo = TextView(this@GestionLocalesActivity).apply {
                    text = "ℹ️ Los locales pueden estar asignados a múltiples supervisores simultáneamente."
                    textSize = 12f
                    setTextColor(resources.getColor(android.R.color.darker_gray, null))
                    setPadding(0, 0, 0, 16)
                }
                layoutPrincipal.addView(mensajeInfo)
                
                // Layout para las dos secciones (horizontal split)
                val layoutSecciones = LinearLayout(this@GestionLocalesActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                    ).apply {
                        weightSum = 2f
                    }
                }
                
                val checkboxes = mutableMapOf<String, android.widget.CheckBox>()
                
                if (locales.isEmpty()) {
                    val mensajeVacio = TextView(this@GestionLocalesActivity).apply {
                        text = "❌ No hay locales disponibles para asignar\n\nVerifica que existan locales activos en Firebase"
                        textSize = 14f
                        setTextColor(resources.getColor(android.R.color.holo_red_dark, null))
                        gravity = android.view.Gravity.CENTER
                        setPadding(0, 16, 0, 16)
                    }
                    layoutPrincipal.addView(mensajeVacio)
                    
                    Log.e("GestionLocalesActivity", "ERROR: No se encontraron locales para asignar")
                } else {
                    // Agregar el layout de secciones solo cuando hay locales
                    // SECCIÓN 1: Locales Asignados
                    val layoutAsignados = LinearLayout(this@GestionLocalesActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            1f
                        ).apply {
                            setMargins(0, 0, 8, 0)
                        }
                        setPadding(12, 12, 12, 12)
                        setBackgroundColor(resources.getColor(R.color.brand_gold_light, null))
                    }
                    
                    val tituloAsignados = TextView(this@GestionLocalesActivity).apply {
                        text = "✅ Locales Asignados (${localesAsignados.size})"
                        textSize = 14f
                        setTypeface(null, android.graphics.Typeface.BOLD)
                        setTextColor(resources.getColor(android.R.color.holo_green_dark, null))
                        setPadding(0, 0, 0, 8)
                    }
                    layoutAsignados.addView(tituloAsignados)
                    
                    val scrollAsignados = android.widget.ScrollView(this@GestionLocalesActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            0,
                            1f
                        )
                    }
                    
                    val contenidoAsignados = LinearLayout(this@GestionLocalesActivity).apply {
                        orientation = LinearLayout.VERTICAL
                    }
                    
                    if (localesAsignados.isEmpty()) {
                        val mensajeVacioAsignados = TextView(this@GestionLocalesActivity).apply {
                            text = "No hay locales asignados"
                            textSize = 12f
                            setTextColor(resources.getColor(android.R.color.darker_gray, null))
                            gravity = android.view.Gravity.CENTER
                            setPadding(0, 16, 0, 16)
                        }
                        contenidoAsignados.addView(mensajeVacioAsignados)
                    } else {
                        localesAsignados.forEach { local ->
                            // Verificar si el local está asignado a otros supervisores
                            val otrosSupervisores = supervisores.filter { 
                                it.id != supervisor.id && it.localesAsignados.contains(local.id) 
                            }
                            
                            val textoLocal = if (otrosSupervisores.isNotEmpty()) {
                                "🏪 ${local.nombre}\n📋 También: ${otrosSupervisores.joinToString(", ") { it.usuario }}"
                            } else {
                                "🏪 ${local.nombre}"
                            }
                            
                            val checkbox = android.widget.CheckBox(this@GestionLocalesActivity).apply {
                                text = textoLocal
                                isChecked = true
                                textSize = 12f
                                setPadding(0, 4, 0, 4)
                                
                                // Cambiar color si está asignado a otros supervisores
                                if (otrosSupervisores.isNotEmpty()) {
                                    setTextColor(resources.getColor(android.R.color.holo_orange_dark, null))
                                }
                            }
                            contenidoAsignados.addView(checkbox)
                            checkboxes[local.id] = checkbox
                        }
                    }
                    
                    scrollAsignados.addView(contenidoAsignados)
                    layoutAsignados.addView(scrollAsignados)
                    
                    // SECCIÓN 2: Locales No Asignados
                    val layoutNoAsignados = LinearLayout(this@GestionLocalesActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            1f
                        ).apply {
                            setMargins(8, 0, 0, 0)
                        }
                        setPadding(12, 12, 12, 12)
                        setBackgroundColor(resources.getColor(R.color.brand_grey_light, null))
                    }
                    
                    val tituloNoAsignados = TextView(this@GestionLocalesActivity).apply {
                        text = "➕ Locales Disponibles (${localesNoAsignados.size})"
                        textSize = 14f
                        setTypeface(null, android.graphics.Typeface.BOLD)
                        setTextColor(resources.getColor(android.R.color.holo_blue_dark, null))
                        setPadding(0, 0, 0, 8)
                    }
                    layoutNoAsignados.addView(tituloNoAsignados)
                    
                    val scrollNoAsignados = android.widget.ScrollView(this@GestionLocalesActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            0,
                            1f
                        )
                    }
                    
                    val contenidoNoAsignados = LinearLayout(this@GestionLocalesActivity).apply {
                        orientation = LinearLayout.VERTICAL
                    }
                    
                    if (localesNoAsignados.isEmpty()) {
                        val mensajeVacioNoAsignados = TextView(this@GestionLocalesActivity).apply {
                            text = "Todos los locales están asignados"
                            textSize = 12f
                            setTextColor(resources.getColor(android.R.color.darker_gray, null))
                            gravity = android.view.Gravity.CENTER
                            setPadding(0, 16, 0, 16)
                        }
                        contenidoNoAsignados.addView(mensajeVacioNoAsignados)
                    } else {
                        localesNoAsignados.forEach { local ->
                            // Verificar si el local está asignado a otros supervisores
                            val otrosSupervisores = supervisores.filter { 
                                it.id != supervisor.id && it.localesAsignados.contains(local.id) 
                            }
                            
                            val textoLocal = if (otrosSupervisores.isNotEmpty()) {
                                "🏪 ${local.nombre}\n📋 Asignado a: ${otrosSupervisores.joinToString(", ") { it.usuario }}"
                            } else {
                                "🏪 ${local.nombre}"
                            }
                            
                            val checkbox = android.widget.CheckBox(this@GestionLocalesActivity).apply {
                                text = textoLocal
                                isChecked = false
                                textSize = 12f
                                setPadding(0, 4, 0, 4)
                                
                                // Cambiar color si está asignado a otros supervisores
                                if (otrosSupervisores.isNotEmpty()) {
                                    setTextColor(resources.getColor(android.R.color.holo_orange_dark, null))
                                }
                            }
                            contenidoNoAsignados.addView(checkbox)
                            checkboxes[local.id] = checkbox
                        }
                    }
                    
                    scrollNoAsignados.addView(contenidoNoAsignados)
                    layoutNoAsignados.addView(scrollNoAsignados)
                    
                    // Agregar ambas secciones al layout horizontal
                    layoutSecciones.addView(layoutAsignados)
                    layoutSecciones.addView(layoutNoAsignados)
                    
                    // Agregar el layout de secciones al layout principal
                    layoutPrincipal.addView(layoutSecciones)
                }
                
                // Crear el diálogo DESPUÉS de crear el layout
                val dialog = AlertDialog.Builder(this@GestionLocalesActivity)
                    .setTitle("Asignar Locales")
                    .setView(layoutPrincipal)
                    .setCancelable(false)
                    .setPositiveButton("ASIGNAR", null) // Se configurará después
                    .setNegativeButton("Cancelar", null)
                    .create()
                
                // Configurar los botones después de crear el diálogo para que siempre sean visibles
                dialog.setOnShowListener {
                    val btnAsignar = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    btnAsignar.setOnClickListener {
                        val localesSeleccionados = checkboxes.filter { it.value.isChecked }.keys.toList()
                        asignarLocalesASupervisor(supervisor, localesSeleccionados)
                        dialog.dismiss()
                    }
                    
                    val btnCancelar = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                    btnCancelar.setOnClickListener {
                        dialog.dismiss()
                    }
                }
                
                dialog.show()
                
                // Ajustar el tamaño del diálogo para que ocupe más espacio
                val window = dialog.window
                window?.setLayout(
                    (resources.displayMetrics.widthPixels * 0.9).toInt(),
                    (resources.displayMetrics.heightPixels * 0.8).toInt()
                )
                
                txtEstado.text = ""
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error mostrando diálogo de asignación", e)
                txtEstado.text = "Error cargando locales: ${e.message}"
            }
        }
    }
    
    /**
     * Asigna locales a un supervisor
     */
    private fun asignarLocalesASupervisor(supervisor: Supervisor, localesAsignados: List<String>) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Asignando locales a ${supervisor.usuario}..."
                
                val supervisorActualizado = supervisor.copy(localesAsignados = localesAsignados)
                
                // Actualizar en Firebase
                firestore.collection("supervisores").document(supervisor.id).set(supervisorActualizado).await()
                
                // Actualizar en la lista local
                val indice = supervisores.indexOfFirst { it.id == supervisor.id }
                if (indice != -1) {
                    supervisores[indice] = supervisorActualizado
                    mostrarSupervisores()
                }
                
                txtEstado.text = "Locales asignados exitosamente"
                
                Log.d("GestionLocalesActivity", "Locales asignados a ${supervisor.usuario}: ${localesAsignados.joinToString(", ")}")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error asignando locales", e)
                txtEstado.text = "Error asignando locales: ${e.message}"
            }
        }
    }
    
    /**
     * Cambia el estado de asistente de un supervisor
     */
    private fun toggleAsistenteSupervisor(supervisor: Supervisor) {
        val nuevoEstado = !supervisor.esAsistente
        val accion = if (nuevoEstado) "designar como asistente" else "quitar como asistente"
        val mensaje = if (nuevoEstado) {
            "¿Deseas designar a ${supervisor.usuario} como asistente?\n\n" +
            "⚠️ Como asistente, tendrá acceso completo como el maestro:\n" +
            "• Ver todos los locales\n" +
            "• Ver todos los supervisores\n" +
            "• Gestionar locales y supervisores"
        } else {
            "¿Deseas quitar a ${supervisor.usuario} como asistente?\n\n" +
            "⚠️ Perderá el acceso completo y solo verá sus locales asignados."
        }
        
        AlertDialog.Builder(this)
            .setTitle(if (nuevoEstado) "Designar como Asistente" else "Quitar como Asistente")
            .setMessage(mensaje)
            .setPositiveButton("SÍ, ${if (nuevoEstado) "DESIGNAR" else "QUITAR"}") { _, _ ->
                actualizarEstadoAsistente(supervisor, nuevoEstado)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
    
    /**
     * Actualiza el estado de asistente de un supervisor en Firebase
     */
    private fun actualizarEstadoAsistente(supervisor: Supervisor, esAsistente: Boolean) {
        lifecycleScope.launch {
            try {
                txtEstado.text = if (esAsistente) {
                    "Designando ${supervisor.usuario} como asistente..."
                } else {
                    "Quitando ${supervisor.usuario} como asistente..."
                }
                
                val supervisorActualizado = supervisor.copy(esAsistente = esAsistente)
                
                // Actualizar en Firebase
                firestore.collection("supervisores").document(supervisor.id).set(supervisorActualizado).await()
                
                // Actualizar en la lista local
                val indice = supervisores.indexOfFirst { it.id == supervisor.id }
                if (indice != -1) {
                    supervisores[indice] = supervisorActualizado
                    mostrarSupervisores()
                }
                
                txtEstado.text = if (esAsistente) {
                    "✅ ${supervisor.usuario} ahora es asistente del maestro"
                } else {
                    "✅ Se quitó a ${supervisor.usuario} como asistente"
                }
                
                Log.d("GestionLocalesActivity", "Estado de asistente actualizado para ${supervisor.usuario}: $esAsistente")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error actualizando estado de asistente", e)
                txtEstado.text = "Error actualizando estado: ${e.message}"
            }
        }
    }
    
    /**
     * Muestra el diálogo para eliminar un supervisor
     */
    private fun mostrarDialogoEliminarSupervisor(supervisor: Supervisor) {
        val contenido = "⚠️ ADVERTENCIA: Esta acción eliminará permanentemente el supervisor.\n\n¿Estás seguro de que quieres eliminar a ${supervisor.usuario}?"
        
        AlertDialog.Builder(this)
            .setTitle("Eliminar Supervisor")
            .setMessage(contenido)
            .setPositiveButton("SÍ, ELIMINAR") { _, _ ->
                eliminarSupervisor(supervisor)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
    
    /**
     * Elimina un supervisor
     */
    private fun eliminarSupervisor(supervisor: Supervisor) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Eliminando supervisor ${supervisor.usuario}..."
                
                // Si tiene firebaseAuthUid, DEBE eliminarse de Firebase Auth primero
                if (!supervisor.firebaseAuthUid.isNullOrEmpty()) {
                    try {
                        // Intentar eliminar usando Firebase Functions (HTTP callable)
                        val functions = Firebase.functions
                        val deleteUser = functions.getHttpsCallable("deleteUser")
                        val data = hashMapOf("uid" to supervisor.firebaseAuthUid)
                        val result = deleteUser.call(data).await()
                        
                        Log.d("GestionLocalesActivity", "✅ Usuario de Firebase Auth eliminado: ${supervisor.firebaseAuthUid}")
                        
                    } catch (e: Exception) {
                        // Si no se puede eliminar de Firebase Auth, NO eliminar de Firestore
                        Log.e("GestionLocalesActivity", "❌ No se pudo eliminar usuario de Firebase Auth: ${e.message}")
                        txtEstado.text = "Error: No se pudo eliminar el usuario de Firebase Auth. El supervisor no fue eliminado."
                        return@launch
                    }
                }
                
                // Solo eliminar de Firestore si se pudo eliminar de Firebase Auth (o si no tenía firebaseAuthUid)
                firestore.collection("supervisores").document(supervisor.id).delete().await()
                
                // Remover de la lista local
                supervisores.removeAll { it.id == supervisor.id }
                mostrarSupervisores()
                
                txtEstado.text = "✅ Supervisor '${supervisor.usuario}' eliminado exitosamente"
                Log.d("GestionLocalesActivity", "Supervisor ${supervisor.usuario} eliminado exitosamente")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error eliminando supervisor", e)
                txtEstado.text = "Error eliminando supervisor: ${e.message}"
            }
        }
    }

    /**
     * Muestra las credenciales de Firebase Auth del local
     * Si no tiene firebaseAuthUid, muestra mensaje indicando que necesita generarlos
     */
    private fun mostrarUsuariosYCredenciales(local: Local) {
        lifecycleScope.launch {
            try {
                val usuarioAdmin = local.usuarios.values.find { it.rol == "admin_local" }
                
                // Verificar si tiene datos en Firebase Auth (en el local o en el usuario admin)
                val tieneFirebaseAuth = !local.firebaseAuthUid.isNullOrEmpty() || !usuarioAdmin?.firebaseAuthUid.isNullOrEmpty()
                
                val mensaje = if (!tieneFirebaseAuth) {
                    // No tiene datos en Firebase Auth
                    buildString {
                        append("🏪 ${local.nombre}\n\n")
                        append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")
                        append("⚠️ CREDENCIALES DE FIREBASE AUTH\n")
                        append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n")
                        append("❌ No se encontraron datos en Firebase Auth para este local.\n\n")
                        append("📋 Para generar las credenciales en Firebase Auth:\n")
                        append("   1. Haz clic en '🔑 CAMBIAR CREDENCIALES'\n")
                        append("   2. Ingresa el email y la nueva contraseña\n")
                        append("   3. El sistema creará automáticamente el usuario en Firebase Auth\n\n")
                        append("ℹ️ Las credenciales de Firebase Auth son necesarias para:\n")
                        append("   • Iniciar sesión en la aplicación\n")
                        append("   • Sincronización con Firestore\n")
                        append("   • Autenticación segura\n")
                    }
                } else {
                    // Tiene datos en Firebase Auth - mostrar email de Firestore
                    // Si hay firebaseAuthUid, significa que las credenciales están generadas en Firebase Auth
                    val firebaseAuthUid = local.firebaseAuthUid ?: usuarioAdmin?.firebaseAuthUid ?: ""
                    // El email está en local.email, no en usuarioAdmin.email
                    val emailFirestore = local.email.ifEmpty { usuarioAdmin?.email ?: "" }
                    val contraseñaFirestore = usuarioAdmin?.contraseña ?: ""
                    
                    // Si hay firebaseAuthUid, las credenciales están generadas (el UID solo existe si el usuario está en Firebase Auth)
                    val credencialesGeneradas = firebaseAuthUid.isNotEmpty()
                    
                    buildString {
                        append("🏪 ${local.nombre}\n")
                        append("🔑 Firebase Auth UID: ${firebaseAuthUid}\n\n")
                        append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")
                        append("✅ CREDENCIALES DE FIREBASE AUTH\n")
                        append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n")
                        if (usuarioAdmin != null) {
                            append("👤 Administrador: ${usuarioAdmin.usuario}\n")
                            append("🔑 Firebase Auth UID: ${usuarioAdmin.firebaseAuthUid ?: firebaseAuthUid}\n\n")
                            
                            // Siempre mostrar el email de Firestore (está en local.email)
                            if (emailFirestore.isNotEmpty()) {
                                append("📧 Email (Firestore): ${emailFirestore}\n")
                            } else {
                                append("📧 Email (Firestore): —\n")
                            }
                            
                            if (credencialesGeneradas) {
                                // Credenciales generadas - mostrar contraseña oculta
                                if (contraseñaFirestore.isNotEmpty()) {
                                    append("🔑 contraseña (Firebase Auth): ${"*".repeat(contraseñaFirestore.length.coerceAtLeast(8))}\n\n")
                                } else {
                                    append("🔑 contraseña (Firebase Auth): —\n\n")
                                }
                                append("✅ Las credenciales de acceso están generadas en Firebase Auth.\n")
                                append("ℹ️ Usa estas credenciales para iniciar sesión en la aplicación.\n\n")
                            } else {
                                // Credenciales no generadas
                                append("🔑 contraseña (Firebase Auth): —\n\n")
                                append("⚠️ Las credenciales de acceso NO están generadas en Firebase Auth.\n\n")
                                append("📋 Para generar las credenciales en Firebase Auth:\n")
                                append("   1. Haz clic en '🔑 CAMBIAR CREDENCIALES'\n")
                                append("   2. Ingresa el email y la nueva contraseña\n")
                                append("   3. El sistema creará automáticamente el usuario en Firebase Auth\n\n")
                            }
                            
                            append("📋 Para actualizar las credenciales, usa el botón '🔑 CAMBIAR CREDENCIALES'.\n")
                        } else {
                            append("⚠️ No se encontró el usuario administrador.\n")
                        }
                    }
                }
                
                mostrarDialogoPersonalizado(
                    icono = "👥",
                    titulo = "Credenciales Firebase Auth: ${local.nombre}",
                    contenido = mensaje,
                    textoBotonConfirmar = "OK",
                    soloConfirmar = true
                )
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error mostrando credenciales", e)
                txtEstado.text = "Error mostrando credenciales: ${e.message}"
            }
        }
    }

    private fun mostrarDialogoPersonalizado(
        icono: String,
        titulo: String,
        contenido: String,
        textoBotonConfirmar: String = "CONFIRMAR",
        soloConfirmar: Boolean = false,
        camposEntrada: List<CampoEntrada> = emptyList(),
        onConfirmar: ((Map<String, String>) -> Unit)? = null
    ) {
        // Usar layout con EditText predefinidos para evitar problemas de timing
        val dialogView = layoutInflater.inflate(R.layout.dialog_gestion_locales_input, null)
        
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        // Configurar elementos del diálogo
        dialogView.findViewById<TextView>(R.id.iconHeader)?.text = icono
        dialogView.findViewById<TextView>(R.id.titleHeader)?.text = titulo
        dialogView.findViewById<TextView>(R.id.textDescription)?.text = contenido

        // Obtener los EditText del layout
        val editText1 = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.editText1)
        val inputLayout1 = dialogView.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.inputLayout1)
        val editText2 = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.editText2)
        val inputLayout2 = dialogView.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.inputLayout2)
        val editText3 = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.editText3)
        val inputLayout3 = dialogView.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.inputLayout3)
        
        val camposMap = mutableMapOf<String, EditText>()
        val camposEmailMap = mutableMapOf<String, Boolean>() // Mapa para saber qué campos son de email
        var primerEditText: EditText? = null

        // Configurar campos según la cantidad de camposEntrada
        when (camposEntrada.size) {
            0 -> {
                // Sin campos
                inputLayout1?.visibility = android.view.View.GONE
                inputLayout2?.visibility = android.view.View.GONE
            }
            1 -> {
                // Un solo campo
                val campo = camposEntrada[0]
                inputLayout1?.hint = campo.hint
                editText1?.inputType = campo.tipoInput
                if (campo.textoInicial.isNotEmpty()) {
                    editText1?.setText(campo.textoInicial)
                }
                
                // Configurar autocompletado de email si es necesario
                if (campo.esEmail && editText1 != null) {
                    configurarAutocompletadoEmail(editText1, inputLayout1)
                    camposEmailMap[campo.id] = true
                }
                
                camposMap[campo.id] = editText1!!
                primerEditText = editText1
                inputLayout2?.visibility = android.view.View.GONE
                inputLayout3?.visibility = android.view.View.GONE
            }
            2 -> {
                // Dos campos
                val campo1 = camposEntrada[0]
                inputLayout1?.hint = campo1.hint
                editText1?.inputType = campo1.tipoInput
                if (campo1.textoInicial.isNotEmpty()) {
                    editText1?.setText(campo1.textoInicial)
                }
                
                // Configurar autocompletado de email si es necesario
                if (campo1.esEmail && editText1 != null) {
                    configurarAutocompletadoEmail(editText1, inputLayout1)
                }
                
                camposMap[campo1.id] = editText1!!
                primerEditText = editText1
                
                val campo2 = camposEntrada[1]
                inputLayout2?.hint = campo2.hint
                inputLayout2?.visibility = android.view.View.VISIBLE
                editText2?.inputType = campo2.tipoInput
                if (campo2.textoInicial.isNotEmpty()) {
                    editText2?.setText(campo2.textoInicial)
                }
                
                // Configurar autocompletado de email si es necesario
                if (campo2.esEmail && editText2 != null) {
                    configurarAutocompletadoEmail(editText2, inputLayout2)
                }
                
                camposMap[campo2.id] = editText2!!
                inputLayout3?.visibility = android.view.View.GONE
                
                // Configurar navegación entre campos
                editText1?.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_NEXT
                editText1?.setOnEditorActionListener { _, actionId, _ ->
                    if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_NEXT) {
                        editText2?.requestFocus()
                        true
                    } else {
                        false
                    }
                }
            }
            else -> {
                // Dos campos
                val campo1 = camposEntrada[0]
                inputLayout1?.hint = campo1.hint
                editText1?.inputType = campo1.tipoInput
                if (campo1.textoInicial.isNotEmpty()) {
                    editText1?.setText(campo1.textoInicial)
                }
                
                // Configurar autocompletado de email si es necesario
                if (campo1.esEmail && editText1 != null) {
                    configurarAutocompletadoEmail(editText1, inputLayout1)
                    camposEmailMap[campo1.id] = true
                }
                
                camposMap[campo1.id] = editText1!!
                primerEditText = editText1
                
                val campo2 = camposEntrada[1]
                inputLayout2?.hint = campo2.hint
                inputLayout2?.visibility = android.view.View.VISIBLE
                editText2?.inputType = campo2.tipoInput
                if (campo2.textoInicial.isNotEmpty()) {
                    editText2?.setText(campo2.textoInicial)
                }
                
                // Configurar autocompletado de email si es necesario
                if (campo2.esEmail && editText2 != null) {
                    configurarAutocompletadoEmail(editText2, inputLayout2)
                    camposEmailMap[campo2.id] = true
                }
                
                camposMap[campo2.id] = editText2!!
                
                // Tercer campo (si existe)
                if (camposEntrada.size >= 3) {
                    val campo3 = camposEntrada[2]
                    inputLayout3?.hint = campo3.hint
                    inputLayout3?.visibility = android.view.View.VISIBLE
                    editText3?.inputType = campo3.tipoInput
                    if (campo3.textoInicial.isNotEmpty()) {
                        editText3?.setText(campo3.textoInicial)
                    }
                    
                    // Configurar autocompletado de email si es necesario
                    if (campo3.esEmail && editText3 != null) {
                        configurarAutocompletadoEmail(editText3, inputLayout3)
                        camposEmailMap[campo3.id] = true
                    }
                    
                    camposMap[campo3.id] = editText3!!
                    
                    // Configurar navegación entre campos
                    editText1?.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_NEXT
                    editText1?.setOnEditorActionListener { _, actionId, _ ->
                        if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_NEXT) {
                            editText2?.requestFocus()
                            true
                        } else {
                            false
                        }
                    }
                    
                    editText2?.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_NEXT
                    editText2?.setOnEditorActionListener { _, actionId, _ ->
                        if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_NEXT) {
                            editText3?.requestFocus()
                            true
                        } else {
                            false
                        }
                    }
                } else {
                    inputLayout3?.visibility = android.view.View.GONE
                    
                    // Configurar navegación entre campos (solo 2 campos)
                    editText1?.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_NEXT
                    editText1?.setOnEditorActionListener { _, actionId, _ ->
                        if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_NEXT) {
                            editText2?.requestFocus()
                            true
                        } else {
                            false
                        }
                    }
                }
            }
        }

        // Configurar botones
        dialogView.findViewById<Button>(R.id.btnCancel)?.apply {
            if (soloConfirmar) {
                visibility = android.view.View.GONE
            } else {
                setOnClickListener { dialog.dismiss() }
            }
        }

        dialogView.findViewById<Button>(R.id.btnConfirm)?.apply {
            text = textoBotonConfirmar
            setOnClickListener {
                // Obtener valores y agregar dominio automáticamente para campos de email
                val valores = camposMap.mapValues { (campoId, editText) ->
                    var valor = editText.text.toString().trim()
                    // Si es un campo de email y no contiene "@", agregar el dominio automáticamente
                    if (camposEmailMap[campoId] == true && valor.isNotEmpty() && !valor.contains("@")) {
                        valor = "$valor@saboresexpress.com.ar"
                    }
                    valor
                }
                onConfirmar?.invoke(valores)
                dialog.dismiss()
            }
        }

        // Configurar window ANTES de mostrar
        dialog.window?.let { window ->
            @Suppress("DEPRECATION")
            window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        dialog.show()
        
        // Configurar window DESPUÉS de mostrar (importante para que funcione)
        dialog.window?.let { window ->
            @Suppress("DEPRECATION")
            window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or 
                                  android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        
        // Dar foco al primer EditText y mostrar teclado
        primerEditText?.let { editText ->
            editText.post {
                editText.requestFocus()
                editText.isCursorVisible = true
                
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                
                // Múltiples intentos para asegurar que el teclado aparezca
                editText.postDelayed({
                    if (!editText.hasFocus()) {
                        editText.requestFocus()
                    }
                    imm.showSoftInput(editText, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                }, 100)
                
                editText.postDelayed({
                    if (!imm.isActive(editText)) {
                        editText.requestFocus()
                        imm.showSoftInput(editText, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                    }
                }, 300)
            }
        }
    }
    
    /**
     * Configura el autocompletado de email para un EditText
     * Similar a la implementación en LoginActivity
     */
    private fun configurarAutocompletadoEmail(
        editText: com.google.android.material.textfield.TextInputEditText,
        inputLayout: com.google.android.material.textfield.TextInputLayout?
    ) {
        // Configurar suffix text en el TextInputLayout
        inputLayout?.setSuffixText("@saboresexpress.com.ar")
        inputLayout?.setSuffixTextColor(android.content.res.ColorStateList.valueOf(
            android.graphics.Color.parseColor("#757575") // Color gris para el suffix
        ))
        
        // Agregar TextWatcher para prevenir que el usuario escriba "@" o el dominio
        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Si el usuario intenta escribir "@", prevenir que lo escriba
                val texto = s.toString()
                if (texto.contains("@")) {
                    // Remover el "@" y todo lo que venga después
                    val textoLimpio = texto.substringBefore("@")
                    if (editText.text.toString() != textoLimpio) {
                        editText.setText(textoLimpio)
                        editText.setSelection(textoLimpio.length)
                    }
                }
            }
            
            override fun afterTextChanged(s: Editable?) {}
        })
        
        // Agregar filtro para prevenir que se escriba "@" o el dominio
        editText.filters = arrayOf(android.text.InputFilter { source, start, end, dest, dstart, dend ->
            // Si el texto contiene "@" o el dominio, no permitirlo
            val texto = source.toString()
            if (texto.contains("@") || texto.contains("saboresexpress.com.ar")) {
                return@InputFilter ""
            }
            null
        })
    }

    data class CampoEntrada(
        val id: String,
        val hint: String,
        val tipoInput: Int = android.text.InputType.TYPE_CLASS_TEXT,
        val textoInicial: String = "",
        val esEmail: Boolean = false // Flag para indicar si es un campo de email que necesita autocompletado
    )

    private fun mostrarDialogoAgregarLocal() {
        val contenido = "Ingresa los datos del nuevo local:"
        
        val campos = listOf(
            CampoEntrada("nombre", "Nombre del local (ej: WILDE)"),
            CampoEntrada("email", "Email del local (ej: wilde)", 
                android.text.InputType.TYPE_CLASS_TEXT,
                esEmail = true),
            CampoEntrada("contraseña", "contraseña inicial del admin", 
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
        )
        
        mostrarDialogoPersonalizado(
            icono = "➕",
            titulo = "Agregar Nuevo Local",
            contenido = contenido,
            textoBotonConfirmar = "CREAR",
            soloConfirmar = false,
            camposEntrada = campos
        ) { valores ->
            val nombreLocal = valores["nombre"]?.trim() ?: ""
            val emailUsuario = valores["email"]?.trim() ?: ""
            val contraseña = valores["contraseña"]?.trim() ?: ""
            
            if (nombreLocal.isEmpty()) {
                txtEstado.text = "El nombre del local no puede estar vacío"
                return@mostrarDialogoPersonalizado
            }
            
            if (emailUsuario.isEmpty()) {
                txtEstado.text = "El email del local es obligatorio"
                return@mostrarDialogoPersonalizado
            }
            
            // Agregar el dominio automáticamente si no lo tiene
            val email = if (emailUsuario.contains("@")) {
                emailUsuario
            } else {
                "$emailUsuario@saboresexpress.com.ar"
            }
            
            if (!email.endsWith("@saboresexpress.com.ar")) {
                txtEstado.text = "El email debe terminar en @saboresexpress.com.ar"
                return@mostrarDialogoPersonalizado
            }
            
            if (contraseña.isEmpty()) {
                txtEstado.text = "La contraseña es obligatoria"
                return@mostrarDialogoPersonalizado
            }
            
            crearNuevoLocal(nombreLocal, email, contraseña)
        }
    }

    private fun crearNuevoLocal(nombreLocal: String, email: String, contraseña: String) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Creando local $nombreLocal..."
                
                // Verificar si el local ya existe
                val snapshot = firestore.collection("locales")
                    .whereEqualTo("nombre", nombreLocal)
                    .get()
                    .await()
                
                if (!snapshot.isEmpty) {
                    txtEstado.text = "El local $nombreLocal ya existe"
                    return@launch
                }
                
                // Verificar si el email ya está en uso
                val snapshotEmail = firestore.collection("locales")
                    .whereEqualTo("email", email)
                    .get()
                    .await()
                
                if (!snapshotEmail.isEmpty) {
                    txtEstado.text = "El email $email ya está en uso por otro local"
                    return@launch
                }
                
                // Crear usuario en Firebase Auth
                txtEstado.text = "Creando usuario en Firebase Auth..."
                val auth = FirebaseRegionManager.getFirebaseAuth()
                val authResult = try {
                    auth.createUserWithEmailAndPassword(email, contraseña).await()
                } catch (e: FirebaseAuthUserCollisionException) {
                    txtEstado.text = "El email $email ya está registrado en Firebase Auth"
                    return@launch
                } catch (e: Exception) {
                    Log.e("GestionLocalesActivity", "Error creando usuario en Firebase Auth", e)
                    txtEstado.text = "Error creando usuario: ${e.message}"
                    return@launch
                }
                
                val uid = authResult.user?.uid ?: throw Exception("No se pudo obtener el UID del usuario")
                Log.d("GestionLocalesActivity", "✅ Usuario creado en Firebase Auth con UID: $uid")
                
                // Crear usuario admin para el nuevo local (mantener para compatibilidad)
                val usuarioAdmin = UsuarioLocal(
                    id = "admin_${nombreLocal.lowercase()}",
                    usuario = "admin_${nombreLocal.lowercase()}",
                    email = email,
                    contraseña = contraseña, // Se mantiene temporalmente para migración
                    rol = "admin_local",
                    firebaseAuthUid = uid
                )
                
                // Crear el local
                val nuevoLocal = Local(
                    nombre = nombreLocal,
                    email = email,
                    fechaCreacion = DateHelper.getDateFormat("yyyy-MM-dd").format(Date()),
                    activo = true,
                    usuarios = mapOf(usuarioAdmin.id to usuarioAdmin),
                    firebaseAuthUid = uid
                )
                
                // Guardar en Firebase
                val docRef = firestore.collection("locales").document(nombreLocal)
                docRef.set(nuevoLocal).await()
                
                // Agregar a la lista local
                locales.add(nuevoLocal.copy(id = nombreLocal))
                mostrarLocales()
                
                txtEstado.text = "Local $nombreLocal creado exitosamente"
                
                // Mostrar credenciales
                mostrarCredenciales(nombreLocal, usuarioAdmin, email)
                
                Log.d("GestionLocalesActivity", "Local $nombreLocal creado exitosamente con email: $email")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error creando local", e)
                txtEstado.text = "Error creando local: ${e.message}"
            }
        }
    }

    private fun generarcontraseña(): String {
        val caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return (1..8)
            .map { caracteres.random() }
            .joinToString("")
    }

    private fun mostrarCredenciales(nombreLocal: String, usuario: UsuarioLocal, email: String) {
        val mensaje = """
            🎉 Local creado exitosamente!
            
            📍 Local: $nombreLocal
            📧 Email: $email
            🔑 contraseña: ${usuario.contraseña}
            
            ⚠️ Guarda estas credenciales para acceder al local
            Usa el email y contraseña para iniciar sesión
        """.trimIndent()
        
        AlertDialog.Builder(this)
            .setTitle("Local Creado")
            .setMessage(mensaje)
            .setPositiveButton("OK") { _, _ ->
                // Recargar la lista de locales
                cargarLocales()
            }
            .setCancelable(false)
            .show()
    }
    
    private fun mostrarDialogoEliminarLocal(local: Local) {
        val contenido = "⚠️ ADVERTENCIA: Esta acción eliminará permanentemente el local y todos sus datos.\n\nPara confirmar, ingresa la contraseña del local:"
        
        val contraseñaGuardada = obtenercontraseñaGuardada(local.id)
        
        val campos = listOf(
            CampoEntrada("contraseña", "contraseña del local", 
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD,
                contraseñaGuardada)
        )
        
        mostrarDialogoPersonalizado(
            icono = "🗑️",
            titulo = "Eliminar Local: ${local.nombre}",
            contenido = contenido,
            textoBotonConfirmar = "ELIMINAR",
            soloConfirmar = false,
            camposEntrada = campos
        ) { valores ->
            val contraseñaIngresada = valores["contraseña"]?.trim() ?: ""
            
            if (contraseñaIngresada.isNotEmpty()) {
                eliminarLocal(local, contraseñaIngresada)
            } else {
                txtEstado.text = "Debes ingresar la contraseña para eliminar el local"
            }
        }
    }
    
    private fun mostrarDialogoCambiarcontraseña(local: Local) {
        val usuarioAdmin = local.usuarios.values.find { it.rol == "admin_local" }
        val emailAdmin = usuarioAdmin?.email ?: ""
        // Si el email tiene el dominio, mostrar solo la parte antes del "@"
        val emailSinDominio = if (emailAdmin.contains("@")) {
            emailAdmin.substringBefore("@")
        } else {
            emailAdmin
        }
        
        val contenido = "Ingresa el email y la nueva contraseña para el administrador del local '${local.nombre}'.\n\n⚠️ Si el usuario no existe en Firebase Auth, se creará automáticamente."
        
        val campos = listOf(
            CampoEntrada("email", "Email del administrador", 
                android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, 
                emailSinDominio, esEmail = true),
            CampoEntrada("nueva", "Nueva contraseña", 
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD),
            CampoEntrada("confirmar", "Confirmar nueva contraseña", 
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
        )
        
        mostrarDialogoPersonalizado(
            icono = "🔑",
            titulo = "Cambiar Credenciales: ${local.nombre}",
            contenido = contenido,
            textoBotonConfirmar = "CAMBIAR",
            soloConfirmar = false,
            camposEntrada = campos
        ) { valores ->
            val email = valores["email"]?.trim() ?: ""
            val contraseñaNueva = valores["nueva"]?.trim() ?: ""
            val confirmarcontraseña = valores["confirmar"]?.trim() ?: ""
            
            if (email.isNotEmpty() && contraseñaNueva.isNotEmpty() && confirmarcontraseña.isNotEmpty()) {
                if (contraseñaNueva == confirmarcontraseña) {
                    cambiarcontraseña(local, email, "", contraseñaNueva)
                } else {
                    txtEstado.text = "Las contraseñas nuevas no coinciden"
                }
            } else {
                txtEstado.text = "Email y nueva contraseña son obligatorios"
            }
        }
    }
    
    private fun eliminarLocal(local: Local, contraseñaIngresada: String) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Verificando contraseña y eliminando local..."
                
                // Buscar el usuario administrador del local
                val usuarioAdmin = local.usuarios.values.find { it.rol == "admin_local" }
                if (usuarioAdmin == null) {
                    txtEstado.text = "No se encontró el usuario administrador del local"
                    return@launch
                }
                
                // Verificar contraseña
                if (usuarioAdmin.contraseña != contraseñaIngresada) {
                    txtEstado.text = "❌ contraseña incorrecta. No se puede eliminar el local."
                    return@launch
                }
                
                // Guardar contraseña para uso futuro
                guardarcontraseñaLocal(local.id, contraseñaIngresada)
                
                // Mostrar diálogo de confirmación final
                AlertDialog.Builder(this@GestionLocalesActivity)
                    .setTitle("⚠️ Confirmación Final")
                    .setMessage("¿Estás seguro de que quieres eliminar permanentemente el local '${local.nombre}'?\n\nEsta acción NO se puede deshacer.")
                    .setPositiveButton("SÍ, ELIMINAR") { _, _ ->
                        ejecutarEliminacionLocal(local)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error verificando contraseña", e)
                txtEstado.text = "Error verificando contraseña: ${e.message}"
            }
        }
    }
    
    private fun ejecutarEliminacionLocal(local: Local) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Eliminando local ${local.nombre} y todos sus datos..."
                
                // Si tiene firebaseAuthUid, DEBE eliminarse de Firebase Auth primero
                if (!local.firebaseAuthUid.isNullOrEmpty()) {
                    try {
                        // Intentar eliminar usando Firebase Functions (HTTP callable)
                        val functions = Firebase.functions
                        val deleteUser = functions.getHttpsCallable("deleteUser")
                        val data = hashMapOf("uid" to local.firebaseAuthUid)
                        val result = deleteUser.call(data).await()
                        
                        Log.d("GestionLocalesActivity", "✅ Usuario de Firebase Auth del local eliminado: ${local.firebaseAuthUid}")
                        
                    } catch (e: Exception) {
                        // Si no se puede eliminar de Firebase Auth, NO eliminar de Firestore
                        Log.e("GestionLocalesActivity", "❌ No se pudo eliminar usuario de Firebase Auth: ${e.message}")
                        txtEstado.text = "Error: No se pudo eliminar el usuario de Firebase Auth. El local no fue eliminado."
                        return@launch
                    }
                }
                
                // Solo eliminar de Firestore si se pudo eliminar de Firebase Auth (o si no tenía firebaseAuthUid)
                // Eliminar subcolecciones primero
                eliminarSubcolecciones(local.nombre)
                
                // Eliminar el local de Firebase
                firestore.collection("locales").document(local.nombre).delete().await()
                
                // Verificar que todo se eliminó correctamente
                verificarEliminacionCompleta(local.nombre)
                
                // Remover de la lista local
                locales.removeAll { it.id == local.id }
                mostrarLocales()
                
                txtEstado.text = "✅ Local '${local.nombre}' eliminado exitosamente"
                Log.d("GestionLocalesActivity", "Local ${local.nombre} eliminado exitosamente")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error eliminando local", e)
                txtEstado.text = "Error eliminando local: ${e.message}"
            }
        }
    }
    
    /**
     * Eliminar todas las subcolecciones de un local
     */
    private suspend fun eliminarSubcolecciones(nombreLocal: String) {
        try {
            Log.d("GestionLocalesActivity", "Eliminando subcolecciones para local: $nombreLocal")
            
            // Eliminar subcolección de productos
            eliminarSubcoleccion(nombreLocal, "productos")
            
            // Eliminar subcolección de registros
            eliminarSubcoleccion(nombreLocal, "registros")
            
            Log.d("GestionLocalesActivity", "Subcolecciones eliminadas exitosamente para: $nombreLocal")
            
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "Error eliminando subcolecciones para $nombreLocal", e)
            throw e
        }
    }
    
    /**
     * Eliminar una subcolección específica
     */
    private suspend fun eliminarSubcoleccion(nombreLocal: String, subcoleccion: String) {
        try {
            Log.d("GestionLocalesActivity", "Iniciando eliminación de subcolección: $subcoleccion")
            
            // Obtener todos los documentos de la subcolección
            val snapshot = firestore.collection("locales")
                .document(nombreLocal)
                .collection(subcoleccion)
                .get()
                .await()
            
            Log.d("GestionLocalesActivity", "Encontrados ${snapshot.size()} documentos en $subcoleccion")
            
            if (snapshot.isEmpty) {
                Log.d("GestionLocalesActivity", "Subcolección $subcoleccion ya está vacía")
                return
            }
            
            // Eliminar documentos en lotes (Firebase tiene límite de 500 operaciones por batch)
            val documentos = snapshot.documents.toList()
            val lotes = documentos.chunked(500) // Dividir en lotes de máximo 500
            
            for ((indice, lote) in lotes.withIndex()) {
                Log.d("GestionLocalesActivity", "Procesando lote ${indice + 1}/${lotes.size} de $subcoleccion")
                
                val batch = firestore.batch()
                
                // Agregar todos los documentos del lote al batch
                for (document in lote) {
                    batch.delete(document.reference)
                }
                
                // Ejecutar el batch
                batch.commit().await()
                Log.d("GestionLocalesActivity", "Lote ${indice + 1} eliminado: ${lote.size} documentos")
            }
            
            Log.d("GestionLocalesActivity", "✅ Subcolección $subcoleccion eliminada completamente")
            
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "Error eliminando subcolección $subcoleccion", e)
            throw e
        }
    }
    
    /**
     * Verificar que la eliminación fue completa
     */
    private suspend fun verificarEliminacionCompleta(nombreLocal: String) {
        try {
            Log.d("GestionLocalesActivity", "Verificando eliminación completa para: $nombreLocal")
            
            // Verificar que el documento principal no existe
            val documentoExiste = firestore.collection("locales")
                .document(nombreLocal)
                .get()
                .await()
                .exists()
            
            if (documentoExiste) {
                Log.w("GestionLocalesActivity", "⚠️ El documento principal aún existe")
            } else {
                Log.d("GestionLocalesActivity", "✅ Documento principal eliminado")
            }
            
            // Verificar subcolecciones
            val productosSnapshot = firestore.collection("locales")
                .document(nombreLocal)
                .collection("productos")
                .get()
                .await()
            
            val registrosSnapshot = firestore.collection("locales")
                .document(nombreLocal)
                .collection("registros")
                .get()
                .await()
            
            Log.d("GestionLocalesActivity", "Verificación final:")
            Log.d("GestionLocalesActivity", "- Productos restantes: ${productosSnapshot.size()}")
            Log.d("GestionLocalesActivity", "- Registros restantes: ${registrosSnapshot.size()}")
            
            if (productosSnapshot.isEmpty() && registrosSnapshot.isEmpty()) {
                Log.d("GestionLocalesActivity", "✅ Eliminación completa verificada")
            } else {
                Log.w("GestionLocalesActivity", "⚠️ Aún hay datos residuales")
            }
            
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "Error verificando eliminación", e)
        }
    }
    
    private fun cambiarcontraseña(local: Local, email: String, contraseñaActual: String, contraseñaNueva: String) {
        lifecycleScope.launch {
            try {
                txtEstado.text = "Verificando datos..."
                
                // Buscar el usuario administrador del local
                val usuarioAdmin = local.usuarios.values.find { it.rol == "admin_local" }
                if (usuarioAdmin == null) {
                    txtEstado.text = "No se encontró el usuario administrador del local"
                    return@launch
                }
                
                // Verificar contraseña actual solo si se proporcionó
                if (contraseñaActual.isNotEmpty() && usuarioAdmin.contraseña != contraseñaActual) {
                    txtEstado.text = "❌ contraseña actual incorrecta"
                    return@launch
                }
                
                // Guardar contraseña actual para uso futuro (si se proporcionó)
                if (contraseñaActual.isNotEmpty()) {
                    guardarcontraseñaLocal(local.id, contraseñaActual)
                }
                
                // Validar nueva contraseña
                if (contraseñaNueva.length < 4) {
                    txtEstado.text = "La nueva contraseña debe tener al menos 4 caracteres"
                    return@launch
                }
                
                // Validar email
                if (email.isEmpty() || !email.contains("@")) {
                    txtEstado.text = "El email debe ser válido"
                    return@launch
                }
                
                val auth = FirebaseAuth.getInstance()
                var firebaseAuthUidActualizado = local.firebaseAuthUid
                
                // Gestionar Firebase Auth
                txtEstado.text = "Gestionando usuario en Firebase Auth..."
                
                try {
                    // Si no tiene firebaseAuthUid o el usuario no existe, crear uno nuevo
                    if (local.firebaseAuthUid.isNullOrEmpty()) {
                        Log.d("GestionLocalesActivity", "🔨 Creando nuevo usuario en Firebase Auth...")
                        try {
                            val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                            firebaseAuthUidActualizado = authResult.user?.uid
                            Log.d("GestionLocalesActivity", "✅ Usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                        } catch (e: FirebaseAuthWeakPasswordException) {
                            Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e)
                            txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                            return@launch
                        }
                    } else {
                        // Intentar actualizar usuario existente
                        try {
                            val user = auth.currentUser
                            
                            // Si el usuario actual no es el del local, intentar autenticarnos como ese usuario
                            if (user?.uid != local.firebaseAuthUid) {
                                val emailActual = usuarioAdmin.email
                                val contraseñaParaAuth = if (contraseñaActual.isNotEmpty()) {
                                    contraseñaActual
                                } else {
                                    // Si no se proporcionó contraseña actual, intentar con la que está en Firestore
                                    usuarioAdmin.contraseña
                                }
                                
                                if (emailActual.isNotEmpty() && contraseñaParaAuth.isNotEmpty()) {
                                    try {
                                        auth.signInWithEmailAndPassword(emailActual, contraseñaParaAuth).await()
                                    } catch (e: Exception) {
                                        Log.w("GestionLocalesActivity", "⚠️ No se pudo autenticar con contraseña actual, intentando crear nuevo usuario")
                                        // Si no se puede autenticar, crear un nuevo usuario
                                        try {
                                            val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                                            firebaseAuthUidActualizado = authResult.user?.uid
                                            Log.d("GestionLocalesActivity", "✅ Nuevo usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                                        } catch (e2: FirebaseAuthWeakPasswordException) {
                                            Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e2)
                                            txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                            return@launch
                                        }
                                    }
                                }
                            }
                            
                            val currentUser = auth.currentUser
                            if (currentUser != null && currentUser.uid == local.firebaseAuthUid) {
                                // Actualizar email si cambió
                                if (email != usuarioAdmin.email) {
                                    try {
                                        currentUser.updateEmail(email).await()
                                        Log.d("GestionLocalesActivity", "✅ Email actualizado en Firebase Auth: $email")
                                    } catch (e: Exception) {
                                        Log.e("GestionLocalesActivity", "Error actualizando email", e)
                                        throw e
                                    }
                                }
                                
                                // Actualizar contraseña
                                try {
                                    currentUser.updatePassword(contraseñaNueva).await()
                                    Log.d("GestionLocalesActivity", "✅ contraseña actualizada en Firebase Auth")
                                } catch (e: FirebaseAuthWeakPasswordException) {
                                    Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e)
                                    txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                    return@launch
                                }
                            } else if (currentUser == null || currentUser.uid != local.firebaseAuthUid) {
                                // Si no se pudo autenticar, crear nuevo usuario
                                Log.d("GestionLocalesActivity", "🔨 Creando nuevo usuario en Firebase Auth (no se pudo actualizar existente)...")
                                try {
                                    val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                                    firebaseAuthUidActualizado = authResult.user?.uid
                                    Log.d("GestionLocalesActivity", "✅ Nuevo usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                                } catch (e: FirebaseAuthWeakPasswordException) {
                                    Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e)
                                    txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                    return@launch
                                }
                            }
                        } catch (e: FirebaseAuthUserCollisionException) {
                            // El email ya está en uso, intentar autenticarnos con ese email
                            Log.w("GestionLocalesActivity", "⚠️ Email ya existe en Firebase Auth, intentando autenticar...")
                            try {
                                val contraseñaParaAuth = if (contraseñaActual.isNotEmpty()) {
                                    contraseñaActual
                                } else {
                                    usuarioAdmin.contraseña
                                }
                                if (contraseñaParaAuth.isNotEmpty()) {
                                    auth.signInWithEmailAndPassword(email, contraseñaParaAuth).await()
                                    val currentUser = auth.currentUser
                                    if (currentUser != null) {
                                        try {
                                            currentUser.updatePassword(contraseñaNueva).await()
                                            firebaseAuthUidActualizado = currentUser.uid
                                            Log.d("GestionLocalesActivity", "✅ contraseña actualizada en Firebase Auth")
                                        } catch (e3: FirebaseAuthWeakPasswordException) {
                                            Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e3)
                                            txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                            return@launch
                                        }
                                    }
                                }
                            } catch (e2: Exception) {
                                Log.e("GestionLocalesActivity", "Error autenticando con email existente", e2)
                                throw e // Re-lanzar el error original
                            }
                        } catch (e: Exception) {
                            Log.e("GestionLocalesActivity", "Error actualizando Firebase Auth, intentando crear nuevo usuario", e)
                            // Si falla la actualización, intentar crear nuevo usuario
                            try {
                                val authResult = auth.createUserWithEmailAndPassword(email, contraseñaNueva).await()
                                firebaseAuthUidActualizado = authResult.user?.uid
                                Log.d("GestionLocalesActivity", "✅ Nuevo usuario creado en Firebase Auth con UID: $firebaseAuthUidActualizado")
                            } catch (e2: FirebaseAuthWeakPasswordException) {
                                Log.e("GestionLocalesActivity", "❌ contraseña débil rechazada por Firebase Auth", e2)
                                txtEstado.text = "❌ La contraseña es muy débil. Firebase Auth requiere contraseñas más seguras (mínimo 6 caracteres, preferiblemente con letras, números y caracteres especiales)."
                                return@launch
                            } catch (e2: Exception) {
                                Log.e("GestionLocalesActivity", "Error creando nuevo usuario en Firebase Auth", e2)
                                throw e2
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("GestionLocalesActivity", "Error gestionando Firebase Auth", e)
                    txtEstado.text = "⚠️ Advertencia: Error gestionando Firebase Auth: ${e.message}. Se actualizará en Firestore."
                }
                
                txtEstado.text = "Actualizando credenciales en Firestore..."
                
                // Crear usuario actualizado con nuevo email y contraseña
                val usuarioActualizado = usuarioAdmin.copy(
                    email = email,
                    contraseña = contraseñaNueva,
                    firebaseAuthUid = firebaseAuthUidActualizado
                )
                
                // Actualizar el local con el usuario modificado y el nuevo firebaseAuthUid
                val usuariosActualizados = local.usuarios.toMutableMap()
                usuariosActualizados[usuarioAdmin.id] = usuarioActualizado
                
                val localActualizado = local.copy(
                    email = email, // Actualizar email del local también
                    usuarios = usuariosActualizados,
                    firebaseAuthUid = firebaseAuthUidActualizado
                )
                
                // Guardar en Firebase
                firestore.collection("locales").document(local.nombre).set(localActualizado).await()
                
                // Actualizar en la lista local
                val indice = locales.indexOfFirst { it.id == local.id }
                if (indice != -1) {
                    locales[indice] = localActualizado
                    mostrarLocales()
                }
                
                txtEstado.text = "✅ Credenciales actualizadas exitosamente"
                
                // Mostrar confirmación
                val mensajeConfirmacion = if (firebaseAuthUidActualizado != null) {
                    "Las credenciales del local '${local.nombre}' han sido actualizadas exitosamente.\n\nEmail: $email\n\n✅ Usuario sincronizado con Firebase Auth"
                } else {
                    "Las credenciales del local '${local.nombre}' han sido actualizadas exitosamente.\n\nEmail: $email\n\n⚠️ Usuario actualizado solo en Firestore"
                }
                
                AlertDialog.Builder(this@GestionLocalesActivity)
                    .setTitle("✅ Credenciales Actualizadas")
                    .setMessage(mensajeConfirmacion)
                    .setPositiveButton("OK", null)
                    .show()
                
                Log.d("GestionLocalesActivity", "Credenciales del local ${local.nombre} actualizadas exitosamente")
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error cambiando credenciales", e)
                txtEstado.text = "Error cambiando credenciales: ${e.message}"
            }
        }
    }
    
    private fun filtrarLocales(texto: String) {
        localesFiltrados.clear()
        
        if (texto.isBlank()) {
            // Si no hay texto de búsqueda, mostrar todos los locales
            mostrarLocales()
            return
        }
        
        // Filtrar locales que contengan el texto de búsqueda
        localesFiltrados.addAll(
            locales.filter { local ->
                local.nombre.contains(texto, ignoreCase = true) ||
                local.fechaCreacion.contains(texto, ignoreCase = true) ||
                local.usuarios.values.any { usuario ->
                    usuario.usuario.contains(texto, ignoreCase = true) ||
                    usuario.rol.contains(texto, ignoreCase = true)
                }
            }
        )
        
        mostrarLocales()
    }
    
    private fun ingresarAlLocal(local: Local) {
        lifecycleScope.launch {
            try {
                // Buscar el usuario administrador del local para obtener credenciales completas
                val usuarioAdmin = local.usuarios.values.find { it.rol == "admin_local" }
                
                // Guardar datos completos del usuario en SharedPreferences
                val prefs = getSharedPreferences("usuario_actual", MODE_PRIVATE)
                
                // 🔧 IMPORTANTE: Guardar el rol original antes de sobrescribirlo
                val rolOriginal = prefs.getString("rol", "") ?: ""
                val esMaestroOriginal = rolOriginal == "maestro"
                
                val editor = prefs.edit()
                editor.putString("localId", local.id)
                editor.putString("localNombre", local.nombre)
                
                // 🔧 Guardar el rol original del usuario maestro/supervisor para restaurarlo después
                if (esMaestroOriginal) {
                    editor.putString("rolOriginal", "maestro")
                    editor.putString("usuarioOriginal", prefs.getString("usuario", "") ?: "")
                    Log.d("GestionLocalesActivity", "🔧 Guardando rol original: maestro")
                } else if (rolOriginal == "supervisor") {
                    editor.putString("rolOriginal", "supervisor")
                    editor.putString("usuarioOriginal", prefs.getString("usuario", "") ?: "")
                    Log.d("GestionLocalesActivity", "🔧 Guardando rol original: supervisor")
                }
                
                // Si encontramos el usuario admin, guardar sus datos
                if (usuarioAdmin != null) {
                    editor.putString("usuarioId", usuarioAdmin.id)
                    editor.putString("usuario", usuarioAdmin.usuario)
                    editor.putString("rol", usuarioAdmin.rol)
                    editor.putString("metodoLogin", "admin_gestion") // 🔧 Marcar que vino desde gestión de locales
                    
                    Log.d("ADMIN_FLOW", "🔧 Marcando admin_gestion en GestionLocalesActivity (usuario admin encontrado)")
                    Log.d("GestionLocalesActivity", "Usuario admin ingresó al local: ${local.nombre} (Usuario: ${usuarioAdmin.usuario})")
                } else {
                    // Si no hay usuario admin, crear datos por defecto para el administrador
                    editor.putString("usuarioId", "admin_${local.id}")
                    editor.putString("usuario", "admin_${local.id}")
                    editor.putString("rol", "admin_local")
                    editor.putString("metodoLogin", "admin_gestion") // 🔧 Marcar que vino desde gestión de locales
                    
                    Log.d("ADMIN_FLOW", "🔧 Marcando admin_gestion en GestionLocalesActivity (usuario admin por defecto)")
                    Log.d("GestionLocalesActivity", "Usuario ingresó al local como admin por defecto: ${local.nombre}")
                }
                
                editor.apply()
                
                // Ir directamente al MainActivity
                val intent = Intent(this@GestionLocalesActivity, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error ingresando al local", e)
                txtEstado.text = "Error ingresando al local: ${e.message}"
            }
        }
    }
    
    private fun obtenercontraseñaGuardada(localId: String): String {
        val prefs = getSharedPreferences("contraseñas_locales", MODE_PRIVATE)
        return prefs.getString("local_$localId", "") ?: ""
    }
    
    private fun guardarcontraseñaLocal(localId: String, contraseña: String) {
        val prefs = getSharedPreferences("contraseñas_locales", MODE_PRIVATE)
        prefs.edit()
            .putString("local_$localId", contraseña)
            .apply()
        
        Log.d("GestionLocalesActivity", "contraseña guardada para local: $localId")
    }
    
    private fun limpiarcontraseñaLocal(localId: String) {
        val prefs = getSharedPreferences("contraseñas_locales", MODE_PRIVATE)
        prefs.edit()
            .remove("local_$localId")
            .apply()
        
        Log.d("GestionLocalesActivity", "contraseña eliminada para local: $localId")
    }
    
    /**
     * Verifica si un local tiene datos en 0 sin el flag noRecibioMercaderia
     * y también verifica si faltan datos en días anteriores
     */
    private fun verificarDatosEnCero(localId: String, nombreLocal: String, nombreTextView: TextView) {
        lifecycleScope.launch {
            try {
                // Obtener la fecha de hoy
                val formatoFecha = DateHelper.getDateFormat("yyyy-MM-dd")
                val fechaHoy = formatoFecha.format(Date())
                
                // Lista para almacenar los problemas encontrados
                val problemas = mutableListOf<String>()
                
                // 1. Verificar datos en 0 de hoy
                verificarDatosEnCeroHoy(localId, fechaHoy, problemas)
                
                // 2. Verificar días faltantes en los últimos 7 días
                verificarDiasFaltantes(localId, fechaHoy, problemas)
                
                // Actualizar el TextView en el hilo principal
                runOnUiThread {
                    if (problemas.isNotEmpty()) {
                        val nombreActual = nombreTextView.text.toString()
                        // Solo agregar el icono si no lo tiene ya
                        if (!nombreActual.contains("⚠️")) {
                            nombreTextView.text = "$nombreActual ⚠️"
                        }
                        
                        // Hacer el icono clickeable para mostrar detalles
                        nombreTextView.setOnClickListener {
                            mostrarDetallesProblemas(nombreLocal, problemas)
                        }
                    }
                }
                
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error verificando datos para local $localId", e)
            }
        }
    }
    
    /**
     * Verifica si hay datos en 0 sin el flag correspondiente en TODOS los registros históricos
     * Verifica desde el primer registro cargado
     */
    private suspend fun verificarDatosEnCeroHoy(localId: String, _fechaHoy: String, problemas: MutableList<String>) {
        Log.d("GestionLocalesActivity", "🔍 Verificando datos en 0 en TODOS los registros históricos para local: $localId")
        
        try {
            // Obtener TODOS los registros históricos del local
            val snapshot = firestore.collection("locales")
                .document(localId)
                .collection("registros")
                .get()
                .await()
            
            Log.d("GestionLocalesActivity", "📊 Total de registros para verificar datos en 0: ${snapshot.documents.size}")
            
            snapshot.documents.forEach { document ->
                val registro = document.toObject(RegistroInventario::class.java)
                if (registro != null) {
                    // Verificar si todos los productos están en 0 (verificar que haya productos antes)
                    val todosEnCero = registro.productos.isNotEmpty() && registro.productos.all { it.cantidad == 0 }
                    
                    Log.d("GestionLocalesActivity", "📅 Verificando ${registro.tipo} - ${registro.fecha}: todosEnCero=$todosEnCero, productos.size=${registro.productos.size}, noRecibioMercaderia=${registro.noRecibioMercaderia}")
                    
                    when (registro.tipo) {
                        "Ingreso de Mercadería" -> {
                            // Si todos están en 0 y NO tiene el flag noRecibioMercaderia, mostrar alerta
                            if (todosEnCero && !registro.noRecibioMercaderia) {
                                val calendarFecha = DateHelper.getCalendar()
                                calendarFecha.time = DateHelper.getDateFormat("yyyy-MM-dd").parse(registro.fecha)!!
                                val diaSemana = obtenerDiaSemana(calendarFecha)
                                val fechaFormateada = formatearFechaParaMostrar(calendarFecha)
                                
                                Log.d("GestionLocalesActivity", "⚠️ Problema encontrado: ${registro.tipo} - ${registro.fecha}")
                                problemas.add("📦 $diaSemana $fechaFormateada:\n Ingreso de Mercadería\n   ⚠️ Todos los productos en 0")
                            }
                        }
                        "Stock Final" -> {
                            // Para Stock Final solo alertar si todos están en 0 (no hay flag aquí)
                            if (todosEnCero) {
                                val calendarFecha = DateHelper.getCalendar()
                                calendarFecha.time = DateHelper.getDateFormat("yyyy-MM-dd").parse(registro.fecha)!!
                                val diaSemana = obtenerDiaSemana(calendarFecha)
                                val fechaFormateada = formatearFechaParaMostrar(calendarFecha)
                                
                                Log.d("GestionLocalesActivity", "⚠️ Problema encontrado: ${registro.tipo} - ${registro.fecha}")
                                problemas.add("📊 $diaSemana $fechaFormateada - Stock Final\n   ⚠️ Todos los productos en 0")
                            }
                        }
                    }
                }
            }
            
            Log.d("GestionLocalesActivity", "✅ Verificación de datos en 0 completada. Problemas encontrados: ${problemas.size}")
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "❌ Error verificando datos en 0: ${e.message}", e)
        }
    }
    
    /**
     * Verifica días faltantes en TODOS los registros históricos (excluyendo hoy)
     * Verifica desde el primer registro cargado
     */
    private suspend fun verificarDiasFaltantes(localId: String, fechaHoy: String, problemas: MutableList<String>) {
        val formatoFecha = DateHelper.getDateFormat("yyyy-MM-dd")
        
        Log.d("GestionLocalesActivity", "🔍 Verificando días faltantes en TODOS los registros históricos para local: $localId, fecha hoy: $fechaHoy")
        
        try {
            // Obtener TODOS los registros históricos del local
            val snapshot = firestore.collection("locales")
                .document(localId)
                .collection("registros")
                .get()
                .await()
            
            Log.d("GestionLocalesActivity", "📊 Total de registros históricos encontrados: ${snapshot.documents.size}")
            
            // Si el local no tiene registros históricos (local nuevo), no generar alertas
            if (snapshot.isEmpty) {
                Log.d("GestionLocalesActivity", "🏪 Local nuevo sin registros históricos, no generando alertas de días faltantes")
                return
            }
            
            // Agrupar registros por fecha
            val registrosPorFecha = mutableMapOf<String, MutableSet<String>>()
            
            snapshot.documents.forEach { document ->
                val registro = document.toObject(RegistroInventario::class.java)
                if (registro != null && registro.fecha != fechaHoy) { // Excluir hoy
                    val fecha = registro.fecha
                    val tipo = registro.tipo
                    
                    if (!registrosPorFecha.containsKey(fecha)) {
                        registrosPorFecha[fecha] = mutableSetOf()
                    }
                    registrosPorFecha[fecha]!!.add(tipo)
                    
                    Log.d("GestionLocalesActivity", "📅 Fecha: $fecha, Tipo: $tipo")
                }
            }
            
            Log.d("GestionLocalesActivity", "📊 Fechas con datos: ${registrosPorFecha.keys.sorted()}")
            
            // Verificar cada fecha histórica
            registrosPorFecha.forEach { (fecha, tiposExistentes) ->
                val calendarFecha = DateHelper.getCalendar()
                calendarFecha.time = formatoFecha.parse(fecha)!!
                val diaSemana = obtenerDiaSemana(calendarFecha)
                
                val faltantes = mutableListOf<String>()
                
                if (!tiposExistentes.contains("Ingreso de Mercadería")) {
                    faltantes.add("Ingreso de Mercadería")
                    Log.d("GestionLocalesActivity", "⚠️ Falta Ingreso de Mercadería para $fecha")
                }
                if (!tiposExistentes.contains("Stock Final")) {
                    faltantes.add("Stock Final")
                    Log.d("GestionLocalesActivity", "⚠️ Falta Stock Final para $fecha")
                }
                
                if (faltantes.isNotEmpty()) {
                    val fechaFormateada = formatearFechaParaMostrar(calendarFecha)
                    Log.d("GestionLocalesActivity", "📝 Agregando problema para $fecha: ${faltantes.joinToString(", ")}")
                    problemas.add("📅 $diaSemana $fechaFormateada\n   ⚠️ Faltan: ${faltantes.joinToString(", ")}")
                }
            }
            
            Log.d("GestionLocalesActivity", "✅ Verificación completada. Problemas encontrados: ${problemas.size}")
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "❌ Error verificando días faltantes: ${e.message}", e)
        }
    }
    
    /**
     * Obtiene el nombre del día de la semana en español
     */
    private fun obtenerDiaSemana(calendar: Calendar): String {
        val dias = arrayOf("DOM", "LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB")
        return dias[calendar.get(Calendar.DAY_OF_WEEK) - 1]
    }
    
    /**
     * Formatea una fecha para mostrar en formato "DD-MM-YY"
     */
    private fun formatearFechaParaMostrar(calendar: Calendar): String {
        val dia = String.format("%02d", calendar.get(Calendar.DAY_OF_MONTH))
        val mes = String.format("%02d", calendar.get(Calendar.MONTH) + 1)
        val año = String.format("%02d", calendar.get(Calendar.YEAR) % 100)
        return "$dia-$mes-$año"
    }
    
    /**
     * Abre la pantalla de Stock y Vencimientos para un local
     */
    private fun abrirStockVencimientos(local: Local) {
        Log.d("GestionLocalesActivity", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        Log.d("GestionLocalesActivity", "🚀 Abriendo StockVencimientosActivity")
        Log.d("GestionLocalesActivity", "   local.id: '${local.id}'")
        Log.d("GestionLocalesActivity", "   local.nombre: '${local.nombre}'")
        
        // Validar que el local tenga un ID válido
        val localIdValido = if (local.id.isEmpty()) {
            // Si el ID está vacío, usar el nombre como fallback (ya que en Firebase el document ID es el nombre)
            Log.w("GestionLocalesActivity", "⚠️ local.id está vacío, usando local.nombre como fallback")
            local.nombre
        } else {
            local.id
        }
        
        if (localIdValido.isEmpty()) {
            Log.e("GestionLocalesActivity", "❌ ERROR: No se puede abrir vencimientos - localId y localNombre están vacíos")
            Toast.makeText(this, "Error: No se pudo identificar el local. Por favor, intente nuevamente.", Toast.LENGTH_LONG).show()
            return
        }
        
        Log.d("GestionLocalesActivity", "   ✅ localId válido: '$localIdValido'")
        
        try {
            val intent = Intent(this, StockVencimientosActivity::class.java)
            intent.putExtra("localId", localIdValido)
            intent.putExtra("localNombre", local.nombre)
            startActivity(intent)
            Log.d("GestionLocalesActivity", "   ✅ Intent creado y actividad iniciada")
        } catch (e: Exception) {
            Log.e("GestionLocalesActivity", "❌ ERROR abriendo StockVencimientosActivity: ${e.message}", e)
            Toast.makeText(this, "Error abriendo vencimientos: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    /**
     * Carga el badge de vencimientos para mostrar alertas en la lista de locales
     */
    private fun cargarBadgeVencimientos(localId: String, badgeView: TextView) {
        lifecycleScope.launch {
            try {
                val vencimientoRepo = com.tuapp.inventario.repository.VencimientoRepository()
                val resumen = vencimientoRepo.obtenerResumenVencimientos(localId)
                
                val hoy = resumen["hoy"] ?: 0
                val manana = resumen["manana"] ?: 0
                
                runOnUiThread {
                    if (hoy > 0) {
                        badgeView.text = "🔴 $hoy"
                        badgeView.visibility = View.VISIBLE
                        badgeView.setBackgroundResource(R.drawable.button_gestion_danger)
                    } else if (manana > 0) {
                        badgeView.text = "🟡 $manana"
                        badgeView.visibility = View.VISIBLE
                        badgeView.setBackgroundColor(resources.getColor(android.R.color.holo_orange_light, null))
                    } else {
                        badgeView.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error cargando badge de vencimientos: ${e.message}")
            }
        }
    }
    
    /**
     * Carga todos los badges de vencimientos en paralelo para mejorar el rendimiento
     */
    private fun cargarBadgesVencimientosParalelo(badgesMap: Map<String, TextView>) {
        lifecycleScope.launch {
            try {
                val vencimientoRepo = com.tuapp.inventario.repository.VencimientoRepository()
                
                // Cargar todos los resúmenes en paralelo usando async
                val deferredResumenes = badgesMap.keys.map { localId ->
                    async {
                        localId to vencimientoRepo.obtenerResumenVencimientos(localId)
                    }
                }
                
                // Esperar a que todas las corrutinas terminen en paralelo
                val resumenes = deferredResumenes.awaitAll()
                
                // Actualizar todos los badges en el hilo principal
                runOnUiThread {
                    resumenes.forEach { (localId, resumen) ->
                        val badgeView = badgesMap[localId] ?: return@forEach
                        val hoy = resumen["hoy"] ?: 0
                        val manana = resumen["manana"] ?: 0
                        
                        if (hoy > 0) {
                            badgeView.text = "🔴 $hoy"
                            badgeView.visibility = View.VISIBLE
                            badgeView.setBackgroundResource(R.drawable.button_gestion_danger)
                        } else if (manana > 0) {
                            badgeView.text = "🟡 $manana"
                            badgeView.visibility = View.VISIBLE
                            badgeView.setBackgroundColor(resources.getColor(android.R.color.holo_orange_light, null))
                        } else {
                            badgeView.visibility = View.GONE
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error cargando badges de vencimientos en paralelo: ${e.message}")
            }
        }
    }
    
    /**
     * Muestra un popup con los productos que vencen hoy
     */
    private fun mostrarPopupVencimientosHoy(local: Local) {
        lifecycleScope.launch {
            try {
                val vencimientoRepo = com.tuapp.inventario.repository.VencimientoRepository()
                val lotes = vencimientoRepo.obtenerLotesActivos(local.id)
                
                // Filtrar solo los que vencen hoy
                val lotesHoy = lotes.filter { it.diasHastaVencimiento() == 0 }
                
                runOnUiThread {
                    if (lotesHoy.isEmpty()) {
                        Toast.makeText(this@GestionLocalesActivity, "No hay productos que venzan hoy", Toast.LENGTH_SHORT).show()
                        return@runOnUiThread
                    }
                    
                    // Agrupar por producto
                    val lotesPorProducto = lotesHoy.groupBy { it.productoCodigo }
                    
                    // Construir mensaje
                    val mensaje = StringBuilder()
                    mensaje.append("🔴 Productos que vencen HOY:\n\n")
                    
                    lotesPorProducto.forEach { (_, lotesProducto) ->
                        val totalCantidad = lotesProducto.sumOf { it.cantidad }
                        val nombreProducto = lotesProducto.first().productoNombre
                        mensaje.append("• $nombreProducto: $totalCantidad uds\n")
                    }
                    
                    // Mostrar diálogo
                    AlertDialog.Builder(this@GestionLocalesActivity)
                        .setTitle("⚠️ ${local.nombre} - Vencimientos HOY")
                        .setMessage(mensaje.toString())
                        .setPositiveButton("Ver Detalles") { _, _ ->
                            abrirStockVencimientos(local)
                        }
                        .setNegativeButton("Cerrar", null)
                        .show()
                }
            } catch (e: Exception) {
                Log.e("GestionLocalesActivity", "Error mostrando popup vencimientos: ${e.message}")
                runOnUiThread {
                    Toast.makeText(this@GestionLocalesActivity, "Error cargando vencimientos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    /**
     * Muestra un diálogo con los detalles de los problemas encontrados
     * Incluye scroll para poder ver todas las alertas cuando hay muchas
     */
    private fun mostrarDetallesProblemas(nombreLocal: String, problemas: List<String>) {
        // Crear layout principal
        val layoutPrincipal = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        // Título
        val txtTitulo = TextView(this).apply {
            text = "⚠️ Alertas - $nombreLocal"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(resources.getColor(android.R.color.white, null))
            setBackgroundColor(0xFFF44336.toInt()) // Rojo
            setPadding(32, 24, 32, 24)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        layoutPrincipal.addView(txtTitulo)
        
        // ScrollView para el contenido
        val scrollView = android.widget.ScrollView(this)
        scrollView.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.6).toInt() // Limitar altura máxima a 60% de la pantalla
        )
        
        // Layout interno para el contenido
        val layoutContenido = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        
        // Mensaje introductorio
        val txtIntro = TextView(this).apply {
            text = "Se encontraron los siguientes problemas:\n"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(resources.getColor(android.R.color.black, null))
            setPadding(0, 0, 0, 16)
        }
        layoutContenido.addView(txtIntro)
        
        // Agregar cada problema
        problemas.forEach { problema ->
            val txtProblema = TextView(this).apply {
                text = problema
                textSize = 14f
                setTextColor(resources.getColor(android.R.color.black, null))
                setPadding(0, 8, 0, 16)
            }
            layoutContenido.addView(txtProblema)
        }
        
        scrollView.addView(layoutContenido)
        layoutPrincipal.addView(scrollView)
        
        // Mostrar diálogo
        AlertDialog.Builder(this)
            .setView(layoutPrincipal)
            .setPositiveButton("Entendido", null)
            .show()
    }
    
    /**
     * Verifica si el dispositivo está en modo oscuro
     */
    private fun isDarkMode(): Boolean {
        val nightModeFlags = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
        return nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES
    }
    
    /**
     * Configura la marca de agua según el modo oscuro
     * En modo oscuro: se muestra difuminada pero visible (alpha = 0.3)
     * En modo claro: se muestra con transparencia (alpha = 0.08)
     */
    private fun configurarMarcaDeAgua() {
        val imgWatermark = findViewById<ImageView>(R.id.imgWatermark)
        imgWatermark?.let {
            if (isDarkMode()) {
                // Modo oscuro: mostrar difuminada pero visible
                it.alpha = 0.3f
                Log.d("GestionLocalesActivity", "🌙 Modo oscuro: marca de agua difuminada (alpha=0.3)")
            } else {
                // Modo claro: mostrar con transparencia
                it.alpha = 0.08f
                Log.d("GestionLocalesActivity", "☀️ Modo claro: marca de agua con transparencia (alpha=0.08)")
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        // Configurar marca de agua según modo oscuro (por si cambió mientras la app estaba en segundo plano)
        configurarMarcaDeAgua()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        // Remover listeners para prevenir memory leaks
        try {
            textWatcherLocales?.let {
                editTextBuscar.removeTextChangedListener(it)
            }
            textWatcherSupervisores?.let {
                editTextBuscarSupervisores.removeTextChangedListener(it)
            }
        } catch (e: Exception) {
            // Ignorar si los views no están inicializados
            Log.d("GestionLocalesActivity", "Error removiendo listeners: ${e.message}")
        }
    }
    
}
