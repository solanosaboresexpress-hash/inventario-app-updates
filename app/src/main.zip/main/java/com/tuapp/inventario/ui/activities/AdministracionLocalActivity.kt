package com.tuapp.inventario.ui.activities

import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import androidx.appcompat.widget.AppCompatAutoCompleteTextView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.tuapp.inventario.R
import com.tuapp.inventario.utils.DateHelper
import com.tuapp.inventario.utils.AnimationUtils
import com.tuapp.inventario.data.models.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Activity principal para administración del local
 * Gestiona documentos del local y personal con sus certificaciones
 */
class AdministracionLocalActivity : AppCompatActivity() {
    
    private fun isDarkMode(): Boolean {
        return when (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) {
            android.content.res.Configuration.UI_MODE_NIGHT_YES -> true
            else -> false
        }
    }
    
    val tabLayout: TabLayout? = null
    private lateinit var txtLocalActual: TextView
    private lateinit var txtTotalDocumentos: TextView
    private lateinit var txtTotalPersonal: TextView
    private lateinit var txtAlertasActivas: TextView
    
    private lateinit var documentosContainer: LinearLayout
    private lateinit var personalContainer: LinearLayout
    private lateinit var notificacionesContainer: LinearLayout
    
    private var localId: String = ""
    private var localNombre: String = ""
    
    // Datos de ejemplo (después se conectarán con Firebase/Room)
    private var documentosLocales = mutableListOf<DocumentoLocal>()
    private var personalLocal = mutableListOf<PersonalLocal>()
    private var notificaciones = mutableListOf<NotificacionVencimiento>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_administracion_local)
        
        // Obtener datos del local
        localId = intent.getStringExtra("localId") ?: ""
        localNombre = intent.getStringExtra("localNombre") ?: "Local Seleccionado"
        
        setupUI()
        cargarDatosDesdeFirebase()
        actualizarUI()
    }
    
    private fun setupUI() {
        txtLocalActual = findViewById(R.id.txtLocalActual)
        txtTotalDocumentos = findViewById(R.id.txtTotalDocumentos)
        txtTotalPersonal = findViewById(R.id.txtTotalPersonal)
        txtAlertasActivas = findViewById(R.id.txtAlertasActivas)
        
        // Configurar clics en tarjetas de estadísticas
        findViewById<LinearLayout>(R.id.cardDocumentos).setOnClickListener {
            mostrarDocumentos()
        }
        
        findViewById<LinearLayout>(R.id.cardPersonal).setOnClickListener {
            mostrarPersonal()
        }
        
        findViewById<LinearLayout>(R.id.cardAlertas).setOnClickListener {
            mostrarNotificaciones()
        }
        
        // Inicializar contenedores
        documentosContainer = findViewById(R.id.documentosContainer)
        personalContainer = findViewById(R.id.personalContainer)
        notificacionesContainer = findViewById(R.id.notificacionesContainer)
        
        // Configurar FABs
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarDocumento).setOnClickListener {
            mostrarDialogoAgregarDocumento()
        }
        
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarPersonal).setOnClickListener {
            mostrarDialogoAgregarPersonal()
        }
        
        // Mostrar documentos por defecto
        mostrarDocumentos()
    }
    
    private fun cargarDatosDesdeFirebase() {
        val db = FirebaseFirestore.getInstance()
        
        // Cargar documentos desde Firebase
        db.collection("locales")
            .document(localId)
            .collection("documentos")
            .get()
            .addOnSuccessListener { result ->
                documentosLocales.clear()
                for (document in result) {
                    val documento = document.toObject(DocumentoLocal::class.java)
                    
                    // Recalcular diasParaVencer con fecha actual
                    val documentoActualizado = documento.copy(
                        diasParaVencer = if (documento.fechaVencimiento != null) {
                            DateHelper.getDaysUntilDate(documento.fechaVencimiento)
                        } else 0,
                        estado = if (documento.fechaVencimiento != null) {
                            when {
                                DateHelper.isDateExpired(documento.fechaVencimiento) -> EstadoDocumento.VENCIDO
                                DateHelper.getDaysUntilDate(documento.fechaVencimiento) <= 30 -> EstadoDocumento.POR_VENCER
                                else -> EstadoDocumento.VIGENTE
                            }
                        } else documento.estado
                    )
                    
                    documentosLocales.add(documentoActualizado)
                }
                
                // Si no hay documentos, cargar datos de ejemplo
                if (documentosLocales.isEmpty()) {
                    cargarDatosEjemplo()
                }
                
                cargarDocumentosUI()
                generarNotificaciones()
                actualizarUI()
            }
            .addOnFailureListener { e ->
                Log.e("AdministracionLocal", "Error cargando documentos desde Firebase", e)
                // Si hay error, cargar datos de ejemplo
                cargarDatosEjemplo()
                cargarDocumentosUI()
                generarNotificaciones()
                actualizarUI()
            }
        
        // Cargar personal desde Firebase
        db.collection("locales")
            .document(localId)
            .collection("personal")
            .get()
            .addOnSuccessListener { result ->
                personalLocal.clear()
                for (document in result) {
                    val personal = document.toObject(PersonalLocal::class.java)
                    
                    // Recalcular diasParaVencer para libreta sanitaria
                    val libretaActualizada = personal.libretaSanitaria?.let { libreta ->
                        val diasParaVencer = if (libreta.fechaVencimiento != null) {
                            DateHelper.getDaysUntilDate(libreta.fechaVencimiento)
                        } else 0
                        
                        libreta.copy(
                            diasParaVencer = diasParaVencer,
                            estado = when {
                                libreta.fechaVencimiento == null -> EstadoCertificado.NO_POSEE
                                DateHelper.isDateExpired(libreta.fechaVencimiento) -> EstadoCertificado.VENCIDO
                                DateHelper.getDaysUntilDate(libreta.fechaVencimiento) <= 30 -> EstadoCertificado.POR_VENCER
                                else -> EstadoCertificado.VIGENTE
                            }
                        )
                    }
                    
                    // Recalcular diasParaVencer para curso de manipulación
                    val cursoActualizado = personal.cursoManipulacion?.let { curso ->
                        val diasParaVencer = if (curso.fechaVencimiento != null) {
                            DateHelper.getDaysUntilDate(curso.fechaVencimiento)
                        } else 0
                        
                        curso.copy(
                            diasParaVencer = diasParaVencer,
                            estado = when {
                                curso.fechaVencimiento == null -> EstadoCertificado.NO_POSEE
                                DateHelper.isDateExpired(curso.fechaVencimiento) -> EstadoCertificado.VENCIDO
                                DateHelper.getDaysUntilDate(curso.fechaVencimiento) <= 30 -> EstadoCertificado.POR_VENCER
                                else -> EstadoCertificado.VIGENTE
                            }
                        )
                    }
                    
                    // Actualizar personal con los valores recalculados
                    val personalActualizado = personal.copy(
                        libretaSanitaria = libretaActualizada,
                        cursoManipulacion = cursoActualizado
                    )
                    
                    personalLocal.add(personalActualizado)
                }
                cargarPersonalUI()
                actualizarUI()
            }
            .addOnFailureListener { e ->
                Log.e("AdministracionLocal", "Error cargando personal desde Firebase", e)
                cargarPersonalUI()
                actualizarUI()
            }
    }
    
    private fun mostrarDocumentos() {
        Log.d("AdministracionLocal", "Mostrando sección de documentos")
        documentosContainer.visibility = View.VISIBLE
        personalContainer.visibility = View.GONE
        notificacionesContainer.visibility = View.GONE
        
        // Cargar documentos en el contenedor
        documentosContainer.removeAllViews()
        documentosLocales.forEach { documento ->
            val cardView = crearDocumentoCard(documento)
            documentosContainer.addView(cardView)
            AnimationUtils.animateViewIn(cardView)
        }
        
        // Ocultar FAB de personal, mostrar FAB de documentos
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarDocumento).visibility = View.VISIBLE
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarPersonal).visibility = View.GONE
        
        actualizarUI()
    }
    
    private fun mostrarPersonal() {
        Log.d("AdministracionLocal", "Mostrando sección de personal")
        documentosContainer.visibility = View.GONE
        personalContainer.visibility = View.VISIBLE
        notificacionesContainer.visibility = View.GONE
        
        // Cargar personal en el contenedor
        personalContainer.removeAllViews()
        personalLocal.forEach { personal ->
            val cardView = crearPersonalCard(personal)
            personalContainer.addView(cardView)
            AnimationUtils.animateViewIn(cardView)
        }
        
        // Ocultar FAB de documentos, mostrar FAB de personal
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarDocumento).visibility = View.GONE
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarPersonal).visibility = View.VISIBLE
        
        actualizarUI()
    }
    
    private fun mostrarNotificaciones() {
        Log.d("AdministracionLocal", "Mostrando sección de notificaciones")
        documentosContainer.visibility = View.GONE
        personalContainer.visibility = View.GONE
        notificacionesContainer.visibility = View.VISIBLE
        
        // Cargar notificaciones en el contenedor
        notificacionesContainer.removeAllViews()
        if (notificaciones.isEmpty()) {
            val txtSinNotificaciones = TextView(this).apply {
                text = "¡No hay alertas activas! \ud83c\udf89"
                textSize = 18f
                gravity = android.view.Gravity.CENTER
                setPadding(0, 100, 0, 0)
                setTextColor(android.graphics.Color.parseColor("#4CAF50"))
            }
            notificacionesContainer.addView(txtSinNotificaciones)
        } else {
            notificaciones.forEach { notificacion ->
                val cardView = crearNotificacionCard(notificacion)
                notificacionesContainer.addView(cardView)
                AnimationUtils.animateViewIn(cardView)
            }
        }
        
        // Ocultar ambos FABs en notificaciones
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarDocumento).visibility = View.GONE
        findViewById<ExtendedFloatingActionButton>(R.id.fabAgregarPersonal).visibility = View.GONE
        
        actualizarUI()
    }
    
    private fun cargarDatosEjemplo() {
        val calendar = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        
        // Documentos de ejemplo
        documentosLocales.addAll(listOf(
            DocumentoLocal(
                id = "1",
                localId = localId,
                tipoDocumento = TipoDocumento.FUMIGACION,
                nombreDocumento = "Fumigación Cuatrimestral",
                fechaVencimiento = calendar.apply { add(Calendar.MONTH, 2) }.time,
                empresaResponsable = "Pest Control S.A.",
                estado = EstadoDocumento.VIGENTE,
                diasParaVencer = 60
            ),
            DocumentoLocal(
                id = "2",
                localId = localId,
                tipoDocumento = TipoDocumento.OBLEA_MATAFUEGOS,
                nombreDocumento = "Oblea Matafuegos Anual",
                fechaVencimiento = calendar.apply { add(Calendar.MONTH, -1) }.time,
                empresaResponsable = "Seguridad Fire S.R.L.",
                estado = EstadoDocumento.VENCIDO,
                diasParaVencer = -30
            ),
            DocumentoLocal(
                id = "3",
                localId = localId,
                tipoDocumento = TipoDocumento.ANALISIS_AGUA,
                nombreDocumento = "Análisis de Agua Potable",
                fechaVencimiento = calendar.apply { add(Calendar.MONTH, 6) }.time,
                empresaResponsable = "LabAgua S.A.",
                estado = EstadoDocumento.VIGENTE,
                diasParaVencer = 180
            )
        ))
        
        // Personal de ejemplo
        personalLocal.addAll(listOf(
            PersonalLocal(
                id = "1",
                localId = localId,
                nombre = "Juan",
                apellido = "Pérez",
                dni = "12345678",
                cargo = "Cocinero",
                telefono = "11-1234-5678",
                estado = EstadoPersonal.ACTIVO,
                libretaSanitaria = LibretaSanitaria(
                    numeroLibreta = "LS-12345",
                    fechaVencimiento = calendar.apply { add(Calendar.MONTH, 3) }.time,
                    estado = EstadoCertificado.VIGENTE,
                    diasParaVencer = 90
                ),
                cursoManipulacion = CursoManipulacion(
                    institucion = "INA",
                    tipoCurso = "Manipulación de Alimentos",
                    fechaVencimiento = calendar.apply { add(Calendar.MONTH, 1) }.time,
                    estado = EstadoCertificado.POR_VENCER,
                    diasParaVencer = 30
                )
            ),
            PersonalLocal(
                id = "2",
                localId = localId,
                nombre = "María",
                apellido = "González",
                dni = "87654321",
                cargo = "Moza",
                telefono = "11-8765-4321",
                estado = EstadoPersonal.ACTIVO,
                libretaSanitaria = LibretaSanitaria(
                    numeroLibreta = "LS-54321",
                    fechaVencimiento = calendar.apply { add(Calendar.MONTH, -2) }.time,
                    estado = EstadoCertificado.VENCIDO,
                    diasParaVencer = -60
                ),
                cursoManipulacion = CursoManipulacion(
                    institucion = "CENIC",
                    tipoCurso = "Manipulación de Alimentos",
                    fechaVencimiento = calendar.apply { add(Calendar.MONTH, 8) }.time,
                    estado = EstadoCertificado.VIGENTE,
                    diasParaVencer = 240
                )
            )
        ))
        
        // Generar notificaciones y mostrar documentos por defecto
        generarNotificaciones()
        mostrarDocumentos()
    }
    
    private fun generarNotificaciones() {
        notificaciones.clear()
        
        // Notificaciones de documentos
        documentosLocales.forEach { doc ->
            when {
                doc.diasParaVencer <= 0 -> {
                    notificaciones.add(NotificacionVencimiento(
                        id = "doc_${doc.id}",
                        localId = localId,
                        tipo = TipoNotificacion.DOCUMENTO_LOCAL,
                        elementoId = doc.id,
                        elementoNombre = doc.nombreDocumento,
                        tipoElemento = doc.tipoDocumento.displayName,
                        fechaVencimiento = doc.fechaVencimiento,
                        diasParaVencer = doc.diasParaVencer,
                        mensaje = "¡${doc.nombreDocumento} ${if (doc.diasParaVencer == 0) "VENCE HOY" else "VENCIDO"}!",
                        prioridad = if (doc.diasParaVencer <= -30) PrioridadNotificacion.CRITICA else PrioridadNotificacion.ALTA
                    ))
                }
                doc.diasParaVencer <= 30 -> {
                    notificaciones.add(NotificacionVencimiento(
                        id = "doc_${doc.id}",
                        localId = localId,
                        tipo = TipoNotificacion.DOCUMENTO_LOCAL,
                        elementoId = doc.id,
                        elementoNombre = doc.nombreDocumento,
                        tipoElemento = doc.tipoDocumento.displayName,
                        fechaVencimiento = doc.fechaVencimiento,
                        diasParaVencer = doc.diasParaVencer,
                        mensaje = "${doc.nombreDocumento} - ${formatTimeRemaining(doc.diasParaVencer)}",
                        prioridad = if (doc.diasParaVencer <= 7) PrioridadNotificacion.ALTA else PrioridadNotificacion.MEDIA
                    ))
                }
            }
        }
        
        // Notificaciones de personal
        personalLocal.forEach { personal ->
            // Libreta sanitaria
            personal.libretaSanitaria?.let { libreta ->
                when {
                    libreta.diasParaVencer <= 0 -> {
                        notificaciones.add(NotificacionVencimiento(
                            id = "lib_${personal.id}",
                            localId = localId,
                            tipo = TipoNotificacion.LIBRETA_SANITARIA,
                            elementoId = personal.id,
                            elementoNombre = personal.nombreCompleto,
                            tipoElemento = "Libreta Sanitaria",
                            fechaVencimiento = libreta.fechaVencimiento,
                            diasParaVencer = libreta.diasParaVencer,
                            mensaje = "Libreta sanitaria de ${personal.nombreCompleto} ${if (libreta.diasParaVencer == 0) "VENCE HOY" else "VENCIDA"}!",
                            prioridad = PrioridadNotificacion.ALTA
                        ))
                    }
                    libreta.diasParaVencer <= 30 -> {
                        notificaciones.add(NotificacionVencimiento(
                            id = "lib_${personal.id}",
                            localId = localId,
                            tipo = TipoNotificacion.LIBRETA_SANITARIA,
                            elementoId = personal.id,
                            elementoNombre = personal.nombreCompleto,
                            tipoElemento = "Libreta Sanitaria",
                            fechaVencimiento = libreta.fechaVencimiento,
                            diasParaVencer = libreta.diasParaVencer,
                            mensaje = "Libreta sanitaria de ${personal.nombreCompleto} - ${formatTimeRemaining(libreta.diasParaVencer)}",
                            prioridad = PrioridadNotificacion.MEDIA
                        ))
                    }
                    else -> {
                        // No hay notificación para libreta vigente (más de 30 días)
                    }
                }
            }
            
            // Curso de manipulación
            personal.cursoManipulacion?.let { curso ->
                when {
                    curso.diasParaVencer <= 0 -> {
                        notificaciones.add(NotificacionVencimiento(
                            id = "cur_${personal.id}",
                            localId = localId,
                            tipo = TipoNotificacion.CURSO_MANIPULACION,
                            elementoId = personal.id,
                            elementoNombre = personal.nombreCompleto,
                            tipoElemento = "Curso Manipulación",
                            fechaVencimiento = curso.fechaVencimiento,
                            diasParaVencer = curso.diasParaVencer,
                            mensaje = "Curso de ${personal.nombreCompleto} ${if (curso.diasParaVencer == 0) "VENCE HOY" else "VENCIDO"}!",
                            prioridad = PrioridadNotificacion.ALTA
                        ))
                    }
                    curso.diasParaVencer <= 30 -> {
                        notificaciones.add(NotificacionVencimiento(
                            id = "cur_${personal.id}",
                            localId = localId,
                            tipo = TipoNotificacion.CURSO_MANIPULACION,
                            elementoId = personal.id,
                            elementoNombre = personal.nombreCompleto,
                            tipoElemento = "Curso Manipulación",
                            fechaVencimiento = curso.fechaVencimiento,
                            diasParaVencer = curso.diasParaVencer,
                            mensaje = "Curso de ${personal.nombreCompleto} - ${formatTimeRemaining(curso.diasParaVencer)}",
                            prioridad = PrioridadNotificacion.MEDIA
                        ))
                    }
                    else -> {
                        // No hay notificación para curso vigente
                    }
                }
            }
        }
        
        // Ordenar por prioridad y días para vencer
        notificaciones.sortWith(compareByDescending<NotificacionVencimiento> { 
            when (it.prioridad) {
                PrioridadNotificacion.CRITICA -> 4
                PrioridadNotificacion.ALTA -> 3
                PrioridadNotificacion.MEDIA -> 2
                PrioridadNotificacion.BAJA -> 1
            }
        }.thenBy { it.diasParaVencer })
    }
    
    private fun cargarDocumentosUI() {
        documentosContainer.removeAllViews()
        
        documentosLocales.forEach { documento ->
            val cardView = crearDocumentoCard(documento)
            documentosContainer.addView(cardView)
            AnimationUtils.animateViewIn(cardView)
        }
    }
    
    private fun cargarPersonalUI() {
        personalContainer.removeAllViews()
        
        personalLocal.forEach { personal ->
            val cardView = crearPersonalCard(personal)
            personalContainer.addView(cardView)
            AnimationUtils.animateViewIn(cardView)
        }
    }
    
    private fun updateDocumentCount() {
        notificacionesContainer.removeAllViews()
        
        if (notificaciones.isEmpty()) {
            val txtSinNotificaciones = TextView(this).apply {
                text = "¡No hay alertas activas! \ud83c\udf89"
                textSize = 18f
                gravity = android.view.Gravity.CENTER
                setPadding(0, 100, 0, 0)
                setTextColor(android.graphics.Color.parseColor("#4CAF50"))
            }
            notificacionesContainer.addView(txtSinNotificaciones)
        } else {
            notificaciones.forEach { notificacion ->
                val cardView = crearNotificacionCard(notificacion)
                notificacionesContainer.addView(cardView)
                AnimationUtils.animateViewIn(cardView)
            }
        }
    }
    
    private fun crearDocumentoCard(documento: DocumentoLocal): View {
        // Inflar el nuevo layout de tarjeta
        val cardView = layoutInflater.inflate(R.layout.item_documento_card, null)
        
        // Configurar los datos del documento
        cardView.findViewById<TextView>(R.id.txtIcono).text = when (documento.tipoDocumento) {
            TipoDocumento.FUMIGACION -> "🌿"
            TipoDocumento.OBLEA_MATAFUEGOS -> "🔥"
            TipoDocumento.ANALISIS_AGUA -> "💧"
            TipoDocumento.REBA -> "⚠️"
            TipoDocumento.POLIZA_SEGURO -> "🛡️"
            TipoDocumento.HABILITACION_MUNICIPAL -> "🏢"
            TipoDocumento.CERTIFICADO_HIGIENE -> "🏥"
        }
        
        cardView.findViewById<TextView>(R.id.txtNombreDocumento).text = documento.nombreDocumento
        
        // Empresa y teléfono
        cardView.findViewById<TextView>(R.id.txtEmpresa).text = documento.empresaResponsable
        cardView.findViewById<TextView>(R.id.txtTelefono).text = documento.telefono.ifEmpty { "No especificado" }
        
        // Fecha de vencimiento
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        cardView.findViewById<TextView>(R.id.txtFechaVencimiento).text = 
            documento.fechaVencimiento?.let { sdf.format(it) } ?: "No especificada"
        
        // Observaciones
        val txtObservaciones = cardView.findViewById<TextView>(R.id.txtObservaciones)
        if (documento.observaciones.isNotBlank()) {
            txtObservaciones.text = documento.observaciones
            txtObservaciones.visibility = View.VISIBLE
        } else {
            txtObservaciones.visibility = View.GONE
        }
        
        // Estado
        val txtEstado = cardView.findViewById<TextView>(R.id.txtEstado)
        txtEstado.text = documento.estado.displayName
        txtEstado.setBackgroundColor(ContextCompat.getColor(this, 
            when (documento.estado) {
                EstadoDocumento.VIGENTE -> android.R.color.holo_green_dark
                EstadoDocumento.POR_VENCER -> android.R.color.holo_orange_dark
                EstadoDocumento.VENCIDO -> android.R.color.holo_red_dark
                EstadoDocumento.EN_TRAMITE -> android.R.color.holo_blue_dark
            }
        ))
        
        // Días para vencer
        val txtDiasParaVencer = cardView.findViewById<TextView>(R.id.txtDiasParaVencer)
        if (documento.diasParaVencer > 0) {
            txtDiasParaVencer.text = "${documento.diasParaVencer} días"
        } else if (documento.diasParaVencer == 0) {
            txtDiasParaVencer.text = "Vence hoy"
        } else {
            txtDiasParaVencer.text = "Vencido"
        }
        
        // Botón de acciones
        cardView.findViewById<ImageButton>(R.id.btnAcciones).setOnClickListener {
            mostrarOpcionesDocumento(documento)
        }
        
        return cardView
    }
    
    private fun mostrarOpcionesDocumento(documento: DocumentoLocal) {
        val opciones = arrayOf("Ver Detalles", "Editar", "Eliminar")
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Opciones - ${documento.nombreDocumento}")
            .setItems(opciones) { _, which ->
                when (which) {
                    0 -> mostrarDialogoDetalleDocumento(documento)
                    1 -> mostrarDialogoEditarDocumento(documento)
                    2 -> mostrarDialogoEliminarDocumento(documento)
                }
            }
            .show()
    }
    
    private fun crearPersonalCard(personal: PersonalLocal): CardView {
        val cardView = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 8, 16, 8)
            }
            radius = 16f
            cardElevation = 8f
            setCardBackgroundColor(android.graphics.Color.parseColor("#FFFFFF"))
        }
        
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }
        
        // Nombre y cargo
        val nombreView = TextView(this).apply {
            text = personal.nombreCompleto
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.parseColor("#212121"))
        }
        
        val cargoView = TextView(this).apply {
            text = personal.cargo
            textSize = 14f
            setTextColor(android.graphics.Color.parseColor("#757575"))
            setPadding(0, 4, 0, 8)
        }
        
        // Libreta sanitaria
        val libretaLayout = crearCertificadoView(
            "Libreta Sanitaria",
            personal.libretaSanitaria
        )
        
        // Curso manipulación
        val cursoLayout = crearCertificadoView(
            "Curso Manipulación",
            personal.cursoManipulacion
        )
        
        layout.addView(nombreView)
        layout.addView(cargoView)
        layout.addView(libretaLayout)
        layout.addView(cursoLayout)
        
        cardView.addView(layout)
        cardView.setOnClickListener {
            mostrarDialogoDetallePersonal(personal)
        }
        
        return cardView
    }
    
    private fun crearCertificadoView(titulo: String, certificado: Any?): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 8)
        }
        
        val iconView = TextView(this).apply {
            text = when (titulo) {
                "Libreta Sanitaria" -> "\ud83d\udcdd"
                "Curso Manipulación" -> "\ud83c\udf93"
                else -> "\ud83d\udccb"
            }
            textSize = 20f
            setPadding(0, 0, 12, 0)
        }
        
        val infoLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        val tituloView = TextView(this).apply {
            text = titulo
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.parseColor("#212121"))
        }
        
        val estadoView = TextView(this).apply {
            text = when (certificado) {
                is LibretaSanitaria -> {
                    when (certificado.estado) {
                        EstadoCertificado.VIGENTE -> "Vigente - ${formatTimeRemaining(certificado.diasParaVencer)}"
                        EstadoCertificado.POR_VENCER -> "Por vencer - ${formatTimeRemaining(certificado.diasParaVencer)}"
                        EstadoCertificado.VENCIDO -> "Vencido - ${formatTimeRemaining(certificado.diasParaVencer)}"
                        EstadoCertificado.NO_POSEE -> "No posee"
                        EstadoCertificado.EN_TRAMITE -> "En trámite"
                    }
                }
                is CursoManipulacion -> {
                    when (certificado.estado) {
                        EstadoCertificado.VIGENTE -> "Vigente - ${formatTimeRemaining(certificado.diasParaVencer)}"
                        EstadoCertificado.POR_VENCER -> "Por vencer - ${formatTimeRemaining(certificado.diasParaVencer)}"
                        EstadoCertificado.VENCIDO -> "Vencido - ${formatTimeRemaining(certificado.diasParaVencer)}"
                        EstadoCertificado.NO_POSEE -> "No posee"
                        EstadoCertificado.EN_TRAMITE -> "En trámite"
                    }
                }
                else -> "No disponible"
            }
            textSize = 12f
            setTextColor(android.graphics.Color.parseColor("#757575"))
        }
        
        infoLayout.addView(tituloView)
        infoLayout.addView(estadoView)
        
        layout.addView(iconView)
        layout.addView(infoLayout)
        
        return layout
    }
    
    private fun crearNotificacionCard(notificacion: NotificacionVencimiento): CardView {
        val cardView = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 8, 16, 8)
            }
            radius = 12f
            cardElevation = 6f
            setCardBackgroundColor(android.graphics.Color.parseColor(
                when (notificacion.prioridad) {
                    PrioridadNotificacion.CRITICA -> "#FFEBEE"
                    PrioridadNotificacion.ALTA -> "#FFF3E0"
                    PrioridadNotificacion.MEDIA -> "#FFF8E1"
                    PrioridadNotificacion.BAJA -> "#E8F5E8"
                }
            ))
        }
        
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }
        
        // Icono y prioridad
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        
        val iconView = TextView(this).apply {
            text = when (notificacion.prioridad) {
                PrioridadNotificacion.CRITICA -> "\ud83d\udea8"
                PrioridadNotificacion.ALTA -> "\u26a0\ufe0f"
                PrioridadNotificacion.MEDIA -> "\u2139\ufe0f"
                PrioridadNotificacion.BAJA -> "\u2705"
            }
            textSize = 24f
            setPadding(0, 0, 12, 0)
        }
        
        val prioridadView = TextView(this).apply {
            text = "${notificacion.prioridad.displayName}"
            textSize = 12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.parseColor(
                when (notificacion.prioridad) {
                    PrioridadNotificacion.CRITICA -> "#D32F2F"
                    PrioridadNotificacion.ALTA -> "#F57C00"
                    PrioridadNotificacion.MEDIA -> "#F9A825"
                    PrioridadNotificacion.BAJA -> "#388E3C"
                }
            ))
        }
        
        headerLayout.addView(iconView)
        headerLayout.addView(prioridadView)
        
        // Mensaje
        val mensajeView = TextView(this).apply {
            text = notificacion.mensaje
            textSize = 14f
            setTextColor(android.graphics.Color.parseColor("#212121"))
            setPadding(0, 8, 0, 0)
        }
        
        layout.addView(headerLayout)
        layout.addView(mensajeView)
        
        cardView.addView(layout)
        cardView.setOnClickListener {
            marcarNotificacionComoLeida(notificacion)
        }
        
        return cardView
    }
    
    private fun mostrarDialogoAgregarDocumento() {
        Log.d("AdministracionLocal", "mostrarDialogoAgregarDocumento llamado")
        val dialogView = layoutInflater.inflate(R.layout.dialog_agregar_documento, null)
        
        val spinnerTipo = dialogView.findViewById<MaterialAutoCompleteTextView>(R.id.spinnerTipoDocumento)
        val editEmpresa = dialogView.findViewById<TextInputEditText>(R.id.edtEmpresa)
        val editTelefono = dialogView.findViewById<TextInputEditText>(R.id.edtTelefono)
        val editVencimiento = dialogView.findViewById<TextInputEditText>(R.id.edtFechaVencimiento)
        val editObservaciones = dialogView.findViewById<TextInputEditText>(R.id.edtObservaciones)
        
        // Configurar dropdown de tipos
        val tipos = TipoDocumento.values().map { it.displayName }
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, tipos)
        spinnerTipo.setAdapter(adapter)
        
        spinnerTipo.setOnClickListener { spinnerTipo.showDropDown() }
        spinnerTipo.setOnFocusChangeListener { _, hasFocus -> if (hasFocus) spinnerTipo.showDropDown() }
        
        // Configurar date picker
        editVencimiento.setOnClickListener { showDatePicker(editVencimiento) }
        
        // Crear diálogo
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Agregar Documento")
            .setView(dialogView)
            .setPositiveButton("Guardar", null)
            .setNegativeButton("Cancelar", null)
            .create()
        
        dialog.show()
        
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val selectedTipo = spinnerTipo.text.toString()
            val tipoIndex = tipos.indexOf(selectedTipo)
            
            if (tipoIndex == -1) {
                Toast.makeText(this, "Seleccione un tipo de documento", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val vencimiento = parseDate(editVencimiento.text.toString())
            if (vencimiento == null) {
                Toast.makeText(this, "Complete la fecha de vencimiento", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            guardarDocumento(
                tipo = TipoDocumento.values()[tipoIndex],
                empresa = editEmpresa.text.toString(),
                telefono = editTelefono.text.toString(),
                vencimiento = vencimiento,
                observaciones = editObservaciones.text.toString()
            )
            dialog.dismiss()
        }
    }

    private fun mostrarDialogoAgregarPersonal() {
        Log.d("AdministracionLocal", "mostrarDialogoAgregarPersonal llamado")
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_agregar_personal, null)
        
        val editNombre = dialogView.findViewById<EditText>(R.id.edtNombre)
        val editApellido = dialogView.findViewById<EditText>(R.id.edtApellido)
        val editDni = dialogView.findViewById<EditText>(R.id.edtDni)
        val editCargo = dialogView.findViewById<EditText>(R.id.edtCargo)
        val editTelefono = dialogView.findViewById<TextInputEditText>(R.id.edtTelefono)
        val editEmail = dialogView.findViewById<TextInputEditText>(R.id.edtEmail)
        val editFechaIngreso = dialogView.findViewById<TextInputEditText>(R.id.edtFechaIngreso)
        val editLibretaVencimiento = dialogView.findViewById<TextInputEditText>(R.id.edtVencimientoLibreta)
        val editCursoVencimiento = dialogView.findViewById<TextInputEditText>(R.id.edtVencimientoCurso)
        val chkPoseeLibreta = dialogView.findViewById<CheckBox>(R.id.chkPoseeLibreta)
        val chkPoseeCurso = dialogView.findViewById<CheckBox>(R.id.chkPoseeCurso)
        val layoutLibretaSanitaria = dialogView.findViewById<View>(R.id.layoutLibretaSanitaria)
        val layoutCursoManipulacion = dialogView.findViewById<View>(R.id.layoutCursoManipulacion)
        
        chkPoseeLibreta.setOnCheckedChangeListener { _, isChecked ->
            layoutLibretaSanitaria.visibility = if (isChecked) View.VISIBLE else View.GONE
        }
        chkPoseeCurso.setOnCheckedChangeListener { _, isChecked ->
            layoutCursoManipulacion.visibility = if (isChecked) View.VISIBLE else View.GONE
        }
        
        editFechaIngreso.setOnClickListener { showDatePicker(editFechaIngreso) }
        editLibretaVencimiento.setOnClickListener { showDatePicker(editLibretaVencimiento) }
        editCursoVencimiento.setOnClickListener { showDatePicker(editCursoVencimiento) }
        
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Agregar Personal")
            .setView(dialogView)
            .setPositiveButton("Guardar", null)
            .setNegativeButton("Cancelar", null)
            .create()
            
        dialog.show()
        
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val nombre = editNombre.text.toString()
            val dni = editDni.text.toString()
            val cargo = editCargo.text.toString()
            
            if (nombre.isBlank() || dni.isBlank() || cargo.isBlank()) {
                Toast.makeText(this, "Complete los campos obligatorios (Nombre, DNI, Cargo)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            guardarPersonal(
                nombre = nombre,
                apellido = editApellido.text.toString(),
                dni = dni,
                cargo = cargo,
                telefono = editTelefono.text.toString(),
                email = editEmail.text.toString(),
                fechaIngreso = parseDate(editFechaIngreso.text.toString()),
                libretaVencimiento = if (chkPoseeLibreta.isChecked) parseDate(editLibretaVencimiento.text.toString()) else null,
                cursoVencimiento = if (chkPoseeCurso.isChecked) parseDate(editCursoVencimiento.text.toString()) else null
            )
            dialog.dismiss()
        }
    }

    private fun mostrarDialogoEditarDocumento(documento: DocumentoLocal) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_agregar_documento, null)
        val spinnerTipo = dialogView.findViewById<MaterialAutoCompleteTextView>(R.id.spinnerTipoDocumento)
        val editEmpresa = dialogView.findViewById<TextInputEditText>(R.id.edtEmpresa)
        val editTelefono = dialogView.findViewById<TextInputEditText>(R.id.edtTelefono)
        val editVencimiento = dialogView.findViewById<TextInputEditText>(R.id.edtFechaVencimiento)
        val editObservaciones = dialogView.findViewById<TextInputEditText>(R.id.edtObservaciones)
        
        val tipos = TipoDocumento.values().map { it.displayName }
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, tipos)
        spinnerTipo.setAdapter(adapter)
        spinnerTipo.setOnClickListener { spinnerTipo.showDropDown() }
        
        spinnerTipo.setText(documento.tipoDocumento.displayName, false)
        editEmpresa.setText(documento.empresaResponsable)
        editTelefono.setText(documento.telefono)
        editVencimiento.setText(documento.fechaVencimiento?.let { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it) } ?: "")
        editObservaciones.setText(documento.observaciones)
        
        editVencimiento.setOnClickListener { showDatePicker(editVencimiento) }
        
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Editar Documento")
            .setView(dialogView)
            .setPositiveButton("Actualizar", null)
            .setNegativeButton("Cancelar", null)
            .create()
        
        dialog.show()
        
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val selectedTipo = spinnerTipo.text.toString()
            val tipoIndex = tipos.indexOf(selectedTipo)
            val vencimiento = parseDate(editVencimiento.text.toString())
            
            if (tipoIndex == -1 || vencimiento == null) {
                Toast.makeText(this, "Complete los campos obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            actualizarDocumento(
                documento = documento.copy(
                    tipoDocumento = TipoDocumento.values()[tipoIndex],
                    empresaResponsable = editEmpresa.text.toString(),
                    telefono = editTelefono.text.toString(),
                    fechaVencimiento = vencimiento,
                    observaciones = editObservaciones.text.toString(),
                    estado = when {
                        DateHelper.isDateExpired(vencimiento) -> EstadoDocumento.VENCIDO
                        DateHelper.getDaysUntilDate(vencimiento) <= 30 -> EstadoDocumento.POR_VENCER
                        else -> EstadoDocumento.VIGENTE
                    }
                )
            )
            dialog.dismiss()
        }
    }

    private fun mostrarDialogoEditarPersonal(personal: PersonalLocal) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_agregar_personal, null)
        val editNombre = dialogView.findViewById<EditText>(R.id.edtNombre)
        val editApellido = dialogView.findViewById<EditText>(R.id.edtApellido)
        val editDni = dialogView.findViewById<EditText>(R.id.edtDni)
        val editCargo = dialogView.findViewById<EditText>(R.id.edtCargo)
        val editTelefono = dialogView.findViewById<TextInputEditText>(R.id.edtTelefono)
        val editEmail = dialogView.findViewById<TextInputEditText>(R.id.edtEmail)
        val editFechaIngreso = dialogView.findViewById<TextInputEditText>(R.id.edtFechaIngreso)
        val editLibretaVencimiento = dialogView.findViewById<TextInputEditText>(R.id.edtVencimientoLibreta)
        val editCursoVencimiento = dialogView.findViewById<TextInputEditText>(R.id.edtVencimientoCurso)
        val chkPoseeLibreta = dialogView.findViewById<CheckBox>(R.id.chkPoseeLibreta)
        val chkPoseeCurso = dialogView.findViewById<CheckBox>(R.id.chkPoseeCurso)
        val layoutLibretaSanitaria = dialogView.findViewById<View>(R.id.layoutLibretaSanitaria)
        val layoutCursoManipulacion = dialogView.findViewById<View>(R.id.layoutCursoManipulacion)
        
        chkPoseeLibreta.setOnCheckedChangeListener { _, isChecked ->
            layoutLibretaSanitaria.visibility = if (isChecked) View.VISIBLE else View.GONE
        }
        chkPoseeCurso.setOnCheckedChangeListener { _, isChecked ->
            layoutCursoManipulacion.visibility = if (isChecked) View.VISIBLE else View.GONE
        }
        
        editNombre.setText(personal.nombre)
        editApellido.setText(personal.apellido)
        editDni.setText(personal.dni)
        editCargo.setText(personal.cargo)
        editTelefono.setText(personal.telefono)
        editEmail.setText(personal.email)
        editFechaIngreso.setText(personal.fechaIngreso?.let { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it) } ?: "")
        
        personal.libretaSanitaria?.let { libreta ->
            chkPoseeLibreta.isChecked = true
            layoutLibretaSanitaria.visibility = View.VISIBLE
            editLibretaVencimiento.setText(libreta.fechaVencimiento?.let { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it) } ?: "")
        }
        personal.cursoManipulacion?.let { curso ->
            chkPoseeCurso.isChecked = true
            layoutCursoManipulacion.visibility = View.VISIBLE
            editCursoVencimiento.setText(curso.fechaVencimiento?.let { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(it) } ?: "")
        }
        
        editFechaIngreso.setOnClickListener { showDatePicker(editFechaIngreso) }
        editLibretaVencimiento.setOnClickListener { showDatePicker(editLibretaVencimiento) }
        editCursoVencimiento.setOnClickListener { showDatePicker(editCursoVencimiento) }
        
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Editar Personal")
            .setView(dialogView)
            .setPositiveButton("Actualizar", null)
            .setNegativeButton("Cancelar", null)
            .create()
            
        dialog.show()
        
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val nombre = editNombre.text.toString()
            val dni = editDni.text.toString()
            val cargo = editCargo.text.toString()
            
            if (nombre.isBlank() || dni.isBlank() || cargo.isBlank()) {
                Toast.makeText(this, "Complete los campos obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            actualizarPersonal(
                personal = personal.copy(
                    nombre = nombre,
                    apellido = editApellido.text.toString(),
                    dni = dni,
                    cargo = cargo,
                    telefono = editTelefono.text.toString(),
                    email = editEmail.text.toString(),
                    fechaIngreso = parseDate(editFechaIngreso.text.toString()),
                    libretaSanitaria = if (chkPoseeLibreta.isChecked) {
                        val venc = parseDate(editLibretaVencimiento.text.toString())
                        if (venc != null) {
                            LibretaSanitaria(
                                numeroLibreta = "Libreta Sanitaria",
                                fechaVencimiento = venc,
                                estado = when {
                                    DateHelper.isDateExpired(venc) -> EstadoCertificado.VENCIDO
                                    DateHelper.getDaysUntilDate(venc) <= 30 -> EstadoCertificado.POR_VENCER
                                    else -> EstadoCertificado.VIGENTE
                                },
                                diasParaVencer = DateHelper.getDaysUntilDate(venc)
                            )
                        } else null
                    } else null,
                    cursoManipulacion = if (chkPoseeCurso.isChecked) {
                        val venc = parseDate(editCursoVencimiento.text.toString())
                        if (venc != null) {
                            CursoManipulacion(
                                institucion = "Curso de Manipulación",
                                tipoCurso = "Manipulación de Alimentos",
                                fechaVencimiento = venc,
                                estado = when {
                                    DateHelper.isDateExpired(venc) -> EstadoCertificado.VENCIDO
                                    DateHelper.getDaysUntilDate(venc) <= 30 -> EstadoCertificado.POR_VENCER
                                    else -> EstadoCertificado.VIGENTE
                                },
                                diasParaVencer = DateHelper.getDaysUntilDate(venc)
                            )
                        } else null
                    } else null
                )
            )
            dialog.dismiss()
        }
    }
    
    private fun mostrarDialogoDetalleDocumento(documento: DocumentoLocal) {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val mensaje = """
            Documento: ${documento.nombreDocumento}
            Tipo: ${documento.tipoDocumento.displayName}
            Estado: ${documento.estado.displayName}
            Empresa: ${documento.empresaResponsable}
            Vencimiento: ${documento.fechaVencimiento?.let { sdf.format(it) } ?: "No especificada"}
            Observaciones: ${documento.observaciones.ifEmpty { "Sin observaciones" }}
        """.trimIndent()
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Detalle del Documento")
            .setMessage(mensaje)
            .setPositiveButton("Cerrar", null)
            .setNeutralButton("Editar") { _, _ -> mostrarDialogoEditarDocumento(documento) }
            .setNegativeButton("Eliminar") { _, _ -> mostrarDialogoEliminarDocumento(documento) }
            .show()
    }

    private fun mostrarDialogoDetallePersonal(personal: PersonalLocal) {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val mensaje = """
            Nombre: ${personal.nombreCompleto}
            DNI: ${personal.dni}
            Cargo: ${personal.cargo}
            Teléfono: ${personal.telefono}
            Ingreso: ${personal.fechaIngreso?.let { sdf.format(it) } ?: "No especificada"}
            Libreta: ${personal.libretaSanitaria?.fechaVencimiento?.let { sdf.format(it) } ?: "No posee"}
            Curso: ${personal.cursoManipulacion?.fechaVencimiento?.let { sdf.format(it) } ?: "No posee"}
        """.trimIndent()
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Detalles del Personal")
            .setMessage(mensaje)
            .setPositiveButton("Cerrar", null)
            .setNeutralButton("Editar") { _, _ -> mostrarDialogoEditarPersonal(personal) }
            .setNegativeButton("Eliminar") { _, _ -> mostrarDialogoEliminarPersonal(personal) }
            .show()
    }

    private fun mostrarDialogoEliminarDocumento(documento: DocumentoLocal) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar Documento")
            .setMessage("¿Está seguro que desea eliminar \"${documento.nombreDocumento}\"?")
            .setPositiveButton("Eliminar") { _, _ ->
                documentosLocales.removeIf { it.id == documento.id }
                eliminarDocumentoDeFirebase(documento.id)
                actualizarUI()
                cargarDocumentosUI()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun mostrarDialogoEliminarPersonal(personal: PersonalLocal) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar Personal")
            .setMessage("¿Está seguro que desea eliminar a ${personal.nombreCompleto}?")
            .setPositiveButton("Eliminar") { _, _ ->
                personalLocal.removeIf { it.id == personal.id }
                FirebaseFirestore.getInstance().collection("locales").document(localId)
                    .collection("personal").document(personal.id).delete()
                actualizarUI()
                cargarPersonalUI()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun guardarDocumento(
        tipo: TipoDocumento,
        empresa: String,
        telefono: String,
        vencimiento: Date?,
        observaciones: String
    ) {
        if (vencimiento == null) {
            Toast.makeText(this, "Complete la fecha de vencimiento", Toast.LENGTH_SHORT).show()
            return
        }
        
        val documento = DocumentoLocal(
            id = "doc_${System.currentTimeMillis()}",
            localId = localId,
            tipoDocumento = tipo,
            nombreDocumento = tipo.displayName,
            empresaResponsable = empresa,
            telefono = telefono,
            numeroCertificado = "",
            fechaEmision = null,
            fechaVencimiento = vencimiento,
            observaciones = observaciones,
            diasParaVencer = DateHelper.getDaysUntilDate(vencimiento),
            estado = when {
                DateHelper.isDateExpired(vencimiento) -> EstadoDocumento.VENCIDO
                DateHelper.getDaysUntilDate(vencimiento) <= 30 -> EstadoDocumento.POR_VENCER
                else -> EstadoDocumento.VIGENTE
            }
        )
        
        documentosLocales.add(documento)
        guardarDocumentoEnFirebase(documento)
        generarNotificaciones()
        actualizarUI()
        cargarDocumentosUI()
        
        Toast.makeText(this, "Documento guardado exitosamente", Toast.LENGTH_SHORT).show()
    }

    private fun guardarPersonal(
        nombre: String,
        apellido: String,
        dni: String,
        cargo: String,
        telefono: String,
        email: String,
        fechaIngreso: Date?,
        libretaVencimiento: Date?,
        cursoVencimiento: Date?
    ) {
        val personal = PersonalLocal(
            id = "per_${System.currentTimeMillis()}",
            localId = localId,
            nombre = nombre,
            apellido = apellido,
            dni = dni,
            cargo = cargo,
            telefono = telefono,
            email = email,
            fechaIngreso = fechaIngreso,
            estado = EstadoPersonal.ACTIVO,
            libretaSanitaria = if (libretaVencimiento != null) {
                LibretaSanitaria(
                    numeroLibreta = "Libreta Sanitaria",
                    fechaVencimiento = libretaVencimiento,
                    estado = when {
                        DateHelper.isDateExpired(libretaVencimiento) -> EstadoCertificado.VENCIDO
                        DateHelper.getDaysUntilDate(libretaVencimiento) <= 30 -> EstadoCertificado.POR_VENCER
                        else -> EstadoCertificado.VIGENTE
                    },
                    diasParaVencer = DateHelper.getDaysUntilDate(libretaVencimiento)
                )
            } else null,
            cursoManipulacion = if (cursoVencimiento != null) {
                CursoManipulacion(
                    institucion = "Curso de Manipulación",
                    tipoCurso = "Manipulación de Alimentos",
                    fechaVencimiento = cursoVencimiento,
                    estado = when {
                        DateHelper.isDateExpired(cursoVencimiento) -> EstadoCertificado.VENCIDO
                        DateHelper.getDaysUntilDate(cursoVencimiento) <= 30 -> EstadoCertificado.POR_VENCER
                        else -> EstadoCertificado.VIGENTE
                    },
                    diasParaVencer = DateHelper.getDaysUntilDate(cursoVencimiento)
                )
            } else null
        )
        
        personalLocal.add(personal)
        guardarPersonalEnFirebase(personal)
        generarNotificaciones()
        actualizarUI()
        cargarPersonalUI()
        
        Toast.makeText(this, "Personal guardado exitosamente", Toast.LENGTH_SHORT).show()
    }

    private fun actualizarDocumento(documento: DocumentoLocal) {
        val index = documentosLocales.indexOfFirst { it.id == documento.id }
        if (index != -1) {
            documentosLocales[index] = documento
            guardarDocumentoEnFirebase(documento)
            generarNotificaciones()
            actualizarUI()
            cargarDocumentosUI()
            Toast.makeText(this, "Documento actualizado exitosamente", Toast.LENGTH_SHORT).show()
        }
    }

    private fun actualizarPersonal(personal: PersonalLocal) {
        val index = personalLocal.indexOfFirst { it.id == personal.id }
        if (index != -1) {
            personalLocal[index] = personal
            guardarPersonalEnFirebase(personal)
            generarNotificaciones()
            actualizarUI()
            cargarPersonalUI()
            Toast.makeText(this, "Personal actualizado exitosamente", Toast.LENGTH_SHORT).show()
        }
    }

    private fun eliminarDocumentoDeFirebase(id: String) {
        FirebaseFirestore.getInstance().collection("locales").document(localId)
            .collection("documentos").document(id).delete()
    }

    private fun guardarDocumentoEnFirebase(documento: DocumentoLocal) {
        FirebaseFirestore.getInstance().collection("locales").document(localId)
            .collection("documentos").document(documento.id).set(documento)
    }

    private fun guardarPersonalEnFirebase(personal: PersonalLocal) {
        FirebaseFirestore.getInstance().collection("locales").document(localId)
            .collection("personal").document(personal.id).set(personal)
    }

    private fun showDatePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            calendar.set(y, m, d)
            editText.setText(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(calendar.time))
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun parseDate(dateString: String): Date? {
        if (dateString.isBlank()) return null
        return try {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            sdf.timeZone = TimeZone.getTimeZone("America/Argentina/Buenos_Aires")
            sdf.parse(dateString)
        } catch (e: Exception) { null }
    }

    private fun marcarNotificacionComoLeida(notificacion: NotificacionVencimiento) {
        val index = notificaciones.indexOfFirst { it.id == notificacion.id }
        if (index != -1) {
            notificaciones[index] = notificacion.copy(leida = true)
            actualizarUI()
        }
    }

    private fun formatTimeRemaining(dias: Int): String {
        return when {
            dias < 0 -> "Vencido hace ${-dias} días"
            dias == 0 -> "Vence hoy"
            dias == 1 -> "Vence mañana"
            dias < 30 -> "Vence en $dias días"
            else -> {
                val meses = dias / 30
                if (meses == 1) "Vence en 1 mes"
                else "Vence en $meses meses"
            }
        }
    }

    private fun actualizarUI() {
        txtLocalActual.text = "Administración: $localNombre"
        txtTotalDocumentos.text = documentosLocales.size.toString()
        txtTotalPersonal.text = personalLocal.size.toString()
        txtAlertasActivas.text = notificaciones.count { !it.leida }.toString()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}
