﻿package com.tuapp.inventario.utils

import com.tuapp.inventario.Producto
import com.tuapp.inventario.RegistroInventario
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * Gestor centralizado de cache para toda la aplicacion
 * Optimiza el uso de memoria y sincronizacion de datos
 */
object CacheManager {
    
    // Cache de productos por localId
    private val productosCache = ConcurrentHashMap<String, CacheEntry<List<Producto>>>()
    
    // Cache de registros por localId y fecha
    private val registrosCache = ConcurrentHashMap<String, CacheEntry<List<RegistroInventario>>>()
    
    // Cache de promedios por localId
    private val promediosCache = ConcurrentHashMap<String, CacheEntry<Map<String, Map<String, Double>>>>()
    
    // Cache de stock calculado por localId
    private val stockCache = ConcurrentHashMap<String, CacheEntry<Map<String, Int>>>()
    
    // Cache de tendencias por localId
    private val tendenciasCache = ConcurrentHashMap<String, CacheEntry<Map<String, Double>>>()
    
    // Estado de memoria para monitoreo
    private val _memoryUsage = MutableStateFlow(0.0)
    val memoryUsage: StateFlow<Double> = _memoryUsage.asStateFlow()
    
    // Constantes de tiempo de cache
    private const val CACHE_PRODUCTOS_DURATION = 15 * 60 * 1000L // 15 minutos
    private const val CACHE_REGISTROS_DURATION = 5 * 60 * 1000L   // 5 minutos
    private const val CACHE_PROMEDIOS_DURATION = 30 * 60 * 1000L // 30 minutos
    private const val CACHE_STOCK_DURATION = 2 * 60 * 1000L      // 2 minutos
    private const val CACHE_TENDENCIAS_DURATION = 24 * 60 * 60 * 1000L // 24 horas
    
    data class CacheEntry<T>(
        val data: T,
        val timestamp: Long,
        val size: Int = 0
    ) {
        fun isValid(duration: Long): Boolean {
            return (System.currentTimeMillis() - timestamp) < duration
        }
    }
    
    /**
     * Obtiene productos desde cache o null si no existe o esta expirado
     */
    fun getProductos(localId: String): List<Producto>? {
        val entry = productosCache[getCacheKey(localId, "productos")]
        return if (entry != null && entry.isValid(CACHE_PRODUCTOS_DURATION)) {
            Logger.d("CacheManager", "Cache HIT para productos de $localId")
            entry.data
        } else {
            Logger.d("CacheManager", "Cache MISS para productos de $localId")
            null
        }
    }
    
    /**
     * Guarda productos en cache
     */
    fun setProductes(localId: String, productos: List<Producto>) {
        val key = getCacheKey(localId, "productos")
        val entry = CacheEntry(productos, System.currentTimeMillis(), productos.size)
        productosCache[key] = entry
        Logger.d("CacheManager", "Guardados ${productos.size} productos en cache para $localId")
        updateMemoryUsage()
    }
    
    /**
     * Obtiene registros desde cache o null si no existe o esta expirado
     */
    fun getRegistros(localId: String): List<RegistroInventario>? {
        val entry = registrosCache[getCacheKey(localId, "registros")]
        return if (entry != null && entry.isValid(CACHE_REGISTROS_DURATION)) {
            Logger.d("CacheManager", "Cache HIT para registros de $localId")
            entry.data
        } else {
            Logger.d("CacheManager", "Cache MISS para registros de $localId")
            null
        }
    }
    
    /**
     * Guarda registros en cache
     */
    fun setRegistros(localId: String, registros: List<RegistroInventario>) {
        val key = getCacheKey(localId, "registros")
        val entry = CacheEntry(registros, System.currentTimeMillis(), registros.size)
        registrosCache[key] = entry
        Logger.d("CacheManager", "Guardados ${registros.size} registros en cache para $localId")
        updateMemoryUsage()
    }
    
    /**
     * Obtiene promedios desde cache o null si no existe o esta expirado
     */
    fun getPromedios(localId: String): Map<String, Map<String, Double>>? {
        val entry = promediosCache[getCacheKey(localId, "promedios")]
        return if (entry != null && entry.isValid(CACHE_PROMEDIOS_DURATION)) {
            Logger.d("CacheManager", "Cache HIT para promedios de $localId")
            entry.data
        } else {
            Logger.d("CacheManager", "Cache MISS para promedios de $localId")
            null
        }
    }
    
    /**
     * Guarda promedios en cache
     */
    fun setPromedios(localId: String, promedios: Map<String, Map<String, Double>>) {
        val key = getCacheKey(localId, "promedios")
        val totalSize = promedios.values.sumOf { it.size }
        val entry = CacheEntry(promedios, System.currentTimeMillis(), totalSize)
        promediosCache[key] = entry
        Logger.d("CacheManager", "Guardados promedios ($totalSize productos) en cache para $localId")
        updateMemoryUsage()
    }
    
    /**
     * Obtiene stock calculado desde cache o null si no existe o esta expirado
     */
    fun getStock(localId: String): Map<String, Int>? {
        val entry = stockCache[getCacheKey(localId, "stock")]
        return if (entry != null && entry.isValid(CACHE_STOCK_DURATION)) {
            Logger.d("CacheManager", "Cache HIT para stock de $localId")
            entry.data
        } else {
            Logger.d("CacheManager", "Cache MISS para stock de $localId")
            null
        }
    }
    
    /**
     * Guarda stock calculado en cache
     */
    fun setStock(localId: String, stock: Map<String, Int>) {
        val key = getCacheKey(localId, "stock")
        val entry = CacheEntry(stock, System.currentTimeMillis(), stock.size)
        stockCache[key] = entry
        Logger.d("CacheManager", "Guardados ${stock.size} productos de stock en cache para $localId")
        updateMemoryUsage()
    }
    
    /**
     * Obtiene tendencias desde cache o null si no existe o esta expirado
     */
    fun getTendencias(localId: String): Map<String, Double>? {
        val entry = tendenciasCache[getCacheKey(localId, "tendencias")]
        return if (entry != null && entry.isValid(CACHE_TENDENCIAS_DURATION)) {
            Logger.d("CacheManager", "Cache HIT para tendencias de $localId")
            entry.data
        } else {
            Logger.d("CacheManager", "Cache MISS para tendencias de $localId")
            null
        }
    }
    
    /**
     * Guarda tendencias en cache
     */
    fun setTendencias(localId: String, tendencias: Map<String, Double>) {
        val key = getCacheKey(localId, "tendencias")
        val entry = CacheEntry(tendencias, System.currentTimeMillis(), tendencias.size)
        tendenciasCache[key] = entry
        Logger.d("CacheManager", "Guardadas ${tendencias.size} tendencias en cache para $localId")
        updateMemoryUsage()
    }
    
    /**
     * Invalida todos los caches para un localId especifico
     */
    fun invalidateLocal(localId: String) {
        val keysToRemove = listOf(
            getCacheKey(localId, "productos"),
            getCacheKey(localId, "registros"),
            getCacheKey(localId, "promedios"),
            getCacheKey(localId, "stock"),
            getCacheKey(localId, "tendencias")
        )
        
        keysToRemove.forEach { key ->
            productosCache.remove(key)
            registrosCache.remove(key)
            promediosCache.remove(key)
            stockCache.remove(key)
            tendenciasCache.remove(key)
        }
        
        Logger.d("CacheManager", "Invalidados todos los caches para $localId")
        updateMemoryUsage()
    }
    
    /**
     * Invalida caches especificos
     */
    fun invalidateRegistros(localId: String) {
        registrosCache.remove(getCacheKey(localId, "registros"))
        stockCache.remove(getCacheKey(localId, "stock"))
        Logger.d("CacheManager", "Invalidados cache de registros y stock para $localId")
        updateMemoryUsage()
    }
    
    /**
     * Limpia todos los caches (util para cambios de region)
     */
    fun clearAll() {
        productosCache.clear()
        registrosCache.clear()
        promediosCache.clear()
        stockCache.clear()
        tendenciasCache.clear()
        Logger.d("CacheManager", "Todos los caches han sido limpiados")
        updateMemoryUsage()
    }
    
    /**
     * Limpia caches expirados automaticamente
     */
    fun cleanupExpired() {
        val currentTime = System.currentTimeMillis()
        var removedCount = 0
        
        // Limpiar productos expirados
        productosCache.entries.removeIf { (key, entry) ->
            val shouldRemove = !entry.isValid(CACHE_PRODUCTOS_DURATION)
            if (shouldRemove) removedCount++
            shouldRemove
        }
        
        // Limpiar registros expirados
        registrosCache.entries.removeIf { (key, entry) ->
            val shouldRemove = !entry.isValid(CACHE_REGISTROS_DURATION)
            if (shouldRemove) removedCount++
            shouldRemove
        }
        
        // Limpiar promedios expirados
        promediosCache.entries.removeIf { (key, entry) ->
            val shouldRemove = !entry.isValid(CACHE_PROMEDIOS_DURATION)
            if (shouldRemove) removedCount++
            shouldRemove
        }
        
        // Limpiar stock expirado
        stockCache.entries.removeIf { (key, entry) ->
            val shouldRemove = !entry.isValid(CACHE_STOCK_DURATION)
            if (shouldRemove) removedCount++
            shouldRemove
        }
        
        // Limpiar tendencias expiradas
        tendenciasCache.entries.removeIf { (key, entry) ->
            val shouldRemove = !entry.isValid(CACHE_TENDENCIAS_DURATION)
            if (shouldRemove) removedCount++
            shouldRemove
        }
        
        if (removedCount > 0) {
            Logger.d("CacheManager", "Limpiados $removedCount caches expirados")
            updateMemoryUsage()
        }
    }
    
    /**
     * Obtiene estadisticas del cache
     */
    fun getCacheStats(): CacheStats {
        return CacheStats(
            productosCount = productosCache.size,
            registrosCount = registrosCache.size,
            promediosCount = promediosCache.size,
            stockCount = stockCache.size,
            tendenciasCount = tendenciasCache.size,
            totalMemoryUsage = calculateMemoryUsage()
        )
    }
    
    data class CacheStats(
        val productosCount: Int,
        val registrosCount: Int,
        val promediosCount: Int,
        val stockCount: Int,
        val tendenciasCount: Int,
        val totalMemoryUsage: Double
    )
    
    /**
     * Genera clave de cache consistente
     */
    private fun getCacheKey(localId: String, type: String): String {
        return "${localId}_${type}"
    }
    
    /**
     * Calcula el uso de memoria aproximado
     */
    private fun calculateMemoryUsage(): Double {
        val runtime = Runtime.getRuntime()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val maxMemory = runtime.maxMemory()
        return (usedMemory * 100.0 / maxMemory)
    }
    
    /**
     * Actualiza el estado de uso de memoria
     */
    private fun updateMemoryUsage() {
        _memoryUsage.value = calculateMemoryUsage()
    }
    
    /**
     * Verifica si el uso de memoria es alto y limpia si es necesario
     */
    fun checkMemoryPressure() {
        val usage = calculateMemoryUsage()
        if (usage > 80.0) {
            Logger.w("CacheManager", "Alto uso de memoria detectado: ${usage.toInt()}%")
            
            // Limpiar caches mas antiguos primero
            cleanupExpired()
            
            // Si sigue siendo alto, limpiar caches menos criticos
            if (calculateMemoryUsage() > 85.0) {
                Logger.w("CacheManager", "Memoria aun alta, limpiando caches no criticos")
                stockCache.clear()
                tendenciasCache.clear()
                updateMemoryUsage()
            }
            
            // Como ultimo recurso, limpiar todo
            if (calculateMemoryUsage() > 90.0) {
                Logger.w("CacheManager", "Memoria critica, limpiando todos los caches")
                clearAll()
            }
        }
    }
}
