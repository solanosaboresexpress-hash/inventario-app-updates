﻿package com.tuapp.inventario.utils

import com.google.firebase.firestore.FirebaseFirestore
import com.tuapp.inventario.model.UsuarioMaestro
import kotlinx.coroutines.tasks.await
import com.tuapp.inventario.utils.DateHelper
import java.util.*

/**
 * Utilidad para inicializar el sistema con datos por defecto
 */
object SistemaInicializador {
    
    private val firestore: FirebaseFirestore
        get() = com.tuapp.inventario.utils.FirebaseRegionManager.getFirestore()
    
    /**
     * Inicializa el sistema con un usuario maestro por defecto
     */
    suspend fun inicializarSistema() {
        try {
            // Verificar si ya existe un usuario maestro
            val snapshot = firestore.collection("usuarios_maestros")
                .whereEqualTo("rol", "maestro")
                .get()
                .await()
            
            if (snapshot.isEmpty) {
                // Crear usuario maestro por defecto
                val usuarioMaestro = UsuarioMaestro(
                    usuario = "admin",
                    contraseña = "admin123",
                    rol = "maestro",
                    fechaCreacion = DateHelper.getDateFormat("yyyy-MM-dd").format(Date())
                )
                
                firestore.collection("usuarios_maestros").document("admin").set(usuarioMaestro).await()
                
                // Tambion crear la configuracion de administrador
                firestore.collection("configuracion").document("admin").set(
                    mapOf("password" to "admin123")
                ).await()
                
                println(" Sistema inicializado con usuario maestro por defecto")
            } else {
                println(" Sistema ya inicializado")
            }
            
        } catch (e: Exception) {
            println(" Error inicializando sistema: ${e.message}")
            throw e
        }
    }
}
