﻿package com.tuapp.inventario.utils

import com.google.firebase.firestore.FirebaseFirestore
import com.tuapp.inventario.Producto
import com.tuapp.inventario.RegistroInventario
import com.tuapp.inventario.repository.LocalInventarioRepository
import com.tuapp.inventario.database.InventarioDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Optimizador de sincronizacion para mejorar eficiencia de consultas a Firebase
 * Implementa batching, paralelizacion y cache inteligente
 */
object SyncOptimizer {
    
    data class SyncResult(
        val productosSynced: Int,
        val registrosSynced: Int,
        val duration: Long,
        val fromCache: Boolean
    )
    
    data class SyncStats(
        val totalSyncs: Int,
        val avgDuration: Long,
        val cacheHitRate: Double,
        val lastSyncTime: Long
    )
    
    private var totalSyncs = 0
    private var totalDuration = 0L
    private var cacheHits = 0
    private var lastSyncTime = 0L
    
    /**
     * Sincronizacion optimizada de productos y registros
     */
    suspend fun syncOptimized(
        localId: String,
        firestore: FirebaseFirestore,
        localRepository: LocalInventarioRepository,
        forceRefresh: Boolean = false
    ): SyncResult = coroutineScope {
        val startTime = System.currentTimeMillis()
        
        Logger.d("SyncOptimizer", "Iniciando sincronizacion optimizada para $localId")
        
        // Verificar cache primero
        if (!forceRefresh) {
            val cachedProductos = CacheManager.getProductos(localId)
            val cachedRegistros = CacheManager.getRegistros(localId)
            
            if (cachedProductos != null && cachedRegistros != null) {
                Logger.d("SyncOptimizer", "Usando datos cacheados para $localId")
                cacheHits++
                return@coroutineScope SyncResult(
                    productosSynced = cachedProductos.size,
                    registrosSynced = cachedRegistros.size,
                    duration = System.currentTimeMillis() - startTime,
                    fromCache = true
                )
            }
        }
        
        // Sincronizacion paralela con batching
        val productosDeferred = async(Dispatchers.IO) {
            syncProductosBatch(localId, firestore, localRepository)
        }
        
        val registrosDeferred = async(Dispatchers.IO) {
            syncRegistrosBatch(localId, firestore, localRepository)
        }
        
        // Esperar ambas sincronizaciones
        val productosResult = productosDeferred.await()
        val registrosResult = registrosDeferred.await()
        
        val duration = System.currentTimeMillis() - startTime
        updateStats(duration)
        
        Logger.d("SyncOptimizer", "Sincronizacion completada en ${duration}ms - " +
                "Productos: ${productosResult.first}, Registros: ${registrosResult.first}")
        
        SyncResult(
            productosSynced = productosResult.first,
            registrosSynced = registrosResult.first,
            duration = duration,
            fromCache = false
        )
    }
    
    /**
     * Sincronizacion de productos con batching optimizado
     */
    private suspend fun syncProductosBatch(
        localId: String,
        firestore: FirebaseFirestore,
        localRepository: LocalInventarioRepository
    ): Pair<Int, List<Producto>> = withContext(Dispatchers.IO) {
        try {
            val collection = firestore.collection("locales").document(localId).collection("productos")
            
            // Usar paginacion para grandes cantidades
            val productos = mutableListOf<Producto>()
            var lastDocument: com.google.firebase.firestore.DocumentSnapshot? = null
            val batchSize = 100
            
            do {
                val query = if (lastDocument != null) {
                    collection.orderBy("nombre").startAfter(lastDocument).limit(batchSize.toLong())
                } else {
                    collection.orderBy("nombre").limit(batchSize.toLong())
                }
                
                val snapshot = withTimeoutOrNull(30000L) {
                    query.get().await()
                } ?: break
                
                snapshot.documents.forEach { doc ->
                    val nombre = doc.getString("nombre") ?: return@forEach
                    val categoria = doc.getString("categoria") ?: ""
                    productos.add(Producto(nombre, categoria, 0))
                }
                
                lastDocument = snapshot.documents.lastOrNull()
                
                // Pequena pausa para no sobrecargar Firebase
                if (snapshot.documents.size == batchSize) {
                    delay(50)
                }
                
            } while (snapshot.documents.size == batchSize)
            
            // Guardar en Room localmente
            if (productos.isNotEmpty()) {
                localRepository.deleteAllProductos(localId)
                localRepository.insertProductos(localId, productos)
                
                // Guardar en cache
                CacheManager.setProductes(localId, productos)
            }
            
            Pair(productos.size, productos)
            
        } catch (e: Exception) {
            Logger.w("SyncOptimizer", "Error sincronizando productos para $localId")
            Pair(0, emptyList())
        }
    }
    
    /**
     * Sincronizacion de registros con batching optimizado
     */
    private suspend fun syncRegistrosBatch(
        localId: String,
        firestore: FirebaseFirestore,
        localRepository: LocalInventarioRepository
    ): Pair<Int, List<RegistroInventario>> = withContext(Dispatchers.IO) {
        try {
            val collection = firestore.collection("locales").document(localId).collection("registros")
            
            // Obtener registros ordenados por fecha (mas reciente primero)
            val registros = mutableListOf<RegistroInventario>()
            var lastDocument: com.google.firebase.firestore.DocumentSnapshot? = null
            val batchSize = 50
            
            do {
                val query = if (lastDocument != null) {
                    collection.orderBy("fecha", com.google.firebase.firestore.Query.Direction.DESCENDING)
                        .startAfter(lastDocument)
                        .limit(batchSize.toLong())
                } else {
                    collection.orderBy("fecha", com.google.firebase.firestore.Query.Direction.DESCENDING)
                        .limit(batchSize.toLong())
                }
                
                val snapshot = withTimeoutOrNull(30000L) {
                    query.get().await()
                } ?: break
                
                // Procesar documentos en batch
                val batchRegistros = snapshot.documents.mapNotNull { doc ->
                    try {
                        val fecha = doc.getString("fecha") ?: return@mapNotNull null
                        val tipo = doc.getString("tipo") ?: return@mapNotNull null
                        val productosList = doc.get("productos") as? List<Map<String, Any>>
                        
                        val productos = productosList?.map { productoMap ->
                            val nombre = productoMap["nombre"] as? String ?: ""
                            val cantidad = (productoMap["cantidad"] as? Number)?.toInt() ?: 0
                            Producto(nombre, "", cantidad)
                        } ?: emptyList()
                        
                        RegistroInventario(fecha, tipo, productos)
                    } catch (e: Exception) {
                        Logger.w("SyncOptimizer", "Error procesando documento ${doc.id}: ${e.message}")
                        null
                    }
                }
                
                registros.addAll(batchRegistros)
                lastDocument = snapshot.documents.lastOrNull()
                
                // Pausa para no sobrecargar Firebase
                if (snapshot.documents.size == batchSize) {
                    delay(100)
                }
                
            } while (snapshot.documents.size == batchSize)
            
            // Guardar en Room localmente
            if (registros.isNotEmpty()) {
                localRepository.deleteAllRegistros(localId)
                registros.forEach { registro ->
                    localRepository.saveRegistroInventario(localId, registro)
                }
                
                // Guardar en cache
                CacheManager.setRegistros(localId, registros)
            }
            
            Pair(registros.size, registros)
            
        } catch (e: Exception) {
            Logger.w("SyncOptimizer", "Error sincronizando registros para $localId")
            Pair(0, emptyList())
        }
    }
    
    /**
     * Sincronizacion incremental (solo datos nuevos/modificados)
     */
    suspend fun syncIncremental(
        localId: String,
        firestore: FirebaseFirestore,
        localRepository: LocalInventarioRepository,
        lastSyncTime: Long? = null
    ): SyncResult = coroutineScope {
        val startTime = System.currentTimeMillis()
        
        Logger.d("SyncOptimizer", "Iniciando sincronizacion incremental para $localId")
        
        // Obtener timestamp de ultima sincronizacion local
        val lastSync = lastSyncTime ?: getLastSyncTimestamp(localId, localRepository)
        
        val productosDeferred = async(Dispatchers.IO) {
            syncProductosIncremental(localId, firestore, localRepository, lastSync)
        }
        
        val registrosDeferred = async(Dispatchers.IO) {
            syncRegistrosIncremental(localId, firestore, localRepository, lastSync)
        }
        
        val productosResult = productosDeferred.await()
        val registrosResult = registrosDeferred.await()
        
        val duration = System.currentTimeMillis() - startTime
        updateStats(duration)
        
        // Actualizar timestamp de ultima sincronizacion
        updateLastSyncTimestamp(localId, System.currentTimeMillis())
        
        SyncResult(
            productosSynced = productosResult.first,
            registrosSynced = registrosResult.first,
            duration = duration,
            fromCache = false
        )
    }
    
    /**
     * Sincronizacion incremental de productos
     */
    private suspend fun syncProductosIncremental(
        localId: String,
        firestore: FirebaseFirestore,
        localRepository: LocalInventarioRepository,
        sinceTimestamp: Long
    ): Pair<Int, List<Producto>> = withContext(Dispatchers.IO) {
        try {
            val collection = firestore.collection("locales").document(localId).collection("productos")
            
            // Obtener productos modificados desde el ultimo sync
            val query = collection.whereGreaterThan("timestamp", sinceTimestamp)
            val snapshot = withTimeoutOrNull(30000L) {
                query.get().await()
            } ?: return@withContext Pair(0, emptyList())
            
            val productos = snapshot.documents.mapNotNull { doc ->
                val nombre = doc.getString("nombre") ?: return@mapNotNull null
                val categoria = doc.getString("categoria") ?: ""
                Producto(nombre, categoria, 0)
            }
            
            // Actualizar productos existentes y agregar nuevos
            productos.forEach { producto ->
                // Aqui iria logica para actualizar/insertar productos individuales
            }
            
            // Actualizar cache
            val existingProductos = CacheManager.getProductos(localId) ?: emptyList()
            val updatedProductos = (existingProductos + productos).distinctBy { it.nombre }
            CacheManager.setProductes(localId, updatedProductos)
            
            Pair(productos.size, productos)
            
        } catch (e: Exception) {
            Logger.w("SyncOptimizer", "Error en sync incremental de productos")
            Pair(0, emptyList())
        }
    }
    
    /**
     * Sincronizacion incremental de registros
     */
    private suspend fun syncRegistrosIncremental(
        localId: String,
        firestore: FirebaseFirestore,
        localRepository: LocalInventarioRepository,
        sinceTimestamp: Long
    ): Pair<Int, List<RegistroInventario>> = withContext(Dispatchers.IO) {
        try {
            val collection = firestore.collection("locales").document(localId).collection("registros")
            
            // Obtener registros modificados desde el ultimo sync
            val query = collection.whereGreaterThan("timestamp", sinceTimestamp)
                .orderBy("fecha", com.google.firebase.firestore.Query.Direction.DESCENDING)
            
            val snapshot = withTimeoutOrNull(30000L) {
                query.get().await()
            } ?: return@withContext Pair(0, emptyList())
            
            val registros = snapshot.documents.mapNotNull { doc ->
                try {
                    val fecha = doc.getString("fecha") ?: return@mapNotNull null
                    val tipo = doc.getString("tipo") ?: return@mapNotNull null
                    val productosList = doc.get("productos") as? List<Map<String, Any>>
                    
                    val productos = productosList?.map { productoMap ->
                        val nombre = productoMap["nombre"] as? String ?: ""
                        val cantidad = (productoMap["cantidad"] as? Number)?.toInt() ?: 0
                        Producto(nombre, "", cantidad)
                    } ?: emptyList()
                    
                    RegistroInventario(fecha, tipo, productos)
                } catch (e: Exception) {
                    Logger.w("SyncOptimizer", "Error procesando registro incremental: ${e.message}")
                    null
                }
            }
            
            // Guardar nuevos registros
            registros.forEach { registro ->
                localRepository.saveRegistroInventario(localId, registro)
            }
            
            // Actualizar cache
            val existingRegistros = CacheManager.getRegistros(localId) ?: emptyList()
            val updatedRegistros = (registros + existingRegistros)
                .distinctBy { "${it.fecha}_${it.tipo}" }
                .sortedByDescending { it.fecha }
            CacheManager.setRegistros(localId, updatedRegistros)
            
            Pair(registros.size, registros)
            
        } catch (e: Exception) {
            Logger.w("SyncOptimizer", "Error en sync incremental de registros")
            Pair(0, emptyList())
        }
    }
    
    /**
     * Obtiene estadisticas de sincronizacion
     */
    fun getSyncStats(): SyncStats {
        val avgDuration = if (totalSyncs > 0) totalDuration / totalSyncs else 0L
        val cacheHitRate = if (totalSyncs > 0) (cacheHits * 100.0 / totalSyncs) else 0.0
        
        return SyncStats(
            totalSyncs = totalSyncs,
            avgDuration = avgDuration,
            cacheHitRate = cacheHitRate,
            lastSyncTime = lastSyncTime
        )
    }
    
    /**
     * Reinicia estadisticas
     */
    fun resetStats() {
        totalSyncs = 0
        totalDuration = 0L
        cacheHits = 0
        lastSyncTime = 0L
    }
    
    /**
     * Actualiza estadisticas
     */
    private fun updateStats(duration: Long) {
        totalSyncs++
        totalDuration += duration
        lastSyncTime = System.currentTimeMillis()
    }
    
    /**
     * Obtiene timestamp de ultima sincronizacion
     */
    private suspend fun getLastSyncTimestamp(localId: String, localRepository: LocalInventarioRepository): Long {
        return try {
            // Aqui podrias guardar y recuperar timestamps en SharedPreferences o Room
            // Por ahora, devuelve un timestamp por defecto (24 horas atras)
            System.currentTimeMillis() - 24 * 60 * 60 * 1000L
        } catch (e: Exception) {
            Logger.w("SyncOptimizer", "Error obteniendo ultimo timestamp de sync")
            System.currentTimeMillis() - 24 * 60 * 60 * 1000L
        }
    }
    
    /**
     * Actualiza timestamp de ultima sincronizacion
     */
    private suspend fun updateLastSyncTimestamp(localId: String, timestamp: Long) {
        try {
            // Aqui podrias guardar el timestamp en SharedPreferences o Room
            Logger.d("SyncOptimizer", "Actualizado timestamp de sync para $localId: $timestamp")
        } catch (e: Exception) {
            Logger.w("SyncOptimizer", "Error actualizando timestamp de sync")
        }
    }
}
