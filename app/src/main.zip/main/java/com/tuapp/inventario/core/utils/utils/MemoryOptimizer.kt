﻿package com.tuapp.inventario.utils

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

/**
 * Utilidad para optimizar el manejo de memoria en actividades grandes
 */
object MemoryOptimizer {
    
    private val handler = Handler(Looper.getMainLooper())
    private val activityReferences = mutableMapOf<String, WeakReference<Activity>>()
    private val cleanupTasks = mutableMapOf<String, Runnable>()
    
    /**
     * Registra una actividad para monitoreo y limpieza automatica
     */
    fun registerActivity(activity: Activity, tag: String = activity::class.java.simpleName) {
        activityReferences[tag] = WeakReference(activity)
        
        // Programar limpieza periodica
        val cleanupTask = Runnable {
            cleanupActivity(tag)
            scheduleCleanup(tag, 30000) // 30 segundos
        }
        cleanupTasks[tag] = cleanupTask
        scheduleCleanup(tag, 30000)
    }
    
    /**
     * Elimina una actividad del monitoreo
     */
    fun unregisterActivity(tag: String) {
        activityReferences.remove(tag)
        cleanupTasks[tag]?.let { handler.removeCallbacks(it) }
        cleanupTasks.remove(tag)
    }
    
    /**
     * Limpia memoria de una actividad especifica
     */
    private fun cleanupActivity(tag: String) {
        val activityRef = activityReferences[tag]
        val activity = activityRef?.get()
        
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            // La actividad ya no existe, limpiar referencias
            activityReferences.remove(tag)
            cleanupTasks[tag]?.let { handler.removeCallbacks(it) }
            cleanupTasks.remove(tag)
            return
        }
        
        // Limpiar memoria si es necesario
        if (shouldCleanupMemory(activity)) {
            performMemoryCleanup(activity)
        }
    }
    
    /**
     * Programa una tarea de limpieza
     */
    private fun scheduleCleanup(tag: String, delayMs: Long) {
        cleanupTasks[tag]?.let { task ->
            handler.postDelayed(task, delayMs)
        }
    }
    
    /**
     * Verifica si es necesario limpiar memoria
     */
    private fun shouldCleanupMemory(context: Context): Boolean {
        val runtime = Runtime.getRuntime()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val maxMemory = runtime.maxMemory()
        val memoryUsagePercent = (usedMemory * 100 / maxMemory).toInt()
        
        // Limpiar si se usa mas del 70% de memoria
        return memoryUsagePercent > 70
    }
    
    /**
     * Realiza limpieza de memoria
     */
    private fun performMemoryCleanup(activity: Activity) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Forzar garbage collection
                System.gc()
                
                // Limpiar caches si es necesario
                clearCachesIfNeeded()
                
                // Notificar en el hilo principal
                handler.post {
                    Logger.d("MemoryOptimizer", "Memoria limpiada para ${activity::class.java.simpleName}")
                }
            } catch (e: Exception) {
                Logger.e("MemoryOptimizer", "Error al limpiar memoria", e)
            }
        }
    }
    
    /**
     * Limpia caches si es necesario
     */
    private fun clearCachesIfNeeded() {
        // Limpiar cache de promedios si es muy grande
        val runtime = Runtime.getRuntime()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val maxMemory = runtime.maxMemory()
        val memoryUsagePercent = (usedMemory * 100 / maxMemory).toInt()
        
        if (memoryUsagePercent > 80) {
            // Limpiar cache de MainActivity
            try {
                val mainActivityClass = Class.forName("com.tuapp.inventario.MainActivity")
                val clearCacheMethod = mainActivityClass.getDeclaredMethod("clearAllCaches")
                clearCacheMethod.invoke(null)
            } catch (e: Exception) {
                // Ignorar si el metodo no existe
            }
            
            // Limpiar cache de PedidoFabricaActivity
            try {
                val pedidoFabricaClass = Class.forName("com.tuapp.inventario.PedidoFabricaActivity")
                val clearCacheMethod = pedidoFabricaClass.getDeclaredMethod("clearPromediosCache")
                clearCacheMethod.invoke(null)
            } catch (e: Exception) {
                // Ignorar si el metodo no existe
            }
        }
    }
    
    /**
     * Libera recursos grandes de una actividad
     */
    fun releaseLargeResources(tag: String) {
        val activityRef = activityReferences[tag]
        val activity = activityRef?.get() ?: return
        
        CoroutineScope(Dispatchers.Main).launch {
            try {
                // Liberar recursos grandes especificos de cada actividad
                when (activity::class.java.simpleName) {
                    "PedidoFabricaActivity" -> {
                        // Limpiar listas grandes y caches
                        releasePedidoFabricaResources(activity)
                    }
                    "MainActivity" -> {
                        // Limpiar caches principales
                        releaseMainActivityResources(activity)
                    }
                    "VentaVolumenActivity" -> {
                        // Limpiar datos de ventas
                        releaseVentaVolumenResources(activity)
                    }
                }
                
                Logger.d("MemoryOptimizer", "Recursos grandes liberados para $tag")
            } catch (e: Exception) {
                Logger.e("MemoryOptimizer", "Error al liberar recursos", e)
            }
        }
    }
    
    private fun releasePedidoFabricaResources(activity: Activity) {
        try {
            // Usar reflexion para limpiar variables grandes
            val productosField = activity::class.java.getDeclaredField("productos")
            productosField.isAccessible = true
            productosField.set(activity, emptyList<Any>())
            
            val txtSugerenciasField = activity::class.java.getDeclaredField("txtSugerencias")
            txtSugerenciasField.isAccessible = true
            txtSugerenciasField.set(activity, mutableMapOf<String, Any>())
        } catch (e: Exception) {
            Logger.w("MemoryOptimizer", "No se pudieron liberar recursos de PedidoFabricaActivity: ${e.message}")
        }
    }
    
    private fun releaseMainActivityResources(activity: Activity) {
        try {
            // Limpiar caches estaticas
            val clearCacheMethod = activity::class.java.getDeclaredMethod("clearAllCaches")
            clearCacheMethod.invoke(null)
        } catch (e: Exception) {
            Logger.w("MemoryOptimizer", "No se pudieron liberar recursos de MainActivity: ${e.message}")
        }
    }
    
    private fun releaseVentaVolumenResources(activity: Activity) {
        try {
            // Limpiar datos de ventas
            val registrosCacheField = activity::class.java.getDeclaredField("registrosCache")
            registrosCacheField.isAccessible = true
            registrosCacheField.set(activity, emptyList<Any>())
        } catch (e: Exception) {
            Logger.w("MemoryOptimizer", "No se pudieron liberar recursos de VentaVolumenActivity: ${e.message}")
        }
    }
    
    /**
     * Obtiene informacion de uso de memoria
     */
    fun getMemoryInfo(): String {
        val runtime = Runtime.getRuntime()
        val totalMemory = runtime.totalMemory() / 1024 / 1024
        val freeMemory = runtime.freeMemory() / 1024 / 1024
        val usedMemory = totalMemory - freeMemory
        val maxMemory = runtime.maxMemory() / 1024 / 1024
        val usagePercent = (usedMemory * 100 / maxMemory)
        
        return "Memoria: $usedMemory/$maxMemory MB ($usagePercent%)"
    }
}
