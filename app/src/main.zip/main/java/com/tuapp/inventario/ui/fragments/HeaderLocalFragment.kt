﻿package com.tuapp.inventario.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.tuapp.inventario.R

class HeaderLocalFragment : Fragment() {
    
    private lateinit var txtLocalActual: TextView
    private lateinit var btnAlertaLocal: ImageView
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_header_local, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        txtLocalActual = view.findViewById(R.id.txtLocalActual)
        btnAlertaLocal = view.findViewById(R.id.btnAlertaLocal)
    }
    
    fun actualizarLocal(nombreLocal: String) {
        txtLocalActual.text = " $nombreLocal"
    }
    
    fun mostrarAlerta(mostrar: Boolean) {
        btnAlertaLocal.visibility = if (mostrar) View.VISIBLE else View.GONE
    }
    
    fun configurarAlertaClickListener(listener: () -> Unit) {
        btnAlertaLocal.setOnClickListener { listener() }
    }
}
