﻿package com.tuapp.inventario.update

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class GitHubRelease(
    val tagName: String,
    val versionCode: Int,
    val downloadUrl: String,
    val fileName: String,
    val description: String,
    val forceUpdate: Boolean = false
)

class GitHubUpdateChecker(private val context: Context) {
    
    companion object {
        private const val TAG = "GitHubUpdateChecker"
        // Cambia estos valores por los de tu repositorio
        private const val GITHUB_OWNER = "tu-usuario"  // Tu usuario de GitHub
        private const val GITHUB_REPO = "inventario_app"  // Nombre de tu repositorio
        private const val GITHUB_API_URL = "https://api.github.com/repos/$GITHUB_OWNER/$GITHUB_REPO/releases/latest"
    }
    
    /**
     * Verifica si hay una actualizacion disponible desde GitHub
     */
    suspend fun checkForUpdate(): GitHubRelease? {
        return try {
            Log.d(TAG, " Verificando actualizaciones desde GitHub...")
            
            val currentVersionCode = getCurrentVersionCode()
            Log.d(TAG, " Version actual: $currentVersionCode")
            
            val release = getLatestRelease()
            
            if (release != null && release.versionCode > currentVersionCode) {
                Log.d(TAG, " Actualizacion disponible: ${release.tagName} (${release.versionCode})")
                release
            } else {
                Log.d(TAG, " Aplicacion actualizada")
                null
            }
            
        } catch (e: Exception) {
            Log.e(TAG, " Error verificando actualizaciones", e)
            null
        }
    }
    
    /**
     * Obtiene la informacion de la ultima release desde GitHub API
     */
    private suspend fun getLatestRelease(): GitHubRelease? {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL(GITHUB_API_URL)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("Accept", "application/vnd.github.v3+json")
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(response)
                    
                    // Buscar el archivo APK en los assets
                    val assets = json.getJSONArray("assets")
                    var apkAsset: JSONObject? = null
                    
                    for (i in 0 until assets.length()) {
                        val asset = assets.getJSONObject(i)
                        val fileName = asset.getString("name")
                        if (fileName.endsWith(".apk")) {
                            apkAsset = asset
                            break
                        }
                    }
                    
                    if (apkAsset != null) {
                        val tagName = json.getString("tag_name")
                        val description = json.getString("body")
                        
                        // Extraer versionCode del tag (ej: "v1.2.3" -> 123)
                        val versionCode = extractVersionCode(tagName)
                        
                        GitHubRelease(
                            tagName = tagName,
                            versionCode = versionCode,
                            downloadUrl = apkAsset.getString("browser_download_url"),
                            fileName = apkAsset.getString("name"),
                            description = description,
                            forceUpdate = description.contains("[FORCE_UPDATE]", ignoreCase = true)
                        )
                    } else {
                        Log.w(TAG, " No se encontro archivo APK en la release")
                        null
                    }
                } else {
                    Log.e(TAG, " Error HTTP: ${connection.responseCode}")
                    null
                }
            } catch (e: Exception) {
                Log.e(TAG, " Error obteniendo release desde GitHub", e)
                null
            }
        }
    }
    
    /**
     * Extrae el codigo de version del tag (ej: "v1.2.3" -> 123)
     */
    private fun extractVersionCode(tagName: String): Int {
        return try {
            // Remover 'v' si existe y convertir a numero
            val cleanTag = tagName.removePrefix("v")
            val parts = cleanTag.split(".")
            
            when (parts.size) {
                1 -> parts[0].toInt() * 100
                2 -> parts[0].toInt() * 100 + parts[1].toInt()
                3 -> parts[0].toInt() * 10000 + parts[1].toInt() * 100 + parts[2].toInt()
                else -> cleanTag.replace(".", "").toIntOrNull() ?: 0
            }
        } catch (e: Exception) {
            Log.e(TAG, " Error extrayendo versionCode de $tagName", e)
            0
        }
    }
    
    /**
     * Obtiene el codigo de version actual de la aplicacion
     */
    private fun getCurrentVersionCode(): Int {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.longVersionCode.toInt()
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, " Error obteniendo version actual", e)
            0
        }
    }
    
    /**
     * Descarga la nueva APK desde GitHub
     */
    suspend fun downloadUpdate(release: GitHubRelease, onProgress: (Int) -> Unit = {}): java.io.File? {
        return try {
            Log.d(TAG, " Iniciando descarga desde GitHub...")
            
            val localFile = java.io.File(context.getExternalFilesDir(null), release.fileName)
            
            // Crear directorio si no existe
            localFile.parentFile?.mkdirs()
            
            val url = URL(release.downloadUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 30000
            connection.readTimeout = 30000
            
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val totalSize = connection.contentLength
                val inputStream = connection.inputStream
                val outputStream = java.io.FileOutputStream(localFile)
                
                val buffer = ByteArray(8192)
                var downloaded = 0
                var bytesRead: Int
                
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                    downloaded += bytesRead
                    
                    if (totalSize > 0) {
                        val progress = (downloaded * 100 / totalSize)
                        onProgress(progress)
                    }
                }
                
                inputStream.close()
                outputStream.close()
                
                Log.d(TAG, " Descarga completada: ${localFile.absolutePath}")
                localFile
            } else {
                Log.e(TAG, " Error descargando: ${connection.responseCode}")
                null
            }
            
        } catch (e: Exception) {
            Log.e(TAG, " Error descargando actualizacion", e)
            null
        }
    }
    
    /**
     * Verifica si el archivo APK es valido
     */
    fun validateApk(file: java.io.File): Boolean {
        return try {
            file.exists() && file.length() > 0 && file.extension == "apk"
        } catch (e: Exception) {
            Log.e(TAG, " Error validando APK", e)
            false
        }
    }
}
