﻿package com.tuapp.inventario.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.tuapp.inventario.R
import java.text.SimpleDateFormat
import java.util.*

class DateSelectorFragment : Fragment() {
    
    private lateinit var txtFechaActual: TextView
    private lateinit var btnDiaAnterior: ImageButton
    private lateinit var btnDiaSiguiente: ImageButton
    
    private var fechaSeleccionada: String = ""
    private var listener: DateSelectorListener? = null
    
    interface DateSelectorListener {
        fun onFechaCambiada(fecha: String)
        fun onMostrarCalendario()
    }
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_date_selector, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        txtFechaActual = view.findViewById(R.id.txtFechaActual)
        btnDiaAnterior = view.findViewById(R.id.btnDiaAnterior)
        btnDiaSiguiente = view.findViewById(R.id.btnDiaSiguiente)
        
        configurarFechaActual()
        configurarListeners()
    }
    
    fun setListener(listener: DateSelectorListener) {
        this.listener = listener
    }
    
    private fun configurarFechaActual() {
        val calendar = Calendar.getInstance()
        val formato = SimpleDateFormat("EEEE - dd/MM/yy", Locale("es", "ES"))
        // Forzar zona horaria de Argentina
        formato.timeZone = TimeZone.getTimeZone("America/Argentina/Buenos_Aires")
        
        val sdfFecha = SimpleDateFormat("yyyy-MM-dd", Locale("es", "ES"))
        sdfFecha.timeZone = TimeZone.getTimeZone("America/Argentina/Buenos_Aires")
        fechaSeleccionada = sdfFecha.format(calendar.time)
        
        txtFechaActual.text = formato.format(calendar.time)
    }
    
    private fun configurarListeners() {
        txtFechaActual.setOnClickListener {
            listener?.onMostrarCalendario()
        }
        
        btnDiaAnterior.setOnClickListener {
            cambiarDia(-1)
        }
        
        btnDiaSiguiente.setOnClickListener {
            cambiarDia(1)
        }
    }
    
    private fun cambiarDia(dias: Int) {
        val formato = SimpleDateFormat("yyyy-MM-dd", Locale("es", "ES"))
        formato.timeZone = TimeZone.getTimeZone("America/Argentina/Buenos_Aires")
        
        val fechaActual = formato.parse(fechaSeleccionada)
        val calendar = Calendar.getInstance()
        calendar.time = fechaActual
        calendar.add(Calendar.DAY_OF_MONTH, dias)
        
        fechaSeleccionada = formato.format(calendar.time)
        
        val formatoDisplay = SimpleDateFormat("EEEE - dd/MM/yy", Locale("es", "ES"))
        formatoDisplay.timeZone = TimeZone.getTimeZone("America/Argentina/Buenos_Aires")
        txtFechaActual.text = formatoDisplay.format(calendar.time)
        
        listener?.onFechaCambiada(fechaSeleccionada)
    }
    
    fun getFechaSeleccionada(): String = fechaSeleccionada
    
    fun setFecha(fecha: String) {
        fechaSeleccionada = fecha
        val formatoDisplay = SimpleDateFormat("EEEE - dd/MM/yy", Locale("es", "ES"))
        formatoDisplay.timeZone = TimeZone.getTimeZone("America/Argentina/Buenos_Aires")
        
        try {
            val fechaDate = SimpleDateFormat("yyyy-MM-dd", Locale("es", "ES")).apply {
                timeZone = TimeZone.getTimeZone("America/Argentina/Buenos_Aires")
            }.parse(fecha)
            
            txtFechaActual.text = formatoDisplay.format(fechaDate)
        } catch (e: Exception) {
            // Si hay error, mantener la fecha actual
            configurarFechaActual()
        }
    }
}
