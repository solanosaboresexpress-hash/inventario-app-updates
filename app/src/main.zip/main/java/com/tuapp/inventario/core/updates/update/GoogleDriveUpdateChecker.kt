﻿package com.tuapp.inventario.update

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class GoogleDriveRelease(
    val versionCode: Int,
    val versionName: String,
    val downloadUrl: String,
    val fileName: String,
    val description: String,
    val forceUpdate: Boolean = false
)

class GoogleDriveUpdateChecker(private val context: Context) {
    
    companion object {
        private const val TAG = "GoogleDriveUpdateChecker"
        // Cambia este ID por el de tu carpeta de Google Drive
        private const val GOOGLE_DRIVE_FOLDER_ID = "TU_FOLDER_ID_AQUI"
        private const val VERSION_INFO_FILE = "version_info.json"
        private const val GOOGLE_DRIVE_API_URL = "https://drive.google.com/uc?export=download&id="
    }
    
    /**
     * Verifica si hay una actualizacion disponible desde Google Drive
     */
    suspend fun checkForUpdate(): GoogleDriveRelease? {
        return try {
            Log.d(TAG, " Verificando actualizaciones desde Google Drive...")
            
            val currentVersionCode = getCurrentVersionCode()
            Log.d(TAG, " Version actual: $currentVersionCode")
            
            val release = getLatestRelease()
            
            if (release != null && release.versionCode > currentVersionCode) {
                Log.d(TAG, " Actualizacion disponible: ${release.versionName} (${release.versionCode})")
                release
            } else {
                Log.d(TAG, " Aplicacion actualizada")
                null
            }
            
        } catch (e: Exception) {
            Log.e(TAG, " Error verificando actualizaciones", e)
            null
        }
    }
    
    /**
     * Obtiene la informacion de la ultima version desde Google Drive
     */
    private suspend fun getLatestRelease(): GoogleDriveRelease? {
        return withContext(Dispatchers.IO) {
            try {
                // URL del archivo version_info.json en Google Drive
                val versionInfoUrl = "https://drive.google.com/uc?export=download&id=${getFileIdFromUrl(VERSION_INFO_FILE)}"
                
                val url = URL(versionInfoUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(response)
                    
                    GoogleDriveRelease(
                        versionCode = json.getInt("versionCode"),
                        versionName = json.getString("versionName"),
                        downloadUrl = GOOGLE_DRIVE_API_URL + json.getString("apkFileId"),
                        fileName = json.getString("fileName"),
                        description = json.getString("description"),
                        forceUpdate = json.optBoolean("forceUpdate", false)
                    )
                } else {
                    Log.e(TAG, " Error HTTP: ${connection.responseCode}")
                    null
                }
            } catch (e: Exception) {
                Log.e(TAG, " Error obteniendo informacion de version", e)
                null
            }
        }
    }
    
    /**
     * Obtiene el ID de archivo desde Google Drive (simulado - necesitaras configurar esto)
     */
    private fun getFileIdFromUrl(fileName: String): String {
        // Aqui necesitaras mapear los nombres de archivo a sus IDs de Google Drive
        // Por ahora, retornamos un placeholder
        return when (fileName) {
            VERSION_INFO_FILE -> "TU_VERSION_INFO_FILE_ID"
            else -> "TU_APK_FILE_ID"
        }
    }
    
    /**
     * Obtiene el codigo de version actual de la aplicacion
     */
    private fun getCurrentVersionCode(): Int {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.longVersionCode.toInt()
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, " Error obteniendo version actual", e)
            0
        }
    }
    
    /**
     * Descarga la nueva APK desde Google Drive
     */
    suspend fun downloadUpdate(release: GoogleDriveRelease, onProgress: (Int) -> Unit = {}): java.io.File? {
        return try {
            Log.d(TAG, " Iniciando descarga desde Google Drive...")
            
            val localFile = java.io.File(context.getExternalFilesDir(null), release.fileName)
            
            // Crear directorio si no existe
            localFile.parentFile?.mkdirs()
            
            val url = URL(release.downloadUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 30000
            connection.readTimeout = 30000
            
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val totalSize = connection.contentLength
                val inputStream = connection.inputStream
                val outputStream = java.io.FileOutputStream(localFile)
                
                val buffer = ByteArray(8192)
                var downloaded = 0
                var bytesRead: Int
                
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                    downloaded += bytesRead
                    
                    if (totalSize > 0) {
                        val progress = (downloaded * 100 / totalSize)
                        onProgress(progress)
                    }
                }
                
                inputStream.close()
                outputStream.close()
                
                Log.d(TAG, " Descarga completada: ${localFile.absolutePath}")
                localFile
            } else {
                Log.e(TAG, " Error descargando: ${connection.responseCode}")
                null
            }
            
        } catch (e: Exception) {
            Log.e(TAG, " Error descargando actualizacion", e)
            null
        }
    }
    
    /**
     * Verifica si el archivo APK es valido
     */
    fun validateApk(file: java.io.File): Boolean {
        return try {
            file.exists() && file.length() > 0 && file.extension == "apk"
        } catch (e: Exception) {
            Log.e(TAG, " Error validando APK", e)
            false
        }
    }
}
